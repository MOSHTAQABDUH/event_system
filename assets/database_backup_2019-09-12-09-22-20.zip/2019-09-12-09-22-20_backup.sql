#
# TABLE STRUCTURE FOR: aaccounting_currency
#

DROP TABLE IF EXISTS `aaccounting_currency`;

CREATE TABLE `aaccounting_currency` (
  `account_number` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `statuse` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` int(11) NOT NULL,
  `ad_trmnl` varchar(20) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` int(11) NOT NULL,
  `up_trmnl` varchar(20) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_number`,`currency_id`),
  KEY `currency_id` (`currency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (15, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (33, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (46, 1, 0, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (47, 1, 0, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (53, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (123, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (151, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (155, 5, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (211, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (302, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (555, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1556, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1557, 1, 0, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (3303, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (5214, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10256, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10257, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10259, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10260, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10261, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10263, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10264, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (30265, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (33033, 1, 1, 0, 0, 'hhh', 0, 0, '', 0);
INSERT INTO `aaccounting_currency` (`account_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (330333, 1, 0, 0, 0, 'hhh', 0, 0, '', 0);


#
# TABLE STRUCTURE FOR: accountanalysis
#

DROP TABLE IF EXISTS `accountanalysis`;

CREATE TABLE `accountanalysis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountanalysis_name` varchar(50) NOT NULL,
  `accountanalysis_e_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `accountanalysis` (`id`, `accountanalysis_name`, `accountanalysis_e_name`) VALUES (1, 'عام', 'public');
INSERT INTO `accountanalysis` (`id`, `accountanalysis_name`, `accountanalysis_e_name`) VALUES (2, 'صناديق', 'boxs');
INSERT INTO `accountanalysis` (`id`, `accountanalysis_name`, `accountanalysis_e_name`) VALUES (3, 'بنوك', 'banks');
INSERT INTO `accountanalysis` (`id`, `accountanalysis_name`, `accountanalysis_e_name`) VALUES (4, 'عملاء', 'customers');
INSERT INTO `accountanalysis` (`id`, `accountanalysis_name`, `accountanalysis_e_name`) VALUES (5, 'موردين', 'vendors');


#
# TABLE STRUCTURE FOR: accountingtree
#

DROP TABLE IF EXISTS `accountingtree`;

CREATE TABLE `accountingtree` (
  `account_number` int(11) NOT NULL,
  `account_name` varchar(256) NOT NULL,
  `account_e_name` varchar(256) DEFAULT NULL,
  `acc_primary` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `nature` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `report_type` int(11) NOT NULL,
  `anlays` int(11) NOT NULL,
  `statuse` int(11) NOT NULL,
  `process` int(11) DEFAULT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(20) DEFAULT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(20) DEFAULT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_number`),
  KEY `acc_primary` (`acc_primary`),
  KEY `accountingtree_report_type_2` (`report_type`),
  KEY `accountingtree_anlays_3` (`anlays`),
  CONSTRAINT `accountingtree_ibfk_1` FOREIGN KEY (`acc_primary`) REFERENCES `accountingtree` (`account_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (0, 'شجرة الحسابات', 'accountings tree', 0, 1, 1, 0, 1, 1, 1, NULL, 0, '0000-00-00', '', 0, '0000-00-00', '', 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 'الاصول', NULL, 0, 1, 1, 1, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 'الخصوم', NULL, 0, 1, 0, 1, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (3, 'المصروفات', NULL, 0, 1, 1, 1, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (4, 'الايرادات', NULL, 0, 1, 0, 1, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (11, 'الاصول الثابتة', NULL, 1, 1, 1, 2, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12, 'الاصول المتداولة', NULL, 1, 1, 1, 2, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (13, 'استثمارات واصول مالية', NULL, 1, 1, 1, 2, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (14, 'ارصدة مدينة اخرى', NULL, 1, 1, 1, 2, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (15, 'سيارات', '', 1, 1, 1, 2, 1, 1, 1, NULL, 1, '2019-09-07', '174.136.12.172uscent', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (21, 'الخصوم الثابتة', NULL, 2, 1, 0, 2, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22, 'الخصوم المتداولة', NULL, 2, 1, 0, 2, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (23, 'ارصدة دائنة اخرى', NULL, 2, 1, 0, 2, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31, 'مصاريف النشاط الجاري', NULL, 3, 1, 1, 2, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32, 'مصاريف ادارية وعمومية', NULL, 3, 1, 1, 2, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41, 'ايرادات النشاط الجاري', NULL, 4, 1, 0, 2, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (42, 'الايرادات الاخرى', NULL, 4, 1, 0, 2, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (111, 'الاراضي والمباني', NULL, 11, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (121, 'النقدية في الصناديق والبنوك', NULL, 12, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (122, 'المخزون', NULL, 12, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (123, 'ذمم العملاء', NULL, 12, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (124, 'الاعتمادات المستندية', NULL, 12, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (125, 'اوراق القبض', NULL, 12, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (126, 'ذمم الموظفين', NULL, 12, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (127, 'العهد', NULL, 12, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (128, 'سلف الموظفين', NULL, 12, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (129, 'جاري الفروع', NULL, 12, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (131, 'استثمارات اسهم وشركات', NULL, 13, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (141, 'ارصدة مدينة اخرى', NULL, 14, 1, 1, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (211, 'حقوق الملكية', NULL, 21, 1, 0, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (212, 'قروض طويلة الاجل', NULL, 21, 1, 0, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (213, 'جاري الشــــــركاء', NULL, 21, 1, 0, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (222, 'الدائنون', NULL, 22, 1, 0, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (223, 'اوراق الدفع', NULL, 22, 1, 0, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (224, 'المخصصات', NULL, 22, 1, 0, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (225, 'الفوائد و الضرائب', NULL, 22, 1, 0, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (231, 'ارصدة دائنة اخرى', NULL, 23, 1, 0, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (232, 'المصاريف المستحقة', NULL, 23, 1, 0, 3, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (311, 'مصاريف النشاط الجاري', NULL, 31, 1, 1, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (321, 'مصاريف ادارية', NULL, 32, 1, 1, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (322, 'مصاريف عمومية', NULL, 32, 1, 1, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (323, 'المصروفات التسويقية', NULL, 32, 1, 1, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (324, 'المصاريف والاعباء', NULL, 32, 1, 1, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (325, 'مصاريف الاهلاك', NULL, 32, 1, 1, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (326, 'مجمع الاهلاك', NULL, 32, 1, 1, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (327, 'خسائر رئسمالية', NULL, 32, 1, 1, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (328, 'الحسابات الوسيطة', NULL, 32, 1, 1, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (411, 'ايرادات النشاط الجاري', NULL, 41, 1, 0, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (421, 'ايرادات متنوعه', NULL, 42, 1, 0, 3, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (11101, 'الاراضي', NULL, 111, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12101, 'الصناديق', NULL, 121, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12102, 'البنوك', NULL, 121, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12201, 'المخزون السلعي', NULL, 122, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12301, 'ذمم العملاء', NULL, 123, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12401, 'الاعتمادات المستندية', NULL, 124, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12501, 'اوراق القبض', NULL, 125, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12601, 'ذمم الموظفين', NULL, 126, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12701, 'العهد', NULL, 127, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12801, 'سلف الموظفين', NULL, 128, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12901, 'جاري الفروع الوسيطة', NULL, 129, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (14101, 'مصاريف تحت التأسيس', NULL, 141, 1, 1, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (21101, 'رأس المال', NULL, 211, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (21102, 'الارباح والخسائر', NULL, 211, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (21201, 'قروض طويلة الاجل', NULL, 212, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (21301, 'جاري الشــــــركاء', NULL, 213, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22201, 'الموردون', NULL, 222, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22301, 'اوراق الدفع', NULL, 223, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22401, 'المخصصات', NULL, 224, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22402, 'مجمع الاهلاكات', NULL, 224, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22501, 'الضرائب', NULL, 225, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (23101, 'ارصدة دائنة اخرى', NULL, 231, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (23201, 'مصاريف مستحقة', NULL, 232, 1, 0, 4, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31101, 'تكلفة المبيعات', NULL, 311, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31102, 'مردود المبيعات', NULL, 311, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31103, 'الخصم المسموح به', NULL, 311, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31104, 'مردود مبيعات سنوات سابقة', NULL, 311, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31105, 'تكلفة مردود مبيعات سنوات سابقة', NULL, 311, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31106, 'تسوية المخزون', NULL, 311, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31107, 'فروق الاعتمادات', NULL, 311, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31108, 'مردود مشتريات الكميات المجانية', NULL, 311, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32101, 'مصاريف ادارية', NULL, 321, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32102, 'الايجارات', NULL, 321, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32201, 'مصاريف عمومية', NULL, 322, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32202, 'مصاريف متنوعه اخرى', NULL, 322, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32203, 'اهلاكات الاصول الثابتة', NULL, 322, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32301, 'مصروفات البيع والتوزيع', NULL, 323, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32501, 'مصاريف الاهلاك', NULL, 325, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32601, 'مجمع الاهلاك', NULL, 326, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32701, 'خسائر رأس مالية', NULL, 327, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32801, 'الحسابات الوسيطة', NULL, 328, 1, 1, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41101, 'ايرادات المبيعات', NULL, 411, 1, 0, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41102, 'الخصم المكتسب', NULL, 411, 1, 0, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41103, 'مردود المشتريات', NULL, 411, 1, 0, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41104, 'الكميات المجانية', NULL, 411, 1, 0, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (42101, 'ايرادات رأس مالية', NULL, 421, 1, 0, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (42102, 'ايرادات اخرى متنوعه', NULL, 421, 1, 0, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (42103, 'المسترد من المخصصات', NULL, 421, 1, 0, 4, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12101001, 'صندوق الادارة', NULL, 12101, 2, 1, 5, 1, 2, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12101002, 'صندوق رقم ', NULL, 12101, 2, 1, 5, 1, 2, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12101003, 'صندوق رقم 3', NULL, 12101, 2, 1, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12101004, 'صندوق رقم 4', NULL, 12101, 2, 1, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12101005, 'صندوق رقم 5', NULL, 12101, 2, 1, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12102001, 'البنك رقم 1', NULL, 12102, 2, 1, 5, 1, 3, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12201001, 'المخزون السلعي', NULL, 12201, 2, 1, 5, 1, 4, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12301001, 'عملاء محليون', NULL, 12301, 2, 1, 5, 1, 5, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12301002, 'عملاء خارجيون', NULL, 12301, 2, 1, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12501001, 'اوراق القبض', NULL, 12501, 2, 1, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12801001, 'الموظف رقم 1', NULL, 12801, 2, 1, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12901001, 'وسيط جاري الفروع', NULL, 12901, 2, 1, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (21101001, 'رأس المال', NULL, 21101, 2, 0, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (21102001, 'الارباح والخسائر', NULL, 21102, 2, 0, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22201001, 'موردون محليون', NULL, 22201, 2, 0, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22201002, 'موردون خارجيون', NULL, 22201, 2, 0, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22301001, 'اوراق الدفع', NULL, 22301, 2, 0, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22301002, 'بنوك دائنة واوراق دفع', NULL, 22301, 2, 0, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22501001, 'صافي القيمة المضافة للمشتروات', NULL, 22501, 2, 0, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22501002, 'صافي القيمة المضافة للمبيعات', NULL, 22501, 2, 0, 5, 1, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31101001, 'تكلفة المبيعات', NULL, 31101, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31102001, 'مردود المبيعات', NULL, 31102, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31103001, 'الخصم المسموح به', NULL, 31103, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31104001, 'مردود مبيعات سنوات سابقة', NULL, 31104, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31105001, 'تكلفة مردود مبيعات سنوات سابقة', NULL, 31105, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31106001, 'تسوية المخزون', NULL, 31106, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31107001, 'فروق الاعتمادات', NULL, 31107, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31108001, 'مردود مشتريات الكميات المجانية', NULL, 31108, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32101001, 'المرتبات والاجور', NULL, 32101, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32101002, 'سفر وجوازات', NULL, 32101, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32101003, 'مصاريف بدل اضافى', NULL, 32101, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32101004, 'مكافأت واكرامية', NULL, 32101, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32101005, 'مصاريف مكافأت', NULL, 32101, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32101006, 'مصاريف بنكية', NULL, 32101, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32101007, 'مصاريف نثــرية', NULL, 32101, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32102001, 'الايـــجــــا رات', NULL, 32102, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32201001, 'مصاريف صيانة', NULL, 32201, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32201002, 'مصاريف كهرباء', NULL, 32201, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32201003, 'مصاريف مياة', NULL, 32201, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32201004, 'مصاريف هاتف', NULL, 32201, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32201005, 'مصاريف اجور نقل', NULL, 32201, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32201006, 'مصاريف اجور تصنيع', NULL, 32201, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32201007, 'مصاريف اجور شحن', NULL, 32201, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32201008, 'مصاريف محروقات', NULL, 32201, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32202001, 'نثريات', NULL, 32202, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32202002, 'صدقة ومساعدات', NULL, 32202, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32203001, 'اهلاكات الاصول الثابتة', NULL, 32203, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32301001, 'عمولات وتسهيلات المبيعات', NULL, 32301, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32301002, 'عمولات المبيعات', NULL, 32301, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32301003, 'نقل المبيعات', NULL, 32301, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32601001, 'مجمع اهلاك السيارات', NULL, 32601, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32701001, 'خسائر رأس مالية', NULL, 32701, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32801001, 'فوارق العملة', NULL, 32801, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32801002, 'فوارق الكسور', NULL, 32801, 2, 1, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41101001, 'ايرادات مبيعات ', NULL, 41101, 2, 0, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41102001, 'الخصم المكتسب', NULL, 41102, 2, 0, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41103001, 'مردود المشتريات', NULL, 41103, 2, 0, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41104001, 'الكميات المجانية', NULL, 41104, 2, 0, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (42101001, 'ايرادات بيع الاصول', NULL, 42101, 2, 0, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', NULL, 0);
INSERT INTO `accountingtree` (`account_number`, `account_name`, `account_e_name`, `acc_primary`, `type`, `nature`, `level`, `report_type`, `anlays`, `statuse`, `process`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (42102001, 'ايرادات متنوعه اخرى', '', 42102, 2, 0, 5, 2, 1, 1, NULL, 1, '2019-07-28', '192.168.1.10moshtaq', 1, '2019-09-12', '174.136.12.172uscent', 0);


#
# TABLE STRUCTURE FOR: accountreport
#

DROP TABLE IF EXISTS `accountreport`;

CREATE TABLE `accountreport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountreport_name` varchar(50) NOT NULL,
  `accountreport_e_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `accountreport` (`id`, `accountreport_name`, `accountreport_e_name`) VALUES (1, ' ميزانية عمومية', 'Profit and loss');
INSERT INTO `accountreport` (`id`, `accountreport_name`, `accountreport_e_name`) VALUES (2, 'ارباح وخسائر', 'balance sheet');


#
# TABLE STRUCTURE FOR: adjst_id
#

DROP TABLE IF EXISTS `adjst_id`;

CREATE TABLE `adjst_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adjst_id` int(11) NOT NULL,
  `yr_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_unit` int(11) NOT NULL,
  `adj_qty` double NOT NULL,
  `qty_stock` double NOT NULL,
  `cost` double NOT NULL,
  `stock_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `adjst_id` (`adjst_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: adjst_stock_mst
#

DROP TABLE IF EXISTS `adjst_stock_mst`;

CREATE TABLE `adjst_stock_mst` (
  `adjst_id` int(11) NOT NULL DEFAULT '0',
  `account` varchar(50) NOT NULL,
  `adjst_desc` varchar(255) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `ref_no` varchar(20) NOT NULL,
  `amt` double NOT NULL,
  `posted` int(11) NOT NULL DEFAULT '0',
  `posted_u_id` int(11) NOT NULL,
  `posted_date` date DEFAULT NULL,
  `yr_no` int(4) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `adjst_type` int(11) NOT NULL DEFAULT '1',
  `cost_center` int(11) NOT NULL,
  `adjst_date` date NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  PRIMARY KEY (`adjst_id`,`yr_no`,`br_no`,`comp_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: approv_level
#

DROP TABLE IF EXISTS `approv_level`;

CREATE TABLE `approv_level` (
  `u_id` int(11) NOT NULL,
  `form_no` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_u_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`u_id`,`form_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bank
#

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(100) NOT NULL,
  `bank_e_name` varchar(100) NOT NULL,
  `statuse` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `br_id` int(11) NOT NULL,
  `account` int(50) NOT NULL,
  `account_in_bank` varchar(50) NOT NULL,
  `min_border` float NOT NULL,
  `max_border` float NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `account` (`account`),
  KEY `br_id` (`br_id`),
  CONSTRAINT `bank_ibfk_1` FOREIGN KEY (`account`) REFERENCES `accountingtree` (`account_number`),
  CONSTRAINT `bank_ibfk_2` FOREIGN KEY (`br_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `bank` (`id`, `bank_name`, `bank_e_name`, `statuse`, `type`, `br_id`, `account`, `account_in_bank`, `min_border`, `max_border`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 'الراجحي', 'alrajehay', 1, 0, 1, 12102001, '', '0', '0', 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', '', 0);
INSERT INTO `bank` (`id`, `bank_name`, `bank_e_name`, `statuse`, `type`, `br_id`, `account`, `account_in_bank`, `min_border`, `max_border`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 'الانماء', 'alinma', 1, 0, 1, 12102001, '', '0', '0', 1, '2019-08-01', '192.168.1.10moshtaq', 0, '0000-00-00', '', 0);


#
# TABLE STRUCTURE FOR: bank_currency
#

DROP TABLE IF EXISTS `bank_currency`;

CREATE TABLE `bank_currency` (
  `bank_number` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `statuse` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `bank_currency` (`bank_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 5, 1, 1, '2019-06-20', '192.168.1.10moshtaq', 1, '2019-06-20', '192.168.1.10moshtaq', 6);
INSERT INTO `bank_currency` (`bank_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 5, 1, 1, '2019-06-20', '192.168.1.10moshtaq', 1, '2019-06-24', '192.168.1.10moshtaq', 7);
INSERT INTO `bank_currency` (`bank_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 5, 1, 1, '2019-06-24', '192.168.1.10moshtaq', 0, '0000-00-00', '', 0);
INSERT INTO `bank_currency` (`bank_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (3, 1, 1, 1, '2019-06-24', '192.168.1.10moshtaq', 1, '2019-06-24', '192.168.1.10moshtaq', 1);
INSERT INTO `bank_currency` (`bank_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 1, 1, 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', '', 0);
INSERT INTO `bank_currency` (`bank_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 1, 1, 1, '2019-08-01', '192.168.1.10moshtaq', 0, '0000-00-00', '', 0);


#
# TABLE STRUCTURE FOR: box
#

DROP TABLE IF EXISTS `box`;

CREATE TABLE `box` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `box_name` varchar(100) NOT NULL,
  `box_e_name` varchar(100) NOT NULL,
  `br_id` int(11) NOT NULL,
  `account` int(50) NOT NULL,
  `statuse` int(1) NOT NULL DEFAULT '1',
  `type` int(11) NOT NULL,
  `min_border` float NOT NULL,
  `max_border` float NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `br_id` (`br_id`),
  KEY `account` (`account`),
  CONSTRAINT `box_ibfk_1` FOREIGN KEY (`account`) REFERENCES `accountingtree` (`account_number`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `box` (`id`, `box_name`, `box_e_name`, `br_id`, `account`, `statuse`, `type`, `min_border`, `max_border`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 'الادارة', 'management', 1, 12101001, 1, 0, '0', '0', 1, '2019-07-28', '192.168.1.10moshtaq', 0, '0000-00-00', '', 0);
INSERT INTO `box` (`id`, `box_name`, `box_e_name`, `br_id`, `account`, `statuse`, `type`, `min_border`, `max_border`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 'الادارة مكة', 'makah', 1, 12101002, 1, 0, '0', '0', 1, '2019-08-01', '192.168.1.10moshtaq', 0, '0000-00-00', '', 0);


#
# TABLE STRUCTURE FOR: box_currency
#

DROP TABLE IF EXISTS `box_currency`;

CREATE TABLE `box_currency` (
  `box_number` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `statuse` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` int(11) NOT NULL,
  `ad_trmnl` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` int(11) NOT NULL,
  `up_trmnl` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 1, 1, 0, 0, 'hhh', 1, 2019, '192.168.1.10moshtaq', 15);
INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 1, 1, 0, 2019, '192.168.1.10moshtaq', 1, 2019, '192.168.1.10moshtaq', 6);
INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (3, 1, 1, 0, 2019, '192.168.1.10moshtaq', 1, 2019, '192.168.1.10moshtaq', 11);
INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (13, 1, 0, 1, 2019, '192.168.1.10moshtaq', 1, 2019, '192.168.1.10moshtaq', 1);
INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10, 1, 1, 1, 2019, '192.168.1.10moshtaq', 0, 0, '', 0);
INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (11, 1, 1, 1, 2019, '192.168.1.10moshtaq', 0, 0, '', 0);
INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (18, 1, 0, 1, 2019, '192.168.1.10moshtaq', 0, 0, '', 0);
INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (19, 1, 0, 1, 2019, '192.168.1.10moshtaq', 0, 0, '', 0);
INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 1, 1, 1, 2019, '192.168.1.10moshtaq', 0, 0, '', 0);
INSERT INTO `box_currency` (`box_number`, `currency_id`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 1, 1, 1, 2019, '192.168.1.10moshtaq', 0, 0, '', 0);


#
# TABLE STRUCTURE FOR: branch
#

DROP TABLE IF EXISTS `branch`;

CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `br_name` varchar(256) NOT NULL,
  `br_e_name` varchar(256) NOT NULL,
  `location` varchar(256) NOT NULL,
  `web` varchar(100) NOT NULL,
  `phone` int(11) NOT NULL,
  `fax` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tax_num` bigint(111) NOT NULL,
  `country` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `logo` double NOT NULL,
  `BranchStatus` int(11) NOT NULL DEFAULT '1',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` int(11) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` int(11) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `conuty_id` (`country`),
  KEY `city_id` (`city`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `branch` (`id`, `br_name`, `br_e_name`, `location`, `web`, `phone`, `fax`, `email`, `tax_num`, `country`, `city`, `logo`, `BranchStatus`, `ad_u_id`, `ad_date`, `up_u_id`, `up_date`, `up_count`) VALUES (1, 'الرياض', 'riyadh', 'alriyadh', 'riyadh@com.sa', 110545255, 11554415, 'ts@kpi.com.sa', '214748364758588548', 0, 0, '0', 1, 0, 0, 0, 0, 0);
INSERT INTO `branch` (`id`, `br_name`, `br_e_name`, `location`, `web`, `phone`, `fax`, `email`, `tax_num`, `country`, `city`, `logo`, `BranchStatus`, `ad_u_id`, `ad_date`, `up_u_id`, `up_date`, `up_count`) VALUES (8, 'مكة', 'makah', 'rthgrythtr5hg', 'gtrhyrthgy', 2147483647, 2147483647, 'ts@kpi.com.sa', '0', 0, 0, '0', 1, 0, 0, 0, 0, 0);
INSERT INTO `branch` (`id`, `br_name`, `br_e_name`, `location`, `web`, `phone`, `fax`, `email`, `tax_num`, `country`, `city`, `logo`, `BranchStatus`, `ad_u_id`, `ad_date`, `up_u_id`, `up_date`, `up_count`) VALUES (9, 'مؤسسه افكار التسويق', '0', 'الرياض', '0', 0, 0, 'ahmad-qandil@hotmail.com', '0', 0, 0, '0', 1, 0, 0, 0, 0, 0);


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `CategoryNumber` int(5) DEFAULT NULL,
  `CategoryName` varchar(100) NOT NULL,
  `CategoryName_en` varchar(100) DEFAULT NULL,
  `CategoryPic` varchar(6) DEFAULT NULL,
  `BulkUnitID` int(6) DEFAULT NULL,
  `RetailUnitID` varchar(6) DEFAULT NULL,
  `RetailEqualBulk` varchar(6) DEFAULT NULL,
  `Price` varchar(6) DEFAULT NULL,
  `ParcodeBulk` varchar(6) DEFAULT NULL,
  `ParcodeRetail` varchar(6) DEFAULT NULL,
  `CurrencyID` int(6) DEFAULT NULL,
  `CategoryGoods` varchar(6) DEFAULT NULL,
  `ID` int(6) DEFAULT NULL,
  `AD_U_ID` int(5) DEFAULT NULL,
  `AD_DATE` date DEFAULT NULL,
  `UP_U_ID` int(5) DEFAULT NULL,
  `UP_DATE` date DEFAULT NULL,
  `UP_CNT` int(10) DEFAULT NULL,
  `PR_REP` int(10) DEFAULT NULL,
  `AD_TRMNL_NM` varchar(50) DEFAULT NULL,
  `UP_TRMNL_NM` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: chiques_book_dtl
#

DROP TABLE IF EXISTS `chiques_book_dtl`;

CREATE TABLE `chiques_book_dtl` (
  `bank_no` int(11) NOT NULL,
  `chiques_book_no` int(11) NOT NULL,
  `page_no` int(11) NOT NULL,
  `process` int(11) NOT NULL DEFAULT '0',
  `p_u_id` int(11) NOT NULL,
  `p_date` date NOT NULL,
  `p_trmnl` varchar(50) NOT NULL,
  PRIMARY KEY (`bank_no`,`chiques_book_no`,`page_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 3, 1, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 3, 2, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 2, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 3, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 4, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 5, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 6, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 7, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 8, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 9, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 10, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 11, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 12, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 13, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 14, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 15, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 16, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 17, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 18, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 19, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 20, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 21, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 22, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 23, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 24, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 25, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 26, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 27, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 28, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 29, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 30, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 31, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 32, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 33, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 34, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 35, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 36, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 37, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 38, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 39, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 40, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 41, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 42, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 43, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 44, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 45, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 46, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 47, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 48, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 49, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 50, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 51, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 52, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 53, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 54, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 55, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 56, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 57, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 58, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 59, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 60, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 61, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 62, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 63, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 64, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 65, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 66, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 67, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 68, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 69, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 70, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 71, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 72, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 73, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 74, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 75, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 76, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 77, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 78, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 79, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 80, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 81, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 82, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 83, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 84, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 85, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 86, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 87, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 88, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 89, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 90, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 91, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 92, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 93, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 94, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 95, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 96, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 97, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 98, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 99, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 100, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 101, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 102, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 103, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 104, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 105, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 106, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 107, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 108, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 109, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 110, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 111, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 112, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 113, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 114, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 115, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 116, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 117, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 118, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 119, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 4, 120, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 9, 5, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 9, 6, 0, 0, '0000-00-00', '');
INSERT INTO `chiques_book_dtl` (`bank_no`, `chiques_book_no`, `page_no`, `process`, `p_u_id`, `p_date`, `p_trmnl`) VALUES (1, 9, 7, 0, 0, '0000-00-00', '');


#
# TABLE STRUCTURE FOR: chiques_book_mst
#

DROP TABLE IF EXISTS `chiques_book_mst`;

CREATE TABLE `chiques_book_mst` (
  `bank_no` int(11) NOT NULL,
  `chiques_book_no` int(11) NOT NULL,
  `from_no` int(11) NOT NULL,
  `to_no` int(11) NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bank_no`,`chiques_book_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `chiques_book_mst` (`bank_no`, `chiques_book_no`, `from_no`, `to_no`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 3, 1, 2, 0, 1, '2019-06-23', '192.168.1.10moshtaq', 1, '2019-07-07', '192.168.1.14drabdulrahman', 5);
INSERT INTO `chiques_book_mst` (`bank_no`, `chiques_book_no`, `from_no`, `to_no`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 4, 2, 120, 0, 1, '2019-06-24', '192.168.1.10moshtaq', 1, '2019-07-07', '192.168.1.14drabdulrahman', 3);
INSERT INTO `chiques_book_mst` (`bank_no`, `chiques_book_no`, `from_no`, `to_no`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 9, 5, 7, 0, 1, '2019-06-23', '192.168.1.10moshtaq', 1, '2019-07-07', '192.168.1.14drabdulrahman', 3);


#
# TABLE STRUCTURE FOR: city
#

DROP TABLE IF EXISTS `city`;

CREATE TABLE `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(50) NOT NULL,
  `city_e_name` varchar(50) NOT NULL,
  `country` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `conutry_id` (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: comp_inf
#

DROP TABLE IF EXISTS `comp_inf`;

CREATE TABLE `comp_inf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `copm_name` varchar(256) NOT NULL,
  `comp_e_name` varchar(256) NOT NULL,
  `location` varchar(256) NOT NULL,
  `web` varchar(50) NOT NULL,
  `phone` int(11) NOT NULL,
  `logo` blob NOT NULL,
  `tax_num` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: cost_center
#

DROP TABLE IF EXISTS `cost_center`;

CREATE TABLE `cost_center` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `e_name` varchar(256) NOT NULL,
  `type` int(11) NOT NULL,
  `statuse` int(11) DEFAULT '0',
  `cost_primary` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  `yr_no` int(4) NOT NULL DEFAULT '2019',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

INSERT INTO `cost_center` (`id`, `name`, `e_name`, `type`, `statuse`, `cost_primary`, `ad_u_id`, `ad_date`, `up_u_id`, `ad_trmnl`, `up_trmnl`, `up_date`, `up_count`, `yr_no`) VALUES (1, 'مراكز التكلفة', 'cost center', 1, 1, 0, 1, '2019-06-17', 0, '', '', '0000-00-00', 0, 0);
INSERT INTO `cost_center` (`id`, `name`, `e_name`, `type`, `statuse`, `cost_primary`, `ad_u_id`, `ad_date`, `up_u_id`, `ad_trmnl`, `up_trmnl`, `up_date`, `up_count`, `yr_no`) VALUES (101, '1مراكز التكلفة', 'cost center1', 2, 1, 1, 1, '2019-06-24', 1, '192.168.1.10moshtaq', '192.168.1.10moshtaq', '2019-06-24', 12, 2019);


#
# TABLE STRUCTURE FOR: countries
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `countryID` int(11) NOT NULL,
  `countryname` varchar(50) DEFAULT NULL,
  `countryname_en` varchar(40) DEFAULT NULL,
  `FIELD1` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`countryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: country
#

DROP TABLE IF EXISTS `country`;

CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) NOT NULL,
  `country_e_name` varchar(50) NOT NULL,
  `continent` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `continent` (`continent`),
  KEY `continent_2` (`continent`),
  KEY `continent_3` (`continent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: currency
#

DROP TABLE IF EXISTS `currency`;

CREATE TABLE `currency` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(60) NOT NULL,
  `currency_e_name` varchar(60) DEFAULT NULL,
  `cur_code` varchar(7) DEFAULT NULL,
  `currency_sub` varchar(1) NOT NULL,
  `currency_type` int(1) NOT NULL DEFAULT '0',
  `ex_value` double DEFAULT '1',
  `inv_currency` int(11) DEFAULT '0',
  `inactive` int(11) DEFAULT NULL,
  `inactive_res` varchar(10) DEFAULT NULL,
  `ex_min_value` float(24,9) DEFAULT NULL,
  `ex_max_value` float(24,9) DEFAULT NULL,
  `ad_u_id` int(5) DEFAULT NULL,
  `ad_date` date DEFAULT NULL,
  `up_u_id` int(5) DEFAULT NULL,
  `up_date` date DEFAULT NULL,
  `up_count` int(10) DEFAULT NULL,
  `ad_trmnl` varchar(50) DEFAULT NULL,
  `up_trmnl` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CUR_CODE` (`cur_code`),
  UNIQUE KEY `cur_code_2` (`cur_code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `currency` (`id`, `currency_name`, `currency_e_name`, `cur_code`, `currency_sub`, `currency_type`, `ex_value`, `inv_currency`, `inactive`, `inactive_res`, `ex_min_value`, `ex_max_value`, `ad_u_id`, `ad_date`, `up_u_id`, `up_date`, `up_count`, `ad_trmnl`, `up_trmnl`) VALUES (1, 'ريال سعودي', 'SAR', 'SAR', 'ه', 1, '1', NULL, NULL, NULL, '1.000000000', '1.000000000', 1, '2019-06-13', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `currency` (`id`, `currency_name`, `currency_e_name`, `cur_code`, `currency_sub`, `currency_type`, `ex_value`, `inv_currency`, `inactive`, `inactive_res`, `ex_min_value`, `ex_max_value`, `ad_u_id`, `ad_date`, `up_u_id`, `up_date`, `up_count`, `ad_trmnl`, `up_trmnl`) VALUES (5, 'YER', '	YER', 'YER', 'ق', 0, '0.0067', NULL, NULL, NULL, '1.000000000', '1.000000000', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `currency` (`id`, `currency_name`, `currency_e_name`, `cur_code`, `currency_sub`, `currency_type`, `ex_value`, `inv_currency`, `inactive`, `inactive_res`, `ex_min_value`, `ex_max_value`, `ad_u_id`, `ad_date`, `up_u_id`, `up_date`, `up_count`, `ad_trmnl`, `up_trmnl`) VALUES (6, 'RT', 'RT', 'RT', 'R', 0, '0.4', NULL, NULL, NULL, '1.000000000', '1.000000000', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `currency` (`id`, `currency_name`, `currency_e_name`, `cur_code`, `currency_sub`, `currency_type`, `ex_value`, `inv_currency`, `inactive`, `inactive_res`, `ex_min_value`, `ex_max_value`, `ad_u_id`, `ad_date`, `up_u_id`, `up_date`, `up_count`, `ad_trmnl`, `up_trmnl`) VALUES (7, 'روبية', 'IND', 'IND', 'I', 0, '0.2', NULL, NULL, NULL, '0.010000000', '0.010000000', NULL, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(256) DEFAULT NULL,
  `CustomerAccount` int(11) DEFAULT NULL,
  `CustomerPhone` int(11) DEFAULT NULL,
  `CustomerMobile` int(11) DEFAULT NULL,
  `CustomerEmail` varchar(256) DEFAULT NULL,
  `CustomerAddress` varchar(256) DEFAULT NULL,
  `CustomerDebtLimit` float DEFAULT NULL,
  `CustomerTxNo` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: favorite_screens
#

DROP TABLE IF EXISTS `favorite_screens`;

CREATE TABLE `favorite_screens` (
  `u_id` int(11) NOT NULL,
  `form_no` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`u_id`,`form_no`),
  KEY `form_no` (`form_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: forms
#

DROP TABLE IF EXISTS `forms`;

CREATE TABLE `forms` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `label` varchar(200) NOT NULL,
  `label_ar` varchar(256) NOT NULL,
  `parent_id` varchar(11) NOT NULL,
  `link` varchar(200) CHARACTER SET latin1 NOT NULL DEFAULT '#',
  `statuse` int(11) NOT NULL DEFAULT '1',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (1, 'accounting system', 'accounting system', 'النظام المحاسبي', '0', 'main', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (2, 'system setup', 'system setup', 'تهيئة النظام', '1', 'system_setup', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3, 'system management', 'system management', 'ادارة النظام', '1', 'system_management', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4, 'accounting system', 'accounting system', 'نظام الاستاذالعام', '1', 'accounting_system', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5, 'invevntory system', 'invevntory system', 'نظام المخازن', '1', 'invevntory_system', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6, 'venders system', 'venders system', 'نظام الموردين والمشتريات', '1', 'venders_system', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7, 'customers system', 'customers system', 'نظام العملاء والمبيعات', '1', 'customers_system', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10, 'mangament informations system', 'mangament informations system', 'نظام ادارة المعلومات', '1', 'mangament_informations_system', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (30, 'privilege', 'privilege and safty', 'الصلاحيات والامان', '3', 'privilege', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (31, 'closing', 'closings', 'الاقفالات', '3', 'closing', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (33, 'database management', 'database management', 'ادارة قاعدة البيانات', '3', 'database_management', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (34, 'report', 'reports', 'التقارير', '3', 'sm_reports', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (40, 'input', 'Inputs', 'المدخلات', '4', 'acc_Inputs', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (41, 'transaction', 'Transactions', 'العمليات', '4', 'acc_transaction', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (42, 'report', 'reports', 'التقارير', '4', 'acc_reports', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (50, 'input', 'Inputs', 'المدخلات', '5', 'inv_input', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (51, 'transaction', 'Transactions', 'العمليات', '5', 'inv_transaction', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (52, 'report', 'reports', 'التقارير', '5', 'inv_reports', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (60, 'input', 'Inputs', 'المدخلات', '6', 'vn_inputs', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (61, 'transaction', 'Transactions', 'العمليات', '6', 'vn_transaction', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (62, 'report', 'reports', 'التقارير', '6', 'vn_reports', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (70, 'input', 'Inputs', 'المدخلات', '7', 'cus_input', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (71, 'transaction', 'Transactions', 'العمليات', '7', 'cus_transaction', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (72, 'report', 'reports', 'التقارير', '7', 'cus_reports', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (103, 'system management', 'System Management', 'ادارة النظام', '10', 'mis_system_management', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (104, 'accounting system', 'Accounting System', 'الاستاذ العام', '10', 'mis_accounting_system', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (105, '	\r\ninvevntory system', '	\r\nInvevntory System', 'نظام المخزون', '10', 'mis_invevntory_system', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (106, 'vender system', 'Venders System', ' نظام الموردين والمشتريات', '10', 'mis_vender_system', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (107, 'customer system', 'Customers System', 'نظام العملاء والمبيعات', '10', 'mis_customer_system', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (200, 'common parameter', 'Common parameters', 'المتغيرات العامة', '2', 'common_parameter', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (201, 'country details', 'Countries Details', 'بيانات الدول', '2', 'country_details', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (202, 'city detail', 'Cities Details', 'بيانات المدن', '2', 'city_deatil', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (203, 'region detail', 'Region Details', 'بيانات المناطق', '2', 'region_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (204, 'comany detail', 'Comaneis Details', 'بيانات الشركات', '2', 'comany_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (205, 'branch detail', 'Branchs Details', 'بييانات الفروع', '2', 'branch_details', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (206, 'user data', 'Users Details', 'بيانات المستخدمين', '2', 'user_details', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (207, 'accounting treee', 'Accounting Treee', 'الدليل المحاسبي', '2', 'accounting_treee', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (208, 'cost centers', 'Cost Centers', 'مراكز التكلفة', '2', 'cost_centersm', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (209, 'currency', 'Currencies details', 'العملات', '2', 'currency', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3000, 'screen privilege', 'Screen Privilege', 'صلاحيات الشاشات', '30', 'screen_privilege', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3001, 'transaction privilege', 'Transactions Privilege', 'صلاحيات العمليات', '30', 'transaction_privilege', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3002, 'inputs privilege', 'Inputs Privilege', 'صلاحيات المدخلات', '30', 'inputs_privilege', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3003, 'favorite screen', 'Favorite Screens', 'الشاشات المفضلة', '30', 'favorite_screen', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3004, 'change password', 'Change Password', 'تغير كلمة السر', '30', 'change_password', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3005, 'approvals level', 'Approvals levels', 'مستويات الاعتماد', '30', 'approvals_level', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3006, 'signatuers', 'Signatuers', 'التوقيعات', '30', 'signatuers', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3100, 'closing period', 'Closing Periods', 'إغلاق الفترات', '31', 'closing period', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3101, 'closing year', 'Closing Year', 'أغلاق السنة', '31', 'closing_year', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3102, 'opinig period', 'Opinig Periods', 'افتح الفترات', '31', 'opinig_period', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3103, 'open year', 'Open Year', 'فتح السنة', '31', 'open_year', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3104, 'posting', 'postings', 'الترحيلات', '31', 'posting', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3300, 'database backup', 'Database Backup', 'النسخ الاحتياطي', '33', 'database_backup', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3301, 'restore_backup', 'Restore Backup', 'استرجاع النسخ الاحتياطية', '33', 'restore_backup', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3302, 'update database', 'Update Database', 'تحديث قاعدة البيانات', '33', 'update_database', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3303, 'dictionary', 'Dictionary', 'القاموس', '33', 'dictionary', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3400, 'censorship', 'Censorship', 'الرقابة', '34', 'r_censorship', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3401, 'entry logs', 'Entry Logs', 'سجلات الدخول', '34', 'entry_logs', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (3402, 'privilege report', 'Privilege\'s Reports', 'تقارير الصلاحيات', '34', 'privilege_report', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4000, 'accouintig parameter', 'Accouintig Parameters', 'متغيرات الحسابات', '40', 'accouintig_parameter', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4001, ' type journal voucher', ' Types Of Journal Voucher', 'أنواع قيود اليومية', '40', ' type_journal_voucher', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4002, 'typoe of receipt voucher', 'Typoes of Receipts Voucher', 'أنواع  سندات القبض', '40', 'typoe_receipt_voucher', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4003, 'typoe of payment voucher', 'Typoes Of Payment Voucher', 'أنواع  سندات الصرف', '40', 'typoe_payment_voucher', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4004, 'opening balance', 'Opening Balance', 'الارصدة الافتتاحية', '40', 'opening_balance', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4005, 'box', 'Boxs', 'الصناديق', '40', 'box', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4006, 'bank', 'Banks', 'البنوك', '40', 'bank', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4007, 'cheque book', 'Cheque Book', 'دفت الشيكات', '40', 'cheque_book', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4100, 'journal rquest', 'Journal Vouchers Rquests', 'طلبات القيود اليومية', '41', 'journals_rquest', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4101, 'receipt rquest', 'Receipt Vouchers Rquests', 'طلبات سندات القبض', '41', 'receipt_rquest', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4102, 'payment request', 'Payment Vouchers Request', 'طلبات سندات الصرف', '41', 'payment_request', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4103, 'journal voucher', 'Journal Vouchers', 'قيود اليومية', '41', 'journals_voucher', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4104, 'receipt voucher', 'Receipt Vouchers ', 'سندات القبض', '41', 'receipt_voucher', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4105, 'payment vouchers', 'Payment Vouchers', 'سندات الصرف', '41', 'payment_vouchers', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4200, 'report account', 'Report   Accounts', 'تقارير الدليل المحاسبي', '42', 'report_account', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4201, 'report journal voucher request', 'Report Journal Voucher Request', 'تقارير طلب قيود اليومية', '42', 'report_journal_voucher_request', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4202, 'report  payment', 'Report  Payment  Request', 'تقارير طلب سند الصرف', '42', 'report_payment', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4203, 'report receipt', 'Report Receipt Request', 'تقارير طلب سند القبض', '42', 'report_receipt', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4204, 'report journal voucher', 'Report  Journal Voucher', 'تقارير قيود اليومية', '42', 'report_journal_voucher', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4205, 'report receipt', 'Report Receipts', 'تقارير سند القبض', '42', 'report_receipt', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4206, 'report  payment', 'Report  Payments', 'تقارير سند الصرف', '42', 'report_payment', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4207, 'report due cheque', 'Report  Due Cheque', 'تقارير - الشيكات المستحقة للسداد', '42', 'report_due_cheque', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4208, 'report  posted and unposted report', 'Report - Posted and Unposted Reports', 'تقارير السندات المرحلة وغير المرحلة', '42', 'report_posted_unposted_report', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4209, 'report account statement', 'Report   Account Statement', 'تقارير كشف الحساب', '42', 'report_account_statement', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4210, 'report cash move', 'Report   Cash Move ', 'تقارير حركة الصناديق ', '42', 'report_cash_move', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4211, 'report bank move', 'Report Bank Move', 'تقارير حركة البنوك', '42', 'report_bank_move', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4212, 'report cost_center_tran', 'Report    Cost_center_trans', 'تقارير عمليات مراكز التكلفة ', '42', 'report_cost_center_tran', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4213, 'report opening balance', 'Report - Opening Balance', 'تقارير الأرصدة الإفتتاحية ', '42', 'report_opening_balance', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4214, 'report   journal ', 'Report  Journals', 'تقارير اليومية العامة', '42', 'report_journal', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4215, 'report trial balance', 'Report - Trial Balance', 'تقارير ميزان المراجعة', '42', 'report_trial_balance', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4216, 'report balance sheet', 'Report  Balance Sheet', 'تقارير الميزانية العمومية', '42', 'report_balance_sheet', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4217, 'report profit and Loss', 'Report Profit And Loss', 'تقارير الأرباح والخسائر', '42', 'report_profit_Loss', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4218, 'report balance', 'Report   Balances', 'تقارير الأرصدة', '42', 'report_balance', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4219, 'report non moving account', 'Report - Non Moving Accounts', 'تقارير الحسابات الغير متحركة', '42', 'report_non_moving_account', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4220, 'report bank reconciliation', 'Report   Bank Reconciliation', 'تقارير - تسوية البنوك', '42', 'report_bank_reconciliation', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4221, 'report cash and banks', 'Report   Cash and Banks', 'تقارير الصناديق والبنوك', '42', 'report_cash_bank', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4222, 'report final list and cash flow', 'Report Final List And Cash Flow', 'تقارير القوائم والتدفقات الختامية', '42', 'report_final_list_cash_flow', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (4223, 'cheques report', 'Cheques Reports ', 'تقارير الشيكات', '42', 'cheques_report', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5000, 'inv parameter', 'Inv  Parameters', 'متغيرات المخزون', '50', 'inv_parameter', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5001, 'measurement', 'Measurement', 'وحدات القياس', '50', 'measurement', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5002, 'item type', 'Item Types', 'أنواع الأصناف', '50', 'item_type', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5003, 'outgoing type', 'Outgoing Types', 'أنواع الصرف', '50', 'outgoing_type', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5004, 'incoming type', 'Incoming Types', 'أنواع التوريد', '50', 'incoming_type', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5005, 'pricing level', 'Pricing Levels', 'مستويات التسعيرة', '50', 'pricing_level', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5006, 'group detail', 'Group Details', 'بيانات المجموعات الرئيسية', '50', 'group_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5007, 'sub group', 'Sub Group', 'المجموعات الفرعية', '50', 'sub_group', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5008, 'warehouse detail', 'Warehouse Details', 'بيانات المخازن', '50', 'warehouse_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5009, 'bin detail', 'Bin Details', 'بيانات الرفوف', '50', 'bin_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5010, 'item detail', 'Item Details', 'بيانات الأصناف', '50', 'item_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5011, 'item pricing', 'Item Pricing', 'تسعيرة الأصناف', '50', 'item_pricing', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5012, 'stock opining', 'Stock Opining', 'المخزون الإفتتاحي', '50', 'stock_opining', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5013, 'conn inv acc by gl ', 'Conn. Inv. Acc. By Gl ', 'ربط حسابات المخزون بالأستاذ العام', '50', 'conn_inv_acc_by_gl ', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5100, 'incoming stock', 'Incoming Stock', 'التوريد المخزني', '51', 'incoming_stock', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5101, 'outgoing stock', 'Outgoing Stock', 'أمر الصرف المخزني', '51', 'outgoing_stock', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5102, 'warehouse transfer', 'Warehouse Transfer', 'التحويل المخزني', '51', 'warehouse_transfer', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5103, 'warehouse received', 'Warehouse Trns. Received', 'إستلام تحويل مخزني', '51', 'warehouse_received', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5104, 'manual inventory', 'Manual Inventory', 'الجرد اليدوي', '51', 'manual_inventory', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5105, 'stk_adjustment', 'Stk_Adjustment', 'تسوية مخزون', '51', 'stk_adjustment', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5200, 'report group detail', 'Reports- Group Details', 'تقارير بيانات المجموعات', '52', 'report_group_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5201, 'report item detail', 'reports- Item Details', 'تقارير بيانات الأصناف', '51', 'report item detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5202, 'report pricing detail', 'Reports Pricing Details', 'تقارير تسعيرة الأصناف', '52', 'report_pricing_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5203, 'report bin detail', 'reports Bin Details', 'تقارير مواقع الأصناف', '52', 'report_bin_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5204, 'report  open stock', 'Reports- Open Stock', 'تقارير المخزون الإفتتاحي', '52', 'report_open_stock', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5205, 'reports incoming stock', 'Reports- Incoming Stock', 'تقارير التوريد المخزني', '52', 'reports_incoming_stock', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5206, 'report outgoing report', 'Reports  Outgoing reports', 'تقارير  الصرف المخزنية', '52', 'report_outgoing_report', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5207, 'report transfer and rec Detail', 'Reports- Transfer and Rec. Details', 'تقارير التحويل والإستلام المخزني', '52', 'report_transfer_and_rec_Detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5208, 'report manual inventory', 'Reports- Manual Inventory', 'تقارير الجرد اليدوي', '52', 'report_manual_inventory', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5209, 'report stock adjustment', 'Reports- Stock Adjustment', 'تقارير تسوية المخزون', '52', 'report_stock_adjustment', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5210, 'report stock detail', 'Reports stock Details', 'تقارير المخزون', '52', 'report_stock_detai', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (5211, 'report turn over ratio', 'Reports- Turn Over Ratio', 'تقارير معدل الدوران', '52', 'report_turn_over_ratio', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6000, 'ap. parameters', 'AP. Parameters', 'متغيرات نظام الموردين', '60', 'ap_parameters', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6001, 'vendor group', 'Vendor Groups', 'مجموعة الموردين', '60', 'vendor_group', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6003, 'vendor deatil', 'Vendors Deatils', 'بيانات الموردين', '60', 'vendor_deatil', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6004, 'type of purchase invoice', 'Type Of Purchase Invoices', 'أنواع فواتير  المشتريات ', '60', 'type of purchase_invoice', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6005, 'vendor open bal', 'Vendor Open Bal', 'الأرصدة الإفتتاحية للموردين', '60', 'vendor_open_bal', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6100, 'purchase request', 'Purchase Request', 'طلبات الشراء', '61', 'purchase_request', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6101, 'purchase order', 'Purchase Order', 'purchase_order', '61', '#', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6102, 'purchase invoice', 'Purchase Invoice', 'فاتورة المشتريات ', '61', 'purchase_invoice', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6103, 'purchase return invoice', 'Purchase Return Invoice', 'فاتورة مردود المشتريات', '61', 'purchase_return_invoice', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6104, 'additional discount for purchase', 'Additional Discount For Purchase', 'الخصومات الاضافية لفواتيرالمشتريات', '61', 'additional_discount_for_purchase', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6106, 'payment voucher', 'Payment Voucher', 'سند الصرف', '61', 'payment_voucher', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6107, 'vendor installment adjustment', 'Vendor Installment Adjustment', 'تسوية أقساط الموردين', '61', 'vendor_installment_adjustment', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6200, 'report vendor detail', 'Reports Vendor Details', 'تقارير بيانات الموردين', '62', 'report_vendor_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6201, 'report vendor statement', 'Reports Vendor Statement', 'تقارير كشوفات حساب الموردين', '62', 'report_vendor_statement', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6202, 'report purchase order', 'Rports Purchase Order', 'تقارير أوامر الشراء', '62', 'report_purchase_order', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6203, 'report purchase request', ' Rports Purchase Request', 'تقارير طلبات الشراء', '62', 'report_purchase_request', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6204, 'report purchase invoice', 'Reports Purchase Invoice', 'تقارير فواتير المشتريات', '62', 'report_purchase_invoice', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6205, 'report purchase return invoice', 'Reports Purchase Return Invoice', 'تقارير مردود المشتريات', '62', 'report_purchase_return_invoice', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6206, 'report purchasing cost', 'Reports Purchasing Cost', 'تقارير تكاليف المشتريات', '62', 'report_purchasing_cost', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6208, 'report  payment', 'Report  Payments', 'تقارير سند الصرف', '62', 'report_payment', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6209, 'add discount report for purchase', 'Add Discount Reports For Purchase', 'تقارير الخصومات الإضافية للمشتريات', '62', 'add_discount_report_for_purchase', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6210, 'report vendor open balance', 'Reports Vendor Open Balance', 'تقارير الأرصدة الإفتتاحية للموردين', '62', 'report_vendor_open_balance', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (6212, 'vat report', 'Vat. Reports', 'تقارير ضريبة القيمة المضافة', '62', 'vat_report', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7000, 'ar parameters', 'AR. Parameters', 'متغيرات نظام العملاء', '70', 'ar_parameters', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7002, 'type des devis', 'Types des devis', 'أنواع عروض الأسعار', '70', 'type_des_devis', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7004, 'quotation type', 'Quotation Types', 'أنواع طلبات العملاء', '70', 'quotation_type', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7006, 'type de factures de vente', 'Types de factures de vente', 'أنواع فواتير المبيعات', '70', 'type_de_factures_de_vente', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7010, 'customer group', 'Customer groups', 'مجموعة العملاء', '70', 'customer_group', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7014, 'customer detail', 'Customer Details', 'بيانات العملاء', '70', 'customer_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7016, 'salesman detail', 'Salesman details', 'بيانات مندوبي المبيعات', '70', 'salesman_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7018, 'collector detail', 'Collector details', 'بيانات المحصلين', '70', 'collector_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7020, 'credit card detail', 'Credit Card Detail', 'بيانات بطاقات الائتمان', '70', 'credit_card_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7024, 'sale discount ', 'Sales Discount ', 'ترميز الخصم', '70', 'sale_discount ', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7026, 'promotion quotation', 'Promotion Quotations', 'العروض الترويجية', '70', 'promotion_quotation', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7028, 'item pricing', 'Item Pricing', 'تسعيرة الأصناف', '70', 'item_pricing', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7030, 'open balance for customer', 'Open balance for Customer', 'الأرصدة الإفتتاحية للعملاء', '70', 'open_balance_for_customer', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7032, 'sale charge', 'Sales Charges', 'أعباء المبيعات', '70', 'sale_charge', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7100, 'quotation', 'Quotations', 'عروض الأسعار', '71', 'quotation', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7102, 'sale Order', 'Sales Orders', 'طلبات العملاء', '71', 'sale_Order', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7104, 'sale invoice', 'Sales Invoice', 'فواتير المبيعات', '71', 'sale_invoice', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7106, 'bill outgoing', 'Bills Outgoing', 'إذن صرف فاتورة مبيعات', '71', 'bill_outgoing', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7108, 'sale return invoice', 'Sales Return Invoice', 'فواتير مردود المبيعات', '71', 'sale_return_invoice', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7110, 'income sale return', 'Income Sales Return', 'إذن إرجاع فاتورة مردود', '71', 'income_sale_return', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7114, 'receipt voucher', 'Receipt voucher', 'سند القبض', '71', 'receipt_voucher', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7120, 'indebtedness scheduling', 'Indebtedness Scheduling', 'جدولة المديونية', '71', 'indebtedness_scheduling', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7200, 'daily sale report', 'Daily Sales Reports', 'تقارير المبيعات اليومية', '72', 'daily_sale_report', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7201, 'sale net ', 'Sales Net ', 'تقارير صافي المبيعات', '72', 'sale_net ', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7202, 'profit margin', 'Profit Margin', 'تقارير هامش الربح', '72', 'profit_margin', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7203, 'report sale invoice', 'Reports Sales Invoice', 'تقارير فواتير المبيعات', '72', 'report_sale_invoice', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7204, 'report sale return invoice', 'Reports Sales Return Invoice', 'تقارير مردود المبيعات', '72', 'report_sale_return_invoice', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7205, 'report sale order', 'Reports Sales Orders', 'تقارير طلبات العملاء', '72', 'report_sale_order', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7206, 'report quotation', 'Reports Quotations', 'تقاريرعروض الأسعار', '72', 'report_quotation', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7207, 'customer statement', 'Customer Statement', 'تقارير كشف حساب العملاء', '72', 'customer_statement', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7208, 'report open balance for customer', 'Reports Open balance for Customer', 'تقارير الأرصدة الإفتتاحية للعملاء', '72', 'report_open_balance_for_customer', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7209, 'report bill outgoing', 'Reports Bills Outgoing', 'تقارير إذن صرف فاتورة المبيعات', '72', 'report_bill_outgoing', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7210, 'report income sale return  ', 'Reports Income Sales Return  ', 'تقارير إذن إرجاع فاتورة المردود', '72', 'report income sale return ', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7211, 'report customer aging', 'Reports Customer Aging', 'تقارير أعمار الديون', '72', 'report_customer_aging', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7212, 'report promotion quotation', 'Reports Promotion Quotations', 'تقارير العروض الترويجية', '72', 'report_promotion_quotation', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7213, 'report customer indebtedness', 'Reports Customer Indebtedness', 'تقارير مديونية العملاء', '72', 'report_customer|_indebtedness', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7215, 'sale invoice dated', 'Sales Invoices Dated', 'فواتير المبيعات المستحقة للسداد', '72', 'sale_invoice_dated', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7216, 'report customer detail', 'Reports Customer Details', 'تقارير بيانات العملاء', '72', 'report_customer_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7217, 'report salesman detail', 'Reports Salesman Details', 'تقارير مندوبي المبيعات', '72', 'report_salesman_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7218, 'report collector detail', 'Reports Collector Details', 'تقارير بيانات المحصلين', '72', 'report_collector_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7219, 'report sale charge ', 'Reports Sales Charges ', 'تقارير أعباءالمبيعات', '72', 'report_sale charge', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7220, 'item order', 'Items Order', 'تقارير الأصناف المطلوبة', '72', 'item_order ', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (7250, 'vat report', 'Vat reports', 'تقارير ضريبة القيمة المضافة', '72', 'vat_report', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10300, 'censorship', 'Censorship', 'الرقابة', '103', 'r_censorship', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10301, 'entry logs', 'Entry Logs', 'سجلات الدخول', '103', 'entry_logs', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10302, 'privilege report', 'Privilege\'s Reports', 'تقارير الصلاحيات', '103', 'privilege_report', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10401, 'report account statement', 'Report   Account Statement', 'تقارير كشف الحساب', '104', 'report_account_statement', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10402, 'report profit and Loss', 'Report Profit And Loss', 'تقارير الأرباح والخسائر', '104', 'report_profit_Loss', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10403, 'report balance', 'Report   Balances', 'تقارير الأرصدة', '104', 'report_balance', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10404, 'report final list and cash flow', 'Report Final List And Cash Flow', 'تقارير القوائم والتدفقات الختامية', '42', 'report_final_list_cash_flow', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10405, 'accounting graphic', 'Accounting Graphic', 'رسوم بيانية', '104', 'accounting_graphic', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10500, 'report stock detail', 'Reports stock Details', 'تقارير المخزون', '105', 'report_stock_detai', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10501, 'stock graphic', 'Stock Graphic', 'رسوم بيانية', '105', 'stock_graphic', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10502, 'report pricing detail', 'Reports Pricing Details', 'تقارير تسعيرة الأصناف', '105', 'report_pricing_detail', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10601, 'purchase graphic', 'Purchase Graphic', 'رسوم بيانية', '106', 'purchase_graphic', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10700, 'profit margin', 'Profit Margin', 'تقارير هامش الربح', '107', 'profit_margin', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10701, 'sale graphic', 'Sales Graphic', 'رسوم بيانية', '107', 'sale_graphic', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10702, 'sale net ', 'Sales Net ', 'تقارير صافي المبيعات', '107', 'sale_net ', 1);
INSERT INTO `forms` (`id`, `name`, `label`, `label_ar`, `parent_id`, `link`, `statuse`) VALUES (10704, 'item order', 'Items Order', 'تقارير الأصناف المطلوبة', '107', 'item_order ', 1);


#
# TABLE STRUCTURE FOR: gl_para
#

DROP TABLE IF EXISTS `gl_para`;

CREATE TABLE `gl_para` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chk_br_box` int(11) NOT NULL DEFAULT '1',
  `use_box_in_jor` int(11) NOT NULL DEFAULT '1',
  `save_zero` int(11) NOT NULL DEFAULT '1',
  `acc_use_level` int(11) NOT NULL DEFAULT '5',
  `use_approv` int(11) NOT NULL DEFAULT '1',
  `req_mond` int(11) NOT NULL DEFAULT '0',
  `no_depend_on_type` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `gl_para` (`id`, `chk_br_box`, `use_box_in_jor`, `save_zero`, `acc_use_level`, `use_approv`, `req_mond`, `no_depend_on_type`, `ad_u_id`, `ad_date`, `up_u_id`, `up_date`, `up_count`) VALUES (1, 1, 0, 0, 5, 1, 1, 1, 1, '2019-09-12', 1, '2019-09-12', 11);


#
# TABLE STRUCTURE FOR: in_comming_dtl
#

DROP TABLE IF EXISTS `in_comming_dtl`;

CREATE TABLE `in_comming_dtl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `in_com_id` int(11) NOT NULL,
  `yr_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_unit` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `cost` double NOT NULL,
  `stock_no` int(11) NOT NULL,
  `vat_amt` double NOT NULL,
  `amt` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: in_comming_mst
#

DROP TABLE IF EXISTS `in_comming_mst`;

CREATE TABLE `in_comming_mst` (
  `in_com_id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(50) NOT NULL,
  `in_com_desc` varchar(255) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `ref_no` varchar(20) NOT NULL,
  `amt` double NOT NULL,
  `vat_amt` double NOT NULL,
  `req_no` int(11) NOT NULL,
  `yr_no` int(4) NOT NULL,
  `br_no` int(11) NOT NULL,
  `reseveir` varchar(50) NOT NULL,
  `posted` int(11) NOT NULL DEFAULT '0',
  `posted_u_id` int(11) DEFAULT NULL,
  `posted_date` date DEFAULT NULL,
  `cost_center` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `in_com_date` date NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`in_com_id`,`yr_no`,`br_no`,`comp_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: input_privlage
#

DROP TABLE IF EXISTS `input_privlage`;

CREATE TABLE `input_privlage` (
  `u_id` int(11) NOT NULL,
  `input_type` int(11) NOT NULL,
  `input_no` int(11) NOT NULL AUTO_INCREMENT,
  `input_name` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`input_no`,`input_type`,`u_id`),
  KEY `u_id` (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: inv_para
#

DROP TABLE IF EXISTS `inv_para`;

CREATE TABLE `inv_para` (
  `id` int(11) NOT NULL DEFAULT '1',
  `yr_no` int(4) NOT NULL,
  `cost_type` int(11) NOT NULL,
  `auto_item_no` int(11) NOT NULL,
  `use_service_itrm` int(11) NOT NULL,
  `use_cost_center` int(11) NOT NULL,
  `use_expire_date` int(11) NOT NULL,
  `defualt_price_for_all` int(11) NOT NULL,
  `allow_incom_expire` int(11) NOT NULL,
  `barcod_right` varchar(20) NOT NULL,
  `barcod_right_len` int(11) NOT NULL,
  `barcode_left` varchar(20) NOT NULL,
  `barcode_left_len` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`yr_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item
#

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `item` (`id`, `name`, `parent_id`) VALUES (2, 'm1', 0);
INSERT INTO `item` (`id`, `name`, `parent_id`) VALUES (3, 'm2', 1);
INSERT INTO `item` (`id`, `name`, `parent_id`) VALUES (4, 'm1', 0);
INSERT INTO `item` (`id`, `name`, `parent_id`) VALUES (5, 'm2', 1);
INSERT INTO `item` (`id`, `name`, `parent_id`) VALUES (6, 'n1', 0);
INSERT INTO `item` (`id`, `name`, `parent_id`) VALUES (7, 'n2', 3);
INSERT INTO `item` (`id`, `name`, `parent_id`) VALUES (8, 'n1', 0);
INSERT INTO `item` (`id`, `name`, `parent_id`) VALUES (9, 'n2', 3);


#
# TABLE STRUCTURE FOR: item_dtl
#

DROP TABLE IF EXISTS `item_dtl`;

CREATE TABLE `item_dtl` (
  `item_code` varchar(20) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `item_unit` int(11) NOT NULL DEFAULT '1',
  `main_unit` int(11) NOT NULL DEFAULT '0',
  `sale_unit` int(11) NOT NULL DEFAULT '0',
  `purch_unit` int(11) NOT NULL DEFAULT '0',
  `inv_unit` int(11) NOT NULL DEFAULT '0',
  `unit_size` int(11) NOT NULL DEFAULT '1',
  `statuse` int(11) NOT NULL DEFAULT '1',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  `min_border` double DEFAULT NULL,
  `max_border` double DEFAULT NULL,
  UNIQUE KEY `barcode` (`barcode`),
  KEY `item_code` (`item_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item_group
#

DROP TABLE IF EXISTS `item_group`;

CREATE TABLE `item_group` (
  `id` varchar(10) NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `group_e_name` varchar(100) DEFAULT NULL,
  `group_i_code` varchar(6) DEFAULT NULL,
  `item_group_type` int(11) NOT NULL DEFAULT '0',
  `parent` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(5) DEFAULT NULL,
  `ad_date` date DEFAULT NULL,
  `up_u_id` int(5) DEFAULT NULL,
  `up_date` date DEFAULT NULL,
  `UP_CNT` int(10) DEFAULT NULL,
  `cmp_no` int(3) NOT NULL,
  `brn_no` int(6) NOT NULL,
  `yr_no` int(4) DEFAULT NULL,
  `ad_trmnl` varchar(50) DEFAULT NULL,
  `up_trmnl` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item_movement
#

DROP TABLE IF EXISTS `item_movement`;

CREATE TABLE `item_movement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(20) NOT NULL,
  `yr_no` int(4) NOT NULL,
  `br_n0` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `stock_no` int(11) NOT NULL,
  `cost_center` int(11) NOT NULL,
  `mov_ref` int(11) NOT NULL,
  `mov_type` int(11) NOT NULL,
  `item_unit` varchar(50) NOT NULL,
  `cost` double NOT NULL,
  `price` double NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '1',
  `mov_date` date NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item_shelf
#

DROP TABLE IF EXISTS `item_shelf`;

CREATE TABLE `item_shelf` (
  `shelf_cod` int(11) NOT NULL AUTO_INCREMENT,
  `wh_code` int(11) NOT NULL,
  `item_code` varchar(20) NOT NULL,
  `shelf_name` varchar(50) NOT NULL,
  `shelf_e_name` varchar(50) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(11) NOT NULL,
  `ud_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(11) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`shelf_cod`),
  KEY `item_code` (`item_code`),
  KEY `wh_code` (`wh_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item_type
#

DROP TABLE IF EXISTS `item_type`;

CREATE TABLE `item_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_type_nmae` varchar(50) NOT NULL,
  `item_type_e_nmae` varchar(50) NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '1',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: itm_mst
#

DROP TABLE IF EXISTS `itm_mst`;

CREATE TABLE `itm_mst` (
  `item_code` varchar(20) NOT NULL,
  `item_name` varchar(256) NOT NULL,
  `item_e_name` varchar(256) NOT NULL,
  `item_group_id` varchar(10) NOT NULL,
  `item_sub_group_id` varchar(10) NOT NULL,
  `item_desc` varchar(256) NOT NULL,
  `item_service` int(11) NOT NULL DEFAULT '0',
  `use_decimal` int(11) NOT NULL DEFAULT '0',
  `use_vat` int(11) NOT NULL DEFAULT '0',
  `vat_percent` int(11) NOT NULL,
  `cash` int(11) NOT NULL DEFAULT '0',
  `retourn` int(11) NOT NULL DEFAULT '1',
  `use_expire_date` int(11) DEFAULT '0',
  `item_type` int(11) NOT NULL,
  `avg_cost` double NOT NULL,
  `primary_cost` double NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '1',
  `no_sale` int(11) DEFAULT '0',
  `logo` blob NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_code`),
  KEY `item_group_id` (`item_group_id`),
  KEY `item_sub_group_id` (`item_sub_group_id`),
  KEY `item_type` (`item_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: journal_dtl
#

DROP TABLE IF EXISTS `journal_dtl`;

CREATE TABLE `journal_dtl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL,
  `br_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `br_year` int(11) NOT NULL DEFAULT '2019',
  `j_no` int(11) DEFAULT NULL,
  `r_no` int(11) DEFAULT NULL,
  `p_no` int(11) DEFAULT NULL,
  `cr_no` int(11) DEFAULT NULL,
  `cp_no` int(11) DEFAULT NULL,
  `box_bank_no` int(11) DEFAULT NULL,
  `post_type` int(11) NOT NULL,
  `j_type` int(11) NOT NULL,
  `acoutn_no` int(11) NOT NULL,
  `acount_type` int(11) NOT NULL,
  `acount_analys` int(11) NOT NULL,
  `currency` varchar(7) NOT NULL,
  `cost_no` int(11) DEFAULT NULL,
  `currency_rate` float NOT NULL,
  `debt` double NOT NULL,
  `credit` double NOT NULL DEFAULT '0',
  `jd_desc` varchar(256) NOT NULL,
  `date_maturity` date NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '1',
  `ad_date` date NOT NULL,
  `posted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `m_id` (`m_id`),
  KEY `j_no` (`j_no`),
  KEY `r_no` (`r_no`),
  KEY `p_no` (`p_no`),
  KEY `cp_no` (`cp_no`),
  KEY `cr_no` (`cr_no`),
  KEY `currency` (`currency`),
  KEY `acoutn_no` (`acoutn_no`),
  KEY `br_id` (`br_id`),
  CONSTRAINT `journal_dtl_ibfk_1` FOREIGN KEY (`m_id`) REFERENCES `journal_mst` (`id`),
  CONSTRAINT `journal_dtl_ibfk_2` FOREIGN KEY (`j_no`) REFERENCES `journal_mst` (`j_no`),
  CONSTRAINT `journal_dtl_ibfk_3` FOREIGN KEY (`r_no`) REFERENCES `journal_mst` (`r_no`),
  CONSTRAINT `journal_dtl_ibfk_4` FOREIGN KEY (`p_no`) REFERENCES `journal_mst` (`p_no`),
  CONSTRAINT `journal_dtl_ibfk_5` FOREIGN KEY (`cp_no`) REFERENCES `journal_mst` (`cp_no`),
  CONSTRAINT `journal_dtl_ibfk_6` FOREIGN KEY (`cr_no`) REFERENCES `journal_mst` (`cr_no`),
  CONSTRAINT `journal_dtl_ibfk_7` FOREIGN KEY (`currency`) REFERENCES `currency` (`cur_code`),
  CONSTRAINT `journal_dtl_ibfk_8` FOREIGN KEY (`acoutn_no`) REFERENCES `accountingtree` (`account_number`),
  CONSTRAINT `journal_dtl_ibfk_9` FOREIGN KEY (`br_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=850 DEFAULT CHARSET=utf8;

INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (14, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 0, '1', '250000', '0', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-01-01', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (15, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'SAR', 0, '1', '250000', '0', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (16, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101004, 1, 0, 'SAR', 0, '1', '250000', '0', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (17, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 0, '1', '250000', '0', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (18, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12301001, 5, 0, 'SAR', 0, '1', '250000', '0', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (19, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 31104001, 1, 0, 'SAR', 0, '1', '250000', '0', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (20, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 2, 'SAR', 0, '1', '0', '250000', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (21, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '500000', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (22, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 22201002, 1, 0, 'SAR', 0, '1', '0', '5000000', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (23, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 22201001, 1, 0, 'SAR', 0, '1', '0', '250000', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (24, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12301002, 1, 0, 'SAR', 0, '1', '4500000', '0', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (25, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 0, '1', '250000', '0', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (26, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 22201001, 1, 0, 'SAR', 0, '1', '0', '250000', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (27, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 22201002, 1, 0, 'SAR', 0, '1', '0', '5000000', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (28, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '500000', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (29, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '250000', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (30, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 31104001, 1, 0, 'SAR', 0, '1', '250000', '0', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (31, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12301001, 5, 0, 'SAR', 0, '1', '250000', '0', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (32, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 0, '1', '250000', '0', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (33, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101004, 1, 0, 'SAR', 0, '1', '250000', '0', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (34, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'SAR', 0, '1', '250000', '0', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (35, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12301002, 1, 0, 'SAR', 0, '1', '4500000', '0', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (36, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 22501001, 1, 0, 'SAR', 0, '1', '200000', '0', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (37, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 22501002, 1, 0, 'SAR', 0, '1', '0', '200000', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (83, 5, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, 1, 2, 1, 22201002, 1, 0, 'YER', 1, '0.0067', '0', '1500000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (84, 5, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, 1, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (85, 5, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, 1, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (86, 5, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, 1, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (87, 5, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, 1, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (88, 5, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, 1, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (89, 5, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, 1, 2, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '150000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (90, 5, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, 1, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-04-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (91, 5, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, 1, 2, 1, 12101001, 2, 1, 'SAR', NULL, '1', '24511650', '0', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (101, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 12101002, 2, 2, 'SAR', 0, '1', '0', '500000', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (102, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 12101003, 1, 0, 'SAR', 0, '1', '0', '500000', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (103, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 12501001, 1, 0, 'SAR', 0, '1', '0', '500000', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (104, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 12301002, 1, 0, 'SAR', 0, '1', '0', '500000', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (105, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 32102001, 1, 0, 'SAR', 0, '1', '0', '500000', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (106, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '500000', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (107, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 12102001, 3, 2, 'SAR', 0, '1', '0', '500000', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (108, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 41101001, 1, 0, 'SAR', 0, '1', '0', '500000', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (109, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 22501001, 1, 0, 'SAR', 0, '1', '0', '500000', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (110, 6, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, 1, 2, 1, 12101001, 2, 1, 'SAR', 1, '1', '4500000', '0', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (111, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (112, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '12000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (113, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 12102001, 3, 1, 'SAR', 1, '1', '0', '10000000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (114, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (115, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (116, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (117, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (118, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (119, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 12101003, 1, 0, 'SAR', 1, '1', '0', '120000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (120, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 22201002, 1, 0, 'YER', 1, '0.0067', '0', '1500000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (121, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '150000', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (122, 7, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 2, 'SAR', NULL, '1', '34643650', '0', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (152, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12101003, 1, 0, 'SAR', 0, '1', '1575000', '0', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (153, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1575000', '0', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (154, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12101004, 1, 0, 'SAR', 0, '1', '1575000', '0', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (155, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 32101001, 1, 0, 'SAR', 0, '1', '1575000', '0', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (156, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 32801001, 1, 0, 'SAR', 0, '1', '1575000', '0', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (157, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 32201003, 1, 0, 'SAR', 0, '1', '1575000', '0', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (158, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 32601001, 1, 0, 'SAR', 0, '1', '1575000', '0', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (159, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1575000', '0', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (160, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '1575001', '0', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (161, 9, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12101001, 2, 1, 'SAR', NULL, '1', '0', '14175001', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2020-01-02', 1, '2019-01-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (162, 10, 8, 1, 2019, NULL, NULL, 10000003, NULL, NULL, 2, 3, 1, 22301001, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (163, 10, 8, 1, 2019, NULL, NULL, 10000003, NULL, NULL, 2, 3, 1, 12101002, 2, 2, 'SAR', NULL, '1', '0', '1200000', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (192, 8, 1, 1, 2019, NULL, NULL, 10000001, NULL, NULL, 1, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '1000000', '0', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (193, 8, 1, 1, 2019, NULL, NULL, 10000001, NULL, NULL, 1, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (194, 8, 1, 1, 2019, NULL, NULL, 10000001, NULL, NULL, 1, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (195, 8, 1, 1, 2019, NULL, NULL, 10000001, NULL, NULL, 1, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '19000000', '0', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (196, 8, 1, 1, 2019, NULL, NULL, 10000001, NULL, NULL, 1, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (197, 8, 1, 1, 2019, NULL, NULL, 10000001, NULL, NULL, 1, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (198, 8, 1, 1, 2019, NULL, NULL, 10000001, NULL, NULL, 1, 3, 1, 22301001, 1, 0, 'SAR', 0, '1', '1200000', '0', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (199, 8, 1, 1, 2019, NULL, NULL, 10000001, NULL, NULL, 1, 3, 1, 12901001, 1, 0, 'SAR', 0, '1', '120000', '0', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (200, 8, 1, 1, 2019, NULL, NULL, 10000001, NULL, NULL, 1, 3, 1, 12101001, 2, 1, 'SAR', 0, '1', '0', '36587000', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2020-01-02', 1, '2019-02-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (201, 12, 1, 1, 2019, NULL, NULL, NULL, 10000001, NULL, 1, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '150000', ' استلام شيك رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (202, 12, 1, 1, 2019, NULL, NULL, NULL, 10000001, NULL, 1, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', ' استلام شيك رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (203, 12, 1, 1, 2019, NULL, NULL, NULL, 10000001, NULL, 1, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', ' استلام شيك رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (204, 12, 1, 1, 2019, NULL, NULL, NULL, 10000001, NULL, 1, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', ' استلام شيك رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (205, 12, 1, 1, 2019, NULL, NULL, NULL, 10000001, NULL, 1, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', ' استلام شيك رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (206, 12, 1, 1, 2019, NULL, NULL, NULL, 10000001, NULL, 1, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', ' استلام شيك رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (207, 12, 1, 1, 2019, NULL, NULL, NULL, 10000001, NULL, 1, 5, 1, 32101001, 1, 0, 'SAR', 1, '1', '0', '190000000', ' استلام شيك رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (208, 12, 1, 1, 2019, NULL, NULL, NULL, 10000001, NULL, 1, 5, 1, 12101001, 2, 1, 'SAR', NULL, '1', '590160000', '0', ' استلام شيك رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (209, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (210, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (211, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (212, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (213, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 22501002, 1, 0, 'YER', 0, '0.0067', '150000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (214, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (215, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (216, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (217, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (218, 13, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000001, 2, 4, 1, 12102001, 3, 2, 'SAR', NULL, '1', '0', '61645000', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (219, 14, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000002, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '4000000', '0', ' صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '2019-12-30', 1, '2019-06-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (220, 14, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000002, 1, 4, 1, 21101001, 1, 0, 'SAR', 0, '1', '4000000', '0', ' صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (221, 14, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000002, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '4000000', '0', ' صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (222, 14, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000002, 1, 4, 1, 32202001, 1, 0, 'SAR', 0, '1', '4000000', '0', ' صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (223, 14, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000002, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '4000000', '0', ' صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (224, 14, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000002, 1, 4, 1, 12102001, 3, 1, 'SAR', NULL, '1', '0', '20000000', ' صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (234, 16, 8, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 2, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (235, 16, 8, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 2, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (236, 16, 8, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 2, 5, 1, 32101001, 1, 0, 'SAR', 1, '1', '0', '190000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (237, 16, 8, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 2, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (238, 16, 8, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (239, 16, 8, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 2, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (240, 16, 8, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 2, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (241, 16, 8, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', NULL, '1', '590160000', '0', ' استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (266, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (267, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (268, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-05-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (269, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (270, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (271, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (272, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (273, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (274, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (275, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (276, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (277, 4, 8, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (278, 18, 1, 1, 2019, NULL, 10000004, NULL, NULL, NULL, 1, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (279, 18, 1, 1, 2019, NULL, 10000004, NULL, NULL, NULL, 1, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (280, 18, 1, 1, 2019, NULL, 10000004, NULL, NULL, NULL, 1, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (281, 18, 1, 1, 2019, NULL, 10000004, NULL, NULL, NULL, 1, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (282, 18, 1, 1, 2019, NULL, 10000004, NULL, NULL, NULL, 1, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (283, 18, 1, 1, 2019, NULL, 10000004, NULL, NULL, NULL, 1, 2, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '150000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (284, 18, 1, 1, 2019, NULL, 10000004, NULL, NULL, NULL, 1, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (285, 18, 1, 1, 2019, NULL, 10000004, NULL, NULL, NULL, 1, 2, 1, 12101001, 2, 1, 'SAR', 0, '1', '24501600', '0', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (293, 17, 8, 1, 2019, NULL, NULL, NULL, 10000003, NULL, 2, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (294, 17, 8, 1, 2019, NULL, NULL, NULL, 10000003, NULL, 2, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (295, 17, 8, 1, 2019, NULL, NULL, NULL, 10000003, NULL, 2, 5, 1, 32101001, 1, 0, 'SAR', 1, '1', '0', '190000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (296, 17, 8, 1, 2019, NULL, NULL, NULL, 10000003, NULL, 2, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (297, 17, 8, 1, 2019, NULL, NULL, NULL, 10000003, NULL, 2, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-04-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (298, 17, 8, 1, 2019, NULL, NULL, NULL, 10000003, NULL, 2, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (299, 17, 8, 1, 2019, NULL, NULL, NULL, 10000003, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (300, 17, 8, 1, 2019, NULL, NULL, NULL, 10000003, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 0, '1', '590160000', '0', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (346, 19, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (347, 19, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (348, 19, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (349, 19, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (350, 19, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (351, 19, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (352, 19, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (353, 19, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (354, 19, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 12102001, 3, 2, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (355, 15, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000003, 2, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (356, 15, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000003, 2, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-07-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (357, 15, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000003, 2, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (358, 15, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000003, 2, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (359, 15, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000003, 2, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (360, 15, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000003, 2, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (361, 15, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000003, 2, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (362, 15, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000003, 2, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (363, 15, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000003, 2, 4, 1, 12102001, 3, 2, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (364, 20, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (365, 20, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-03-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (366, 20, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (367, 20, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (368, 20, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (369, 20, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (370, 20, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (371, 20, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (372, 20, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم1478 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (373, 21, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (374, 21, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-07-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (375, 21, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (376, 21, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (377, 21, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (378, 21, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (379, 21, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (380, 21, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (381, 21, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم145278 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (382, 22, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (383, 22, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-10-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (384, 22, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (385, 22, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (386, 22, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (387, 22, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (388, 22, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (389, 22, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (390, 22, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم1478 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (391, 23, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (392, 23, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (393, 23, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (394, 23, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (395, 23, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (396, 23, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (397, 23, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (398, 23, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (399, 23, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (400, 24, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (401, 24, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (402, 24, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (403, 24, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (404, 24, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (405, 24, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (406, 24, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (407, 24, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (408, 24, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (409, 25, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (410, 25, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (411, 25, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (412, 25, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (413, 25, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (414, 25, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (415, 25, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (416, 25, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (417, 25, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (418, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (419, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (420, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (421, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (422, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (423, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (424, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (425, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (426, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (427, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (428, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (429, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (430, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (431, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (432, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (433, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (434, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (435, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (454, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (455, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (456, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (457, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (458, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (459, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (460, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (461, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (462, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (463, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-11-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (464, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (465, 28, 8, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (466, 29, 1, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (467, 29, 1, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (468, 29, 1, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (469, 29, 1, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (470, 29, 1, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (471, 29, 1, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '150000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (472, 29, 1, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (473, 29, 1, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 12101001, 2, 1, 'SAR', 0, '1', '24501600', '0', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (481, 31, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (482, 31, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (483, 31, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 32101001, 1, 0, 'SAR', 1, '1', '0', '190000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (484, 31, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (485, 31, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (486, 31, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (487, 31, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (488, 31, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 0, '1', '590160000', '0', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2020-01-02', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (498, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (499, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (500, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (501, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (502, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (503, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (504, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (505, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (506, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (507, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (508, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (509, 33, 8, 1, 2019, 10000006, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (510, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (511, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (512, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (513, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (514, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (515, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (516, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (517, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (518, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (519, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (520, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (521, 34, 8, 1, 2019, 10000007, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (522, 35, 1, 1, 2019, NULL, 10000006, NULL, NULL, NULL, 1, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (523, 35, 1, 1, 2019, NULL, 10000006, NULL, NULL, NULL, 1, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (524, 35, 1, 1, 2019, NULL, 10000006, NULL, NULL, NULL, 1, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (525, 35, 1, 1, 2019, NULL, 10000006, NULL, NULL, NULL, 1, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (526, 35, 1, 1, 2019, NULL, 10000006, NULL, NULL, NULL, 1, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (527, 35, 1, 1, 2019, NULL, 10000006, NULL, NULL, NULL, 1, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (528, 35, 1, 1, 2019, NULL, 10000006, NULL, NULL, NULL, 1, 2, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '150000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (529, 35, 1, 1, 2019, NULL, 10000006, NULL, NULL, NULL, 1, 2, 1, 12101001, 2, 1, 'SAR', 0, '1', '24501600', '0', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-01-01', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (530, 36, 1, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 1, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '1000000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (531, 36, 1, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 1, 3, 1, 12901001, 1, 0, 'SAR', 0, '1', '120000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (532, 36, 1, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 1, 3, 1, 22301001, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (533, 36, 1, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 1, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (534, 36, 1, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 1, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (535, 36, 1, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 1, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '19000000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (536, 36, 1, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 1, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (537, 36, 1, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 1, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (538, 36, 1, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 1, 3, 1, 12101001, 2, 1, 'SAR', 0, '1', '0', '36587000', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-01-01', 1, '2019-08-22', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (557, 37, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000013, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (558, 37, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000013, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (559, 37, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000013, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (560, 37, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000013, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (561, 37, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000013, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (562, 37, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000013, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (563, 37, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000013, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (564, 37, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000013, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (565, 37, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000013, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2020-02-06', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (574, 38, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (575, 38, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 32101001, 1, 0, 'SAR', 1, '1', '0', '190000000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (576, 38, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '150000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (577, 38, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (578, 38, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (579, 38, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (580, 38, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (581, 38, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 0, '1', '590160000', '0', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2020-04-16', 1, '2019-08-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (582, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (583, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (584, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (585, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (586, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (587, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (588, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (589, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 22201001, 1, 0, 'SAR', 1, '1', '0', '100000', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (590, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201004, 1, 0, 'SAR', 1, '1', '47', '0', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (591, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 1, '1', '200000', '0', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (592, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (593, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (594, 1, 1, 1, 2019, 10000001, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (595, 11, 8, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 2, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '10000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (596, 11, 8, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 2, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (597, 11, 8, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 2, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (598, 11, 8, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 2, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (599, 11, 8, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 2, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (600, 11, 8, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 2, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '19000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (601, 11, 8, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 2, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '0', '44267000', ' سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-01-01', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (602, 32, 1, 1, 2019, NULL, NULL, 10000006, NULL, NULL, 1, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '1000000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (603, 32, 1, 1, 2019, NULL, NULL, 10000006, NULL, NULL, 1, 3, 1, 12901001, 1, 0, 'SAR', 0, '1', '120000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (604, 32, 1, 1, 2019, NULL, NULL, 10000006, NULL, NULL, 1, 3, 1, 22301001, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (605, 32, 1, 1, 2019, NULL, NULL, 10000006, NULL, NULL, 1, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (606, 32, 1, 1, 2019, NULL, NULL, 10000006, NULL, NULL, 1, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (607, 32, 1, 1, 2019, NULL, NULL, 10000006, NULL, NULL, 1, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (608, 32, 1, 1, 2019, NULL, NULL, 10000006, NULL, NULL, 1, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (609, 32, 1, 1, 2019, NULL, NULL, 10000006, NULL, NULL, 1, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '19000000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (610, 32, 1, 1, 2019, NULL, NULL, 10000006, NULL, NULL, 1, 3, 1, 12101001, 2, 1, 'SAR', 0, '1', '0', '36587000', 'طلب سند  الصرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-01-01', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (611, 30, 8, 1, 2019, NULL, NULL, 10000005, NULL, NULL, 2, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '10000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (612, 30, 8, 1, 2019, NULL, NULL, 10000005, NULL, NULL, 2, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (613, 30, 8, 1, 2019, NULL, NULL, 10000005, NULL, NULL, 2, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (614, 30, 8, 1, 2019, NULL, NULL, 10000005, NULL, NULL, 2, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (615, 30, 8, 1, 2019, NULL, NULL, 10000005, NULL, NULL, 2, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (616, 30, 8, 1, 2019, NULL, NULL, 10000005, NULL, NULL, 2, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '19000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (617, 30, 8, 1, 2019, NULL, NULL, 10000005, NULL, NULL, 2, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '0', '44267000', ' سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-01-01', 1, '2019-08-05', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (618, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (619, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (620, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (621, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (622, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (623, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (624, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (625, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (626, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (627, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (628, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (629, 39, 8, 1, 2019, 10000008, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (630, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (631, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (632, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (633, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (634, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (635, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (636, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (637, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (638, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (639, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (640, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (641, 40, 8, 1, 2019, 10000009, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-08-26', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (651, 41, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000014, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (652, 41, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000014, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (653, 41, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000014, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (654, 41, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000014, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (655, 41, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000014, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (656, 41, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000014, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (657, 41, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000014, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (658, 41, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000014, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (659, 41, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000014, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '0000-00-00', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (669, 42, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000015, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (670, 42, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000015, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (671, 42, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000015, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (672, 42, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000015, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (673, 42, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000015, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (674, 42, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000015, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (675, 42, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000015, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (676, 42, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000015, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (677, 42, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000015, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '0000-00-00', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (678, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (679, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (680, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (681, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (682, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (683, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (684, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (685, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (686, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (687, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (688, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (689, 43, 8, 1, 2019, 10000010, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (702, 45, 1, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 1, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (703, 45, 1, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 1, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (704, 45, 1, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 1, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (705, 45, 1, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 1, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (706, 45, 1, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 1, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (707, 45, 1, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 1, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (708, 45, 1, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 1, 2, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '150000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (709, 45, 1, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 1, 2, 1, 12101001, 2, 1, 'SAR', 0, '1', '24501600', '0', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '0000-00-00', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (710, 46, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 2, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (711, 46, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 2, 5, 1, 32101001, 1, 0, 'SAR', 1, '1', '0', '190000000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (712, 46, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 2, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '150000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (713, 46, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 2, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (714, 46, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 2, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (715, 46, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (716, 46, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 2, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (717, 46, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 2, 5, 1, 12101002, 3, 2, 'SAR', 0, '1', '590160000', '0', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '0000-00-00', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (718, 47, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 2, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (719, 47, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 2, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (720, 47, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 2, 5, 1, 32101001, 1, 0, 'SAR', 1, '1', '0', '190000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (721, 47, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 2, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (722, 47, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 2, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (723, 47, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 2, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (724, 47, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (725, 47, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 2, 5, 1, 12101002, 3, 2, 'SAR', 0, '1', '590160000', '0', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '0000-00-00', 1, '2019-09-03', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (738, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (739, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (740, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (741, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (742, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (743, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (744, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (745, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (746, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (747, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (748, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (749, 48, 8, 1, 2019, 10000012, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (750, 49, 1, 1, 0, NULL, NULL, NULL, NULL, 10000016, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (751, 49, 1, 1, 0, NULL, NULL, NULL, NULL, 10000016, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (752, 49, 1, 1, 0, NULL, NULL, NULL, NULL, 10000016, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (753, 49, 1, 1, 0, NULL, NULL, NULL, NULL, 10000016, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (754, 49, 1, 1, 0, NULL, NULL, NULL, NULL, 10000016, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (755, 49, 1, 1, 0, NULL, NULL, NULL, NULL, 10000016, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (756, 49, 1, 1, 0, NULL, NULL, NULL, NULL, 10000016, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (757, 49, 1, 1, 0, NULL, NULL, NULL, NULL, 10000016, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (758, 49, 1, 1, 0, NULL, NULL, NULL, NULL, 10000016, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '0000-00-00', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (768, 50, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000017, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (769, 50, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000017, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (770, 50, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000017, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (771, 50, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000017, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (772, 50, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000017, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (773, 50, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000017, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (774, 50, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000017, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (775, 50, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000017, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (776, 50, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000017, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '0000-00-00', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (777, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (778, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (779, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (780, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (781, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (782, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (783, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (784, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (785, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (786, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (787, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (788, 51, 8, 1, 2019, 10000013, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 0, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (789, 52, 1, 1, 2019, NULL, 10000008, NULL, NULL, NULL, 1, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (790, 52, 1, 1, 2019, NULL, 10000008, NULL, NULL, NULL, 1, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (791, 52, 1, 1, 2019, NULL, 10000008, NULL, NULL, NULL, 1, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (792, 52, 1, 1, 2019, NULL, 10000008, NULL, NULL, NULL, 1, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (793, 52, 1, 1, 2019, NULL, 10000008, NULL, NULL, NULL, 1, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (794, 52, 1, 1, 2019, NULL, 10000008, NULL, NULL, NULL, 1, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (795, 52, 1, 1, 2019, NULL, 10000008, NULL, NULL, NULL, 1, 2, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '150000', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (796, 52, 1, 1, 2019, NULL, 10000008, NULL, NULL, NULL, 1, 2, 1, 12101001, 2, 1, 'SAR', 0, '1', '24501600', '0', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '0000-00-00', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (797, 53, 1, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 1, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '1000000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (798, 53, 1, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 1, 3, 1, 12901001, 1, 0, 'SAR', 0, '1', '120000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (799, 53, 1, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 1, 3, 1, 22301001, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (800, 53, 1, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 1, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (801, 53, 1, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 1, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (802, 53, 1, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 1, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '19000000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (803, 53, 1, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 1, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (804, 53, 1, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 1, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (805, 53, 1, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 1, 3, 1, 12101001, 2, 1, 'SAR', 0, '1', '0', '36587000', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '0000-00-00', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (806, 54, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 2, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (807, 54, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 2, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (808, 54, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 2, 5, 1, 32101001, 1, 0, 'SAR', 1, '1', '0', '190000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (809, 54, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 2, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (810, 54, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 2, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (811, 54, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 2, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (812, 54, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (813, 54, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 2, 5, 1, 12101002, 3, 2, 'SAR', 0, '1', '590160000', '0', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '0000-00-00', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (814, 55, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000018, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (815, 55, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000018, 1, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (816, 55, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000018, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (817, 55, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000018, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (818, 55, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000018, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', ' صرف شيك رقم12 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (819, 55, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000018, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (820, 55, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000018, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (821, 55, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000018, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '2019-12-30', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (822, 55, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000018, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '60640000', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', '0000-00-00', 1, '2019-09-04', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (823, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (824, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 41102001, 1, 0, 'SAR', 1, '1', '0', '50000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (825, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'YER', 1, '0.0067', '1500000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (826, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (827, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (828, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (829, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (830, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (831, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '47', '0', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (832, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (833, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (834, 44, 8, 1, 2019, 10000011, NULL, NULL, NULL, NULL, NULL, 1, 1, 31103001, 1, 0, 'SAR', 1, '1', '100000', '0', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', '2019-12-30', 1, '0000-00-00', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (835, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (836, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (837, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201005, 1, 0, 'SAR', 1, '1', '21172', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (838, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (839, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '311122', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (840, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 1, '1', '200000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (841, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '1000000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (842, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 31105001, 1, 0, 'SAR', 1, '1', '100000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (843, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (844, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201004, 1, 0, 'SAR', 1, '1', '47', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (845, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (846, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (847, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101004, 1, 0, 'SAR', 1, '1', '1000000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (848, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101005, 1, 0, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);
INSERT INTO `journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_date`, `posted`) VALUES (849, 56, 1, 1, 2019, 10000014, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1, '2019-09-10', 0);


#
# TABLE STRUCTURE FOR: journal_mst
#

DROP TABLE IF EXISTS `journal_mst`;

CREATE TABLE `journal_mst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `br_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `br_year` int(11) NOT NULL DEFAULT '2019',
  `box_bank_no` int(11) DEFAULT NULL,
  `j_no` int(11) DEFAULT NULL,
  `r_no` int(11) DEFAULT NULL,
  `p_no` int(11) DEFAULT NULL,
  `cr_no` int(11) DEFAULT NULL,
  `cp_no` int(11) DEFAULT NULL,
  `j_date` date NOT NULL,
  `come_from` int(11) DEFAULT NULL,
  `come_from_no` int(11) DEFAULT NULL,
  `j_return` int(11) DEFAULT NULL,
  `j_use` varchar(50) DEFAULT NULL,
  `amt` double NOT NULL,
  `j_type` int(11) NOT NULL,
  `ref` varchar(50) DEFAULT NULL,
  `j_desc` varchar(256) NOT NULL,
  `post_type` int(11) NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '0',
  `m_date_maturity` date DEFAULT '2050-08-01',
  `extrnal_post` int(11) DEFAULT NULL,
  `posted` int(11) NOT NULL DEFAULT '0',
  `posted_u_id` int(11) NOT NULL,
  `posted_date` date NOT NULL,
  `ad_u_id` int(11) DEFAULT NULL,
  `ad_date` date DEFAULT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) DEFAULT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`j_type`,`post_type`) USING BTREE,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `j_no` (`j_no`),
  UNIQUE KEY `r_no` (`r_no`),
  UNIQUE KEY `p_no` (`p_no`),
  UNIQUE KEY `cr_no` (`cr_no`),
  UNIQUE KEY `cp_no` (`cp_no`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4;

INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 1, 1, 2019, NULL, 10000001, NULL, NULL, NULL, NULL, '2019-08-25', 1, 10000001, NULL, 'الادارة العامة', '571172', 1, '', 'طلب قيد رقم 1 لشهر8 لسنة 2019 عملية 1', 1, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-25', '192.168.1.14moshtaq', 2);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 1, 1, 2019, NULL, 10000002, NULL, NULL, NULL, NULL, '2019-08-01', 0, 0, NULL, 'الادارة العامة', '6000000', 1, '1200', ' قيد رقم 2 لشهر8 لسنة 2019 عملية 2', 1, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (3, 8, 1, 2019, NULL, 10000003, NULL, NULL, NULL, NULL, '2019-08-01', 0, 0, NULL, 'الادارة العامة', '6200000', 1, '1200', ' قيد رقم 3 لشهر8 لسنة 2019 عملية 2 فرع مكة', 1, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (4, 8, 1, 2019, NULL, 10000004, NULL, NULL, NULL, NULL, '2019-08-08', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', 1, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (5, 1, 1, 2019, 1, NULL, 10000001, NULL, NULL, NULL, '2019-08-01', 1, 10000001, NULL, 'الادارة العامة', '24511650', 1, '125', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-01', '192.168.1.10moshtaq', 2);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (6, 1, 1, 2019, 1, NULL, 10000002, NULL, NULL, NULL, '2019-08-01', NULL, 0, NULL, 'الادارة العامة', '4500000', 1, '2019', 'سندات القبض  رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-01', '192.168.1.10moshtaq', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (7, 8, 1, 2019, 2, NULL, 10000003, NULL, NULL, NULL, '2019-08-01', 1, 10000006, NULL, 'الادارة العامة', '34643650', 1, '6125', ' سند رقم3 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 2, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (8, 1, 1, 2019, 1, NULL, NULL, 10000001, NULL, NULL, '2019-08-01', 1, 10000001, NULL, 'الادارة العامة', '36587000', 1, '1236', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 3, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-01', '192.168.1.10moshtaq', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (9, 1, 1, 2019, 1, NULL, NULL, 10000002, NULL, NULL, '2019-08-01', NULL, 0, NULL, '', '14175001', 1, '', 'سند صرف رقم2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 3, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-01', '192.168.1.10moshtaq', 2);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10, 8, 1, 2019, 2, NULL, NULL, 10000003, NULL, NULL, '2019-08-01', 1, 10000005, NULL, 'الادارة العامة', '1200000', 1, '1236', ' سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 3, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (11, 8, 1, 2019, 2, NULL, NULL, 10000004, NULL, NULL, '2019-08-25', 1, 10000006, NULL, 'الادارة العامة', '44267000', 1, '120', ' سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 3, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-25', '192.168.1.14moshtaq', 4);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12, 1, 1, 2019, 1, NULL, NULL, NULL, 10000001, NULL, '2019-08-01', 1, 10000001, NULL, 'mangement', '590160000', 1, '1025', ' استلام شيك رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 5, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (13, 1, 1, 2019, 2, NULL, NULL, NULL, NULL, 10000001, '2019-08-01', 1, 10000002, NULL, 'management department', '61645000', 1, '101', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (14, 8, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000002, '2019-08-01', 0, 0, NULL, '', '20000000', 1, '', ' صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (15, 8, 1, 2019, 2, NULL, NULL, NULL, NULL, 10000003, '2019-08-08', 1, 10000001, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 2);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (16, 8, 1, 2019, 2, NULL, NULL, NULL, 10000002, NULL, '2019-08-01', 1, 10000003, NULL, 'mangement', '590160000', 1, '1025', ' استلام شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 5, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (17, 8, 1, 2019, 2, NULL, NULL, NULL, 10000003, NULL, '2019-08-08', 0, 0, NULL, 'mangement', '590160000', 1, '1025', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 5, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (18, 1, 1, 2019, 1, NULL, 10000004, NULL, NULL, NULL, '2019-08-08', 0, 0, NULL, 'الادارة العامة', '24501600', 1, '125', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (19, 8, 1, 2019, 2, NULL, NULL, NULL, NULL, 10000004, '2019-08-08', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم1 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 3);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (20, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000005, '2019-08-08', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم1478 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (21, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000006, '2019-08-08', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم145278 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000007, '2019-08-08', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم1478 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (23, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000008, '2019-08-08', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (24, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000009, '2019-08-08', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (25, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000010, '2019-08-08', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (26, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000011, '2019-08-08', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (27, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000012, '2019-08-08', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم108 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (28, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, NULL, '2019-08-08', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', 1, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (29, 1, 1, 2019, 1, NULL, 10000005, NULL, NULL, NULL, '2019-08-08', 0, 0, NULL, 'الادارة العامة', '24501600', 1, '125', '  سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (30, 8, 1, 2019, 2, NULL, NULL, 10000005, NULL, NULL, '2019-08-25', 0, 0, NULL, 'الادارة العامة', '44267000', 1, '120', ' سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 3, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', 1, '2019-08-25', '192.168.1.14moshtaq', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31, 8, 1, 2019, 2, NULL, NULL, NULL, 10000004, NULL, '2019-08-08', 0, 0, NULL, 'mangement', '590160000', 1, '1025', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 5, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32, 1, 1, 2019, 1, NULL, NULL, 10000006, NULL, NULL, '2019-08-25', 1, 10000002, NULL, 'الادارة العامة', '36587000', 1, '1236', 'طلب سند  الصرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 3, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-18', '192.168.1.3moshtaq', 1, '2019-08-25', '192.168.1.14moshtaq', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (33, 8, 1, 2019, NULL, 10000006, NULL, NULL, NULL, NULL, '2019-08-22', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم4 لشهر8 لسنة 2019 عملية فرع مكة', 1, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-22', '192.168.1.14moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (34, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, NULL, '2019-08-22', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', 1, 1, '2019-12-31', 1, 0, 0, '0000-00-00', 1, '2019-08-22', '192.168.1.14moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (35, 1, 1, 2019, 1, NULL, 10000006, NULL, NULL, NULL, '2019-08-22', 0, 0, NULL, 'الادارة العامة', '24501600', 1, '125', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-08-22', '192.168.1.14moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (36, 1, 1, 2019, 1, NULL, NULL, 10000007, NULL, NULL, '2019-08-22', 0, 0, NULL, 'الادارة العامة', '36587000', 1, '1236', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 3, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-08-22', '192.168.1.14moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (37, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000013, '2019-08-22', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-08-22', '192.168.1.14moshtaq', 1, '2019-08-22', '192.168.1.14moshtaq', 2);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (38, 8, 1, 2019, 2, NULL, NULL, NULL, 10000005, NULL, '2019-08-22', 0, 0, NULL, 'mangement', '590160000', 1, '1025', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 5, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-08-22', '192.168.1.14moshtaq', 1, '2019-08-22', '192.168.1.14moshtaq', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (39, 8, 1, 2019, NULL, 10000008, NULL, NULL, NULL, NULL, '2019-08-26', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', 1, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-08-26', '192.168.1.14moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (40, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, NULL, '2019-08-26', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', 1, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-08-26', '192.168.1.14moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (41, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000014, '2019-09-03', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (42, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000015, '2019-09-03', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (43, 8, 1, 2019, NULL, 10000010, NULL, NULL, NULL, NULL, '2019-09-03', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', 1, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (44, 8, 1, 2019, NULL, 10000011, NULL, NULL, NULL, NULL, '2019-09-04', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', 1, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (45, 1, 1, 2019, 1, NULL, 10000007, NULL, NULL, NULL, '2019-09-03', 0, 0, NULL, 'الادارة العامة', '24501600', 1, '125', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (46, 8, 1, 2019, 2, NULL, NULL, NULL, 10000006, NULL, '2019-09-03', 0, 0, NULL, 'mangement', '590160000', 1, '1025', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 5, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (47, 8, 1, 2019, 2, NULL, NULL, NULL, 10000007, NULL, '2019-09-03', 0, 0, NULL, 'mangement', '590160000', 1, '1025', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 5, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (48, 8, 1, 2019, NULL, 10000012, NULL, NULL, NULL, NULL, '2019-09-04', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', 1, 0, '2019-12-30', 1, 0, 0, '0000-00-00', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (49, 1, 1, 0, 1, NULL, NULL, NULL, NULL, 10000016, '2019-09-04', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (50, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000017, '2019-09-04', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', 1);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (51, 8, 1, 2019, NULL, 10000013, NULL, NULL, NULL, NULL, '2019-09-04', 0, 0, NULL, 'الادارة العامة', '471172', 1, '', '  قيد رقم7 لشهر8 لسنة 2019 عملية فرع مكة', 1, 0, '2019-12-30', 1, 0, 0, '0000-00-00', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (52, 1, 1, 2019, 1, NULL, 10000008, NULL, NULL, NULL, '2019-09-04', 0, 0, NULL, 'الادارة العامة', '24501600', 1, '125', '  سند رقم6 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (53, 1, 1, 2019, 1, NULL, NULL, 10000008, NULL, NULL, '2019-09-04', 0, 0, NULL, 'الادارة العامة', '36587000', 1, '1236', 'طلب سند  الصرف رقم 7 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 3, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (54, 8, 1, 2019, 2, NULL, NULL, NULL, 10000008, NULL, '2019-09-04', 0, 0, NULL, 'mangement', '590160000', 1, '1025', ' استلام شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 5, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (55, 1, 1, 2019, 1, NULL, NULL, NULL, NULL, 10000018, '2019-09-04', 0, 0, NULL, 'management department', '60640000', 1, '101', ' صرف شيك رقم13 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض', 4, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `box_bank_no`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `j_date`, `come_from`, `come_from_no`, `j_return`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `statuse`, `m_date_maturity`, `extrnal_post`, `posted`, `posted_u_id`, `posted_date`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (56, 1, 1, 2019, NULL, 10000014, NULL, NULL, NULL, NULL, '2019-09-10', 1, 10000002, NULL, 'الادارة العامة', '1732294', 1, '65', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', 1, 1, '2019-12-30', 1, 0, 0, '0000-00-00', 2, '2019-09-10', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);


#
# TABLE STRUCTURE FOR: languages
#

DROP TABLE IF EXISTS `languages`;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_name` varchar(50) NOT NULL,
  `dir` varchar(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lang_name` (`lang_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `languages` (`id`, `lang_name`, `dir`) VALUES (1, 'arabic', 'rtl');
INSERT INTO `languages` (`id`, `lang_name`, `dir`) VALUES (2, 'english', 'ltr');


#
# TABLE STRUCTURE FOR: level_price
#

DROP TABLE IF EXISTS `level_price`;

CREATE TABLE `level_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price_name` varchar(50) NOT NULL,
  `price_e_name` varchar(50) NOT NULL,
  `dfault` int(11) NOT NULL DEFAULT '0',
  `currency` int(11) NOT NULL,
  `cost_precent_pls` int(11) NOT NULL DEFAULT '1',
  `statuse` int(11) NOT NULL DEFAULT '1',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: login_history
#

DROP TABLE IF EXISTS `login_history`;

CREATE TABLE `login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `trmnl` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: masg
#

DROP TABLE IF EXISTS `masg`;

CREATE TABLE `masg` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `frm` int(11) NOT NULL,
  `too` int(11) NOT NULL,
  `details` varchar(2500) NOT NULL,
  `statuse` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: open_balance
#

DROP TABLE IF EXISTS `open_balance`;

CREATE TABLE `open_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `br_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `br_year` int(11) NOT NULL DEFAULT '2019',
  `extrnal_post` int(11) NOT NULL,
  `acoutn_no` int(11) NOT NULL,
  `acount_type` int(11) NOT NULL,
  `acount_analys` int(11) NOT NULL,
  `currency` varchar(7) NOT NULL,
  `cost_no` int(11) NOT NULL,
  `currency_rate` float NOT NULL,
  `debt` double NOT NULL,
  `credit` double NOT NULL,
  `jd_desc` varchar(256) CHARACTER SET utf8mb4 NOT NULL,
  `date_maturity` date NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(11) DEFAULT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) DEFAULT NULL,
  `up_u_id` int(11) DEFAULT NULL,
  `up_date` date DEFAULT NULL,
  `up_trmnl` varchar(50) DEFAULT NULL,
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `open_balance` (`id`, `br_id`, `comp_id`, `br_year`, `extrnal_post`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`) VALUES (1, 1, 1, 2019, 1, 12101001, 2, 1, 'SAR', 0, '1', '458', '0', '12', '2019-12-30', 1, 1, '2019-08-01', '1', NULL, NULL, NULL);
INSERT INTO `open_balance` (`id`, `br_id`, `comp_id`, `br_year`, `extrnal_post`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`) VALUES (2, 1, 1, 2019, 1, 12101002, 2, 0, 'SAR', 0, '1', '0', '50', '12', '2019-12-30', 1, 1, '2019-08-01', '9', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: open_stock_dtl
#

DROP TABLE IF EXISTS `open_stock_dtl`;

CREATE TABLE `open_stock_dtl` (
  `open_stock_id` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `barcode` varchar(20) DEFAULT NULL,
  `item_unit` varchar(20) NOT NULL,
  `qty` double NOT NULL,
  `cost` double NOT NULL,
  `expire_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: open_stock_mst
#

DROP TABLE IF EXISTS `open_stock_mst`;

CREATE TABLE `open_stock_mst` (
  `open_stock_id` int(11) NOT NULL,
  `yr_no` int(4) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `brn_id` int(11) NOT NULL,
  `wh_code` int(11) NOT NULL,
  `cost_c_no` int(11) NOT NULL,
  `open_date` datetime NOT NULL,
  `ref_no` varchar(10) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`yr_no`,`comp_no`,`brn_id`,`wh_code`),
  UNIQUE KEY `id` (`open_stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: out_comming_dtl
#

DROP TABLE IF EXISTS `out_comming_dtl`;

CREATE TABLE `out_comming_dtl` (
  `id` int(11) NOT NULL,
  `out_com_id` int(11) NOT NULL,
  `yr_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_unit` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `cost` double NOT NULL,
  `stock_no` int(11) NOT NULL,
  `vat_amt` double NOT NULL,
  `amt` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: out_comming_mst
#

DROP TABLE IF EXISTS `out_comming_mst`;

CREATE TABLE `out_comming_mst` (
  `out_com_id` int(11) NOT NULL DEFAULT '0',
  `account` varchar(50) NOT NULL,
  `out_com_desc` varchar(255) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `ref_no` varchar(20) NOT NULL,
  `amt` double NOT NULL,
  `vat_amt` double NOT NULL,
  `req_no` int(11) NOT NULL,
  `posted` int(11) NOT NULL DEFAULT '0',
  `posted_u_id` int(11) NOT NULL,
  `posted_date` date DEFAULT NULL,
  `yr_no` int(4) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `reseveir` varchar(50) NOT NULL,
  `cost_center` int(11) NOT NULL,
  `out_com_date` date NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`out_com_id`,`yr_no`,`br_no`,`comp_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: period
#

DROP TABLE IF EXISTS `period`;

CREATE TABLE `period` (
  `prd_no` int(4) NOT NULL,
  `f_prd` date NOT NULL,
  `t_prd` date NOT NULL,
  `period_year` int(4) NOT NULL,
  `hr_cls` int(1) DEFAULT '0',
  `hr_cls_u_id` int(5) DEFAULT NULL,
  `hr_cls_date` date DEFAULT NULL,
  `inv_cls` int(1) DEFAULT '0',
  `inv_cls_u_id` int(5) DEFAULT NULL,
  `in_cls_date` date DEFAULT NULL,
  `yr_cls` int(1) DEFAULT '0',
  `yr_cls_u_id` int(5) DEFAULT NULL,
  `yr_cls_date` date DEFAULT NULL,
  `yr_account` int(11) NOT NULL,
  `amt` double NOT NULL,
  `fas_cls` int(1) DEFAULT '0',
  `fas_cls_u_id` int(5) DEFAULT NULL,
  `fas_cls_date` date DEFAULT NULL,
  `open_new_yr` int(1) DEFAULT '0',
  `open_new_yr_u_id` int(5) DEFAULT NULL,
  `open_new_yr_date` date DEFAULT NULL,
  `ad_u_id` int(5) DEFAULT NULL,
  `ad_date` date DEFAULT NULL,
  `up_u_id` int(5) DEFAULT NULL,
  `up_date` date DEFAULT NULL,
  `up_count` int(10) DEFAULT '0',
  `ad_trmnl` varchar(256) DEFAULT NULL,
  `up_trmnl` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`prd_no`,`period_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: period_dtl
#

DROP TABLE IF EXISTS `period_dtl`;

CREATE TABLE `period_dtl` (
  `prd_no` int(3) NOT NULL,
  `prd_name` varchar(40) NOT NULL,
  `prd_e_name` varchar(40) DEFAULT NULL,
  `f_date` date DEFAULT NULL,
  `_t_date` date DEFAULT NULL,
  `yr_no` int(4) NOT NULL,
  `close` int(1) DEFAULT '0',
  `account` int(11) NOT NULL,
  `close_date` date NOT NULL,
  `br_no` int(15) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(5) DEFAULT NULL,
  `_up_date` date DEFAULT NULL,
  `up_count` int(10) DEFAULT '0',
  PRIMARY KEY (`prd_no`,`yr_no`,`br_no`),
  UNIQUE KEY `yr_no` (`yr_no`),
  KEY `br_no` (`br_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: post_dtl
#

DROP TABLE IF EXISTS `post_dtl`;

CREATE TABLE `post_dtl` (
  `id` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL,
  `j_no` int(11) NOT NULL,
  `j_type` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `acoutn_no` int(11) NOT NULL,
  `acount_type` int(11) NOT NULL,
  `aount_analys` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `value_currency_change` float NOT NULL,
  `amt` double NOT NULL,
  `jd_desc` varchar(256) NOT NULL,
  `date_maturity` date NOT NULL,
  `br_year` int(11) NOT NULL,
  `cost_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: post_mst
#

DROP TABLE IF EXISTS `post_mst`;

CREATE TABLE `post_mst` (
  `id` int(11) NOT NULL DEFAULT '0',
  `br_id` int(11) NOT NULL,
  `j_no` int(11) NOT NULL,
  `j_date` date NOT NULL,
  `cost_no` int(11) NOT NULL,
  `j_return` int(11) NOT NULL,
  `j_use` varchar(50) NOT NULL,
  `currency` int(11) NOT NULL,
  `value_currency_change` float NOT NULL,
  `amt` double NOT NULL,
  `j_type` int(11) NOT NULL,
  `ref` varchar(50) NOT NULL,
  `ad_year` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL,
  `extrnal_post` int(11) NOT NULL,
  `j_desc` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: region
#

DROP TABLE IF EXISTS `region`;

CREATE TABLE `region` (
  `id` int(11) NOT NULL,
  `region_name` varchar(50) NOT NULL,
  `region_e_name` varchar(50) NOT NULL,
  `city` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `city` (`city`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: req_in_comming_dtl
#

DROP TABLE IF EXISTS `req_in_comming_dtl`;

CREATE TABLE `req_in_comming_dtl` (
  `id` int(11) NOT NULL,
  `in_com_id` int(11) NOT NULL,
  `yr_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_unit` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `cost` double NOT NULL,
  `stock_no` int(11) NOT NULL,
  `vat_amt` double NOT NULL,
  `amt` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: req_in_comming_mst
#

DROP TABLE IF EXISTS `req_in_comming_mst`;

CREATE TABLE `req_in_comming_mst` (
  `in_com_id` int(11) NOT NULL DEFAULT '0',
  `account` varchar(50) NOT NULL,
  `in_com_desc` varchar(255) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `ref_no` varchar(20) NOT NULL,
  `amt` double NOT NULL,
  `vat_amt` double NOT NULL,
  `req_no` int(11) NOT NULL,
  `process` int(11) NOT NULL DEFAULT '0',
  `yr_no` int(4) NOT NULL,
  `br_no` int(11) NOT NULL,
  `reseveir` varchar(50) NOT NULL,
  `cost_center` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `in_com_date` date NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`in_com_id`,`yr_no`,`br_no`,`comp_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: req_journal_dtl
#

DROP TABLE IF EXISTS `req_journal_dtl`;

CREATE TABLE `req_journal_dtl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL,
  `br_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `br_year` int(11) NOT NULL DEFAULT '2019',
  `j_no` int(11) DEFAULT NULL,
  `r_no` int(11) DEFAULT NULL,
  `p_no` int(11) DEFAULT NULL,
  `cr_no` int(11) DEFAULT NULL,
  `cp_no` int(11) DEFAULT NULL,
  `box_bank_no` int(11) DEFAULT NULL,
  `post_type` int(11) NOT NULL,
  `j_type` int(11) NOT NULL,
  `acoutn_no` int(11) NOT NULL,
  `acount_type` int(11) NOT NULL,
  `acount_analys` int(11) NOT NULL,
  `currency` varchar(7) NOT NULL,
  `cost_no` int(11) DEFAULT NULL,
  `currency_rate` float NOT NULL,
  `debt` double NOT NULL,
  `credit` double NOT NULL,
  `jd_desc` varchar(256) CHARACTER SET utf8mb4 NOT NULL,
  `date_maturity` date NOT NULL,
  `process` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `m_id` (`m_id`),
  KEY `acoutn_no` (`acoutn_no`),
  KEY `br_id` (`br_id`),
  KEY `currency` (`currency`),
  CONSTRAINT `req_journal_dtl_ibfk_1` FOREIGN KEY (`m_id`) REFERENCES `req_journal_mst` (`id`),
  CONSTRAINT `req_journal_dtl_ibfk_2` FOREIGN KEY (`acoutn_no`) REFERENCES `accountingtree` (`account_number`),
  CONSTRAINT `req_journal_dtl_ibfk_3` FOREIGN KEY (`br_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `req_journal_dtl_ibfk_4` FOREIGN KEY (`currency`) REFERENCES `currency` (`cur_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3336 DEFAULT CHARSET=utf8;

INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2785, 20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2786, 20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2787, 20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, 5, 1, 32101001, 1, 0, 'SAR', 1, '1', '0', '190000000', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2788, 20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2789, 20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2790, 20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2791, 20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2792, 20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, 5, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '9000000', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2793, 20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, 5, 1, 12101001, 3, 1, 'SAR', 0, '1', '599160000', '0', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2794, 22, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2795, 22, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2796, 22, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2797, 22, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2798, 22, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2799, 22, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '580000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2800, 22, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 31101001, 1, 0, 'YER', 1, '0.0067', '0', '9000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2801, 22, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 0, '1', '400650300', '0', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '0000-00-00', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2839, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2840, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2841, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 32101006, 1, 0, 'SAR', 0, '1', '1400000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2842, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 22501002, 1, 0, 'YER', 0, '0.0067', '150000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2843, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2844, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2845, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2846, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2847, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2848, 26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, 4, 1, 12102001, 3, 2, 'SAR', 1, '1', '0', '61645000', 'طلب صرف شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2849, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201005, 1, 0, 'SAR', 1, '1', '21172', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2850, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '1000000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2851, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2852, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201004, 1, 0, 'SAR', 1, '1', '47', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2853, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '311122', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2854, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2855, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 1, '1', '200000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2856, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101005, 1, 0, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2857, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2858, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2859, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2860, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101004, 1, 0, 'SAR', 1, '1', '1000000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2861, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '1000000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2862, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2863, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 32102001, 1, 0, 'SAR', 1, '1', '1000000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2864, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2865, 3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101004, 1, 0, 'SAR', 1, '1', '100000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2866, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2867, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101005, 1, 0, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2868, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2869, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201004, 1, 0, 'SAR', 1, '1', '47', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2870, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 31105001, 1, 0, 'SAR', 1, '1', '100000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2871, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '1000000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2872, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 1, '1', '200000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2873, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '311122', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2874, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2875, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201005, 1, 0, 'SAR', 1, '1', '21172', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2876, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2877, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2878, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101004, 1, 0, 'SAR', 1, '1', '1000000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2879, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2880, 2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2926, 11, 8, 1, 2019, NULL, NULL, 10000003, NULL, NULL, 1, 3, 1, 22301001, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2927, 11, 8, 1, 2019, NULL, NULL, 10000003, NULL, NULL, 1, 3, 1, 12101001, 2, 1, 'SAR', 0, '1', '0', '1200000', 'طلب سند الصرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2928, 10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2929, 10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2930, 10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12101002, 2, 0, 'SAR', 0, '1', '19000000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2931, 10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2932, 10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2933, 10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 22301001, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2934, 10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12901001, 1, 0, 'SAR', 0, '1', '120000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2935, 10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '1000000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2936, 10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, 3, 1, 12101001, 2, 1, 'SAR', 0, '1', '0', '36587000', 'طلب سند  الصرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2937, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 2, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2938, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 2, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2939, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 2, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2940, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 2, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2941, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 2, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2942, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 2, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2943, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 2, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2944, 27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 2, 4, 1, 12102001, 3, 2, 'SAR', 0, '1', '0', '59240000', 'طلب صرف شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2985, 19, 8, 1, 2019, NULL, 10000011, NULL, NULL, NULL, 2, 2, 1, 12101003, 1, 0, 'SAR', 1, '1', '0', '1400', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2986, 19, 8, 1, 2019, NULL, 10000011, NULL, NULL, NULL, 2, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2987, 19, 8, 1, 2019, NULL, 10000011, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 2, 'SAR', 0, '1', '3000', '0', 'طلب سند رقم 56 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2988, 17, 8, 1, 2019, NULL, 10000010, NULL, NULL, NULL, 2, 2, 1, 12101003, 1, 0, 'SAR', 1, '1', '0', '1400', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2989, 17, 8, 1, 2019, NULL, 10000010, NULL, NULL, NULL, 2, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2990, 17, 8, 1, 2019, NULL, 10000010, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 2, 'SAR', 0, '1', '3000', '0', 'طلب سند رقم 4 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2991, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 12101003, 1, 0, 'SAR', 1, '1', '0', '120000', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2992, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2993, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2994, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2995, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2996, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2997, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2998, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 0, 'SAR', 1, '1', '0', '150000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (2999, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 22201002, 1, 0, 'YER', 1, '0.0067', '0', '1500000', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3000, 16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 2, 'SAR', 0, '1', '24631650', '0', 'طلب سند رقم 4 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3013, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3014, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3015, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3016, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3017, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 12101003, 1, 0, 'SAR', 1, '1', '0', '120000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3018, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 22201002, 1, 0, 'YER', 1, '0.0067', '0', '1500000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3019, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 0, 'SAR', 1, '1', '0', '150000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3020, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3021, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 0, 'SAR', 1, '1', '0', '12000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3022, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 12102001, 3, 1, 'SAR', 1, '1', '0', '10000000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3023, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3024, 14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 2, 'SAR', 0, '1', '34643650', '0', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3025, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '19600000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3026, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 32301002, 1, 0, 'SAR', 1, '1', '0', '190000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3027, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3028, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 31103001, 1, 0, 'SAR', 1, '1', '0', '1960000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3029, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 22301001, 1, 0, 'SAR', 1, '1', '0', '1600000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3030, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 12101003, 1, 0, 'SAR', 1, '1', '0', '120000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3031, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 22201002, 1, 0, 'YER', 1, '0.0067', '0', '1500000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3032, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 12101002, 2, 0, 'SAR', 1, '1', '0', '150000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3033, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 32201006, 1, 0, 'SAR', 1, '1', '0', '1000000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3034, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 12101002, 2, 0, 'SAR', 1, '1', '0', '12000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3035, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 12102001, 3, 1, 'SAR', 1, '1', '0', '10000000', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3036, 8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, 2, 1, 12101001, 2, 1, 'SAR', 0, '1', '34643650', '0', 'طلب سند رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3068, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101004, 1, 0, 'SAR', 1, '1', '1000000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3069, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 31102001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3070, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3071, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3072, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201004, 1, 0, 'SAR', 1, '1', '47', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3073, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 22501002, 1, 0, 'SAR', 0, '1', '0', '100', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3074, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3075, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 1, '1', '200000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3076, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101005, 1, 0, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3077, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 31104001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3078, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301001, 1, 0, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3079, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3080, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201005, 1, 0, 'SAR', 1, '1', '21172', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3081, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3082, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 21102001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3083, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3084, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '1000000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3085, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3086, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 32801001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3087, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3088, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3089, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3090, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3091, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 31104001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3092, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 0, '1', '100', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3093, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 31105001, 1, 0, 'SAR', 1, '1', '100000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3094, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3095, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '311122', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3096, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 22501002, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3097, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101004, 1, 0, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3098, 5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3107, 12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3108, 12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3109, 12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, 3, 1, 12101002, 2, 0, 'SAR', 0, '1', '19000000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3110, 12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3111, 12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3112, 12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, 3, 1, 22301001, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3113, 12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, 3, 1, 12901001, 1, 0, 'SAR', 0, '1', '120000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3114, 12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '1000000', '0', 'طلب سند صرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3115, 12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, 3, 1, 12101001, 2, 1, 'SAR', 0, '1', '0', '36587000', 'طلب سند الصرف رقم 8 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3124, 23, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3125, 23, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3126, 23, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3127, 23, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3128, 23, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3129, 23, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '580000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3130, 23, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 31101001, 1, 0, 'YER', 1, '0.0067', '0', '9000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3131, 23, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, 5, 1, 12101002, 3, 2, 'SAR', 0, '1', '400650300', '0', 'طلب استلام شيك رقم31 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3132, 24, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 1, 5, 1, 31101001, 1, 0, 'YER', 1, '0.0067', '0', '9000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3133, 24, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 1, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '580000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3134, 24, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 1, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3135, 24, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 1, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3136, 24, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 1, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3137, 24, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 1, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3138, 24, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 1, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3139, 24, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 1, 5, 1, 12101001, 2, 1, 'SAR', 0, '1', '400650300', '0', 'طلب استلام شيك رقم351 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '0000-00-00', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3140, 28, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 2, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3141, 28, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 2, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3142, 28, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 2, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3143, 28, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 2, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3144, 28, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 2, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3145, 28, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 2, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3146, 28, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 2, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3147, 28, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 2, 4, 1, 12102001, 3, 2, 'SAR', 0, '1', '0', '59240000', 'طلب صرف شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3201, 29, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 2, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3202, 29, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 2, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3203, 29, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 2, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3204, 29, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 2, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3205, 29, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 2, 4, 1, 12102001, 3, 2, 'SAR', 0, '1', '0', '39600000', 'طلب صرف شيك رقم75 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3214, 30, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3215, 30, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3216, 30, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3217, 30, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3218, 30, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3219, 30, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3220, 30, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3221, 30, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '59240000', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3222, 31, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3223, 31, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3224, 31, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3225, 31, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3226, 31, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3227, 31, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3228, 31, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3229, 31, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '59240000', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3230, 32, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3231, 32, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3232, 32, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3233, 32, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3234, 32, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3235, 32, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3236, 32, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3237, 32, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '59240000', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3238, 25, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 1, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '580000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3239, 25, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 1, 5, 1, 31101001, 1, 0, 'YER', 1, '0.0067', '0', '9000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3240, 25, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 1, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3241, 25, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 1, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3242, 25, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 1, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3243, 25, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 1, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3244, 25, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 1, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3245, 25, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 1, 5, 1, 12101001, 2, 1, 'SAR', 0, '1', '400650300', '0', 'طلب استلام شيك رقم351 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '0000-00-00', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3246, 18, 8, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 2, 3, 1, 12101001, 2, 1, 'SAR', 0, '1', '1500000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3247, 18, 8, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 2, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3248, 18, 8, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 2, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3249, 18, 8, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 2, 3, 1, 12101002, 2, 0, 'SAR', 0, '1', '19000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3250, 18, 8, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 2, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3251, 18, 8, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 2, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3252, 18, 8, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 2, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '10000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3253, 18, 8, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 2, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '0', '45767000', 'طلب سند الصرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3254, 21, 8, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 2, 3, 1, 12101001, 2, 1, 'SAR', 0, '1', '1500000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3255, 21, 8, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 2, 3, 1, 12102001, 3, 1, 'SAR', 0, '1', '10000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3256, 21, 8, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 2, 3, 1, 31103001, 1, 0, 'SAR', 0, '1', '100000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3257, 21, 8, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 2, 3, 1, 12101005, 1, 0, 'SAR', 0, '1', '1967000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3258, 21, 8, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 2, 3, 1, 12101002, 2, 0, 'SAR', 0, '1', '19000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3259, 21, 8, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 2, 3, 1, 22201001, 1, 0, 'SAR', 0, '1', '12000000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3260, 21, 8, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 2, 3, 1, 22201002, 1, 0, 'SAR', 0, '1', '1200000', '0', 'طلب سند صرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3261, 21, 8, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 2, 3, 1, 12101002, 2, 2, 'SAR', 0, '1', '0', '45767000', 'طلب سند الصرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3262, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101004, 1, 0, 'SAR', 1, '1', '1000000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3263, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 41101001, 1, 0, 'SAR', 1, '1', '0', '20100', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3264, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301001, 1, 0, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3265, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101002, 2, 2, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3266, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 31104001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3267, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3268, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3269, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 32101005, 1, 0, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3270, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101004, 1, 0, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3271, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 32801001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3272, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12102001, 3, 1, 'SAR', 1, '1', '200000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3273, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 22501002, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3274, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'SAR', 1, '1', '0', '100000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3275, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3276, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '311122', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3277, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 1, '1', '0', '1000000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3278, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 22501002, 1, 0, 'SAR', 0, '1', '0', '100', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3279, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12501001, 1, 0, 'YER', 1, '0.0067', '0', '150000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3280, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3281, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201004, 1, 0, 'SAR', 1, '1', '47', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3282, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 31105001, 1, 0, 'SAR', 1, '1', '100000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3283, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 21102001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3284, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 1, '1', '150000', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3285, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101005, 1, 0, 'SAR', 0, '1', '100', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3286, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 22301002, 1, 0, 'YER', 1, '0.0067', '0', '10000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3287, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 31108001, 1, 0, 'SAR', 1, '1', '111075', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3288, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 31104001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3289, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 32201005, 1, 0, 'SAR', 1, '1', '21172', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3290, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 31102001, 1, 0, 'SAR', 0, '1', '0', '10', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3291, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 21101001, 1, 0, 'SAR', 1, '1', '0', '300000', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3292, 6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, 1, 1, 12101001, 2, 1, 'SAR', 0, '1', '10', '0', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3293, 33, 8, 1, 2019, NULL, 10000012, NULL, NULL, NULL, 2, 2, 1, 12101003, 1, 0, 'SAR', 1, '1', '0', '1400', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3294, 33, 8, 1, 2019, NULL, 10000012, NULL, NULL, NULL, 2, 2, 1, 31102001, 1, 0, 'SAR', 1, '1', '0', '1600', 'طلب سند رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3295, 33, 8, 1, 2019, NULL, 10000012, NULL, NULL, NULL, 2, 2, 1, 12101002, 2, 2, 'SAR', 0, '1', '3000', '0', 'طلب سند رقم 56 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3304, 35, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 1, 5, 1, 12101004, 1, 0, 'SAR', 1, '1', '0', '580000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3305, 35, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 1, 5, 1, 12501001, 1, 0, 'SAR', 1, '1', '0', '196000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3306, 35, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 1, 5, 1, 12301001, 5, 0, 'SAR', 1, '1', '0', '1960000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3307, 35, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 1, 5, 1, 12101001, 2, 1, 'SAR', 1, '1', '0', '150000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3308, 35, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 1, 5, 1, 12101002, 2, 2, 'SAR', 1, '1', '0', '200000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3309, 35, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 1, 5, 1, 32101002, 1, 0, 'SAR', 1, '1', '0', '1900000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3310, 35, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 1, 5, 1, 31101001, 1, 0, 'YER', 1, '0.0067', '0', '9000000', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '2019-12-30', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3311, 35, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 1, 5, 1, 12101001, 2, 1, 'SAR', 0, '1', '400650300', '0', 'طلب استلام شيك رقم351 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', '0000-00-00', 1);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3312, 36, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3313, 36, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3314, 36, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3315, 36, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3316, 36, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3317, 36, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3318, 36, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3319, 36, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, 4, 1, 12102001, 3, 1, 'SAR', 0, '1', '0', '59240000', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '0000-00-00', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3328, 37, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 12101002, 2, 2, 'SAR', 0, '1', '9600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3329, 37, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 12101005, 1, 0, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3330, 37, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 22201002, 1, 0, 'SAR', 0, '1', '10000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3331, 37, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 32101001, 1, 0, 'SAR', 0, '1', '19600000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3332, 37, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 32102001, 1, 0, 'SAR', 0, '1', '1040000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3333, 37, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 31102001, 1, 0, 'SAR', 0, '1', '1000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3334, 37, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 12101001, 2, 1, 'SAR', 0, '1', '9000000', '0', 'طلب صرف شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', '2019-12-30', 0);
INSERT INTO `req_journal_dtl` (`id`, `m_id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `post_type`, `j_type`, `acoutn_no`, `acount_type`, `acount_analys`, `currency`, `cost_no`, `currency_rate`, `debt`, `credit`, `jd_desc`, `date_maturity`, `process`) VALUES (3335, 37, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, 4, 1, 12102001, 3, 1, 'SAR', NULL, '1', '0', '59240000', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', '0000-00-00', 0);


#
# TABLE STRUCTURE FOR: req_journal_mst
#

DROP TABLE IF EXISTS `req_journal_mst`;

CREATE TABLE `req_journal_mst` (
  `id` int(11) NOT NULL,
  `br_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `br_year` int(11) NOT NULL DEFAULT '2019',
  `j_no` int(11) DEFAULT NULL,
  `r_no` int(11) DEFAULT NULL,
  `p_no` int(11) DEFAULT NULL,
  `cr_no` int(11) DEFAULT NULL,
  `cp_no` int(11) DEFAULT NULL,
  `box_bank_no` int(11) DEFAULT NULL,
  `j_date` date NOT NULL,
  `j_use` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `amt` double NOT NULL,
  `j_type` int(11) NOT NULL,
  `ref` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `j_desc` varchar(256) CHARACTER SET utf8mb4 NOT NULL,
  `post_type` int(11) NOT NULL,
  `process` int(11) NOT NULL DEFAULT '0',
  `j_return` int(11) DEFAULT NULL,
  `m_date_maturity` date DEFAULT '2050-08-01',
  `ad_u_id` int(11) DEFAULT NULL,
  `ad_date` date DEFAULT NULL,
  `ad_trmnl` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `up_u_id` int(11) DEFAULT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `j_no` (`j_no`,`r_no`,`p_no`,`cr_no`,`cp_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 1, 1, 2019, 10000002, NULL, NULL, NULL, NULL, NULL, '2019-08-01', 'الادارة العامة', '1732294', 1, '65', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر', 1, 0, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-01', '192.168.1.10moshtaq', 2);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (3, 8, 1, 2019, 10000003, NULL, NULL, NULL, NULL, NULL, '2019-08-01', 'الادارة العامة', '2732294', 1, '', 'طلب قيد رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 1, 1, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-01', '192.168.1.10moshtaq', 1);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (5, 1, 1, 2019, 10000004, NULL, NULL, NULL, NULL, NULL, '2019-08-08', 'الادارة العامة', '1732464', 1, '', 'طلب قيد رقم 443 لشهر8 لسنة 2019 عملية البناء المستمر', 1, 1, NULL, '2019-12-01', 1, '2019-08-07', '192.168.1.3moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 2);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (6, 1, 1, 2019, 10000005, NULL, NULL, NULL, NULL, NULL, '2019-09-04', 'الادارة العامة', '1732464', 1, '', 'طلب قيد رقم 443 لشهر8 لسنة 2019 عملية البناء المستمر', 1, 1, NULL, '2050-08-01', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (8, 8, 1, 2019, NULL, 10000005, NULL, NULL, NULL, 1, '2019-08-08', 'الادارة العامة', '34643650', 1, '6125', 'طلب سند رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 2, 1, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 2);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (10, 1, 1, 2019, NULL, NULL, 10000002, NULL, NULL, 1, '2019-08-06', 'الادارة العامة', '36587000', 1, '1236', 'طلب سند  الصرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 3, 0, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-06', '192.168.1.3moshtaq', 2);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (11, 8, 1, 2019, NULL, NULL, 10000003, NULL, NULL, 1, '2019-08-06', 'الادارة العامة', '1200000', 1, '1236', 'طلب سند الصرف رقم 1 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 3, 1, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-06', '192.168.1.3moshtaq', 6);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (12, 1, 1, 2019, NULL, NULL, 10000004, NULL, NULL, 1, '2019-08-08', 'الادارة العامة', '36587000', 1, '1236', 'طلب سند الصرف رقم 8 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 3, 1, NULL, '2019-12-01', 1, '2019-08-06', '192.168.1.3moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 2);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (14, 8, 1, 2019, NULL, 10000007, NULL, NULL, NULL, 2, '2019-08-08', 'الادارة العامة', '34643650', 1, '6125', 'طلب سند رقم 2 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 2, 1, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 1);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (16, 8, 1, 2019, NULL, 10000009, NULL, NULL, NULL, 2, '2019-08-08', 'الادارة العامة', '24631650', 1, '125', 'طلب سند رقم 4 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 1);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (17, 8, 1, 2019, NULL, 10000010, NULL, NULL, NULL, 2, '2019-08-08', 'الادارة العامة', '3000', 1, '125', 'طلب سند رقم 4 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 1);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (18, 8, 1, 2019, NULL, NULL, 10000007, NULL, NULL, 2, '2019-09-03', 'الادارة العامة', '45767000', 1, '120', 'طلب سند الصرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 3, 1, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', 4);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (19, 8, 1, 2019, NULL, 10000011, NULL, NULL, NULL, 2, '2019-08-08', 'الادارة العامة', '3000', 1, '125', 'طلب سند رقم 56 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 2);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (20, 1, 1, 2019, NULL, NULL, NULL, 10000002, NULL, 1, '2019-08-01', 'mangement', '599160000', 1, '1025', 'طلب استلام شيك رقم2 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع الرياض ', 5, 1, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', 1, '2019-08-01', '192.168.1.10moshtaq', 1);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (21, 8, 1, 2019, NULL, NULL, 10000008, NULL, NULL, 2, '2019-09-03', 'الادارة العامة', '45767000', 1, '120', 'طلب سند الصرف رقم 5 لشهر8 لسنة 2019 عملية البناء المستمر فرع مكة', 3, 1, NULL, '2050-08-01', 1, '2019-09-03', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (22, 8, 1, 2019, NULL, NULL, NULL, 10000004, NULL, 2, '2019-08-01', 'mangement', '400650300', 1, '1025', 'طلب استلام شيك رقم3 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', 5, 1, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (23, 8, 1, 2019, NULL, NULL, NULL, 10000005, NULL, 2, '2019-08-08', 'mangement', '400650300', 1, '1025', 'طلب استلام شيك رقم31 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', 5, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 1);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (24, 8, 1, 2019, NULL, NULL, NULL, 10000006, NULL, 1, '2019-08-08', 'mangement', '400650300', 1, '1025', 'طلب استلام شيك رقم351 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', 5, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (25, 8, 1, 2019, NULL, NULL, NULL, 10000007, NULL, 1, '2019-08-08', 'mangement', '400650300', 1, '1025', 'طلب استلام شيك رقم351 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', 5, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (26, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000004, 2, '2019-08-01', 'management department', '61645000', 1, '101', 'طلب صرف شيك رقم4 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', 4, 1, NULL, '2019-12-01', 1, '2019-08-01', '192.168.1.10moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (27, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000005, 2, '2019-08-07', 'management department', '59240000', 1, '101', 'طلب صرف شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', 4, 1, NULL, '2019-12-01', 1, '2019-08-07', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (28, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000006, 2, '2019-08-08', 'management department', '59240000', 1, '101', 'طلب صرف شيك رقم5 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', 4, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (29, 1, 1, 2019, NULL, NULL, NULL, NULL, 10000007, 2, '2019-08-08', 'management department', '39600000', 1, '101', 'طلب صرف شيك رقم75 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع الرياض', 4, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 3);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (30, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000008, 1, '2019-08-08', 'management department', '59240000', 1, '101', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', 4, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', 1, '2019-08-08', '192.168.1.3moshtaq', 1);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (31, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000009, 1, '2019-08-08', 'management department', '59240000', 1, '101', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', 4, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (32, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000010, 1, '2019-08-08', 'management department', '59240000', 1, '101', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', 4, 1, NULL, '2019-12-01', 1, '2019-08-08', '192.168.1.3moshtaq', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (33, 8, 1, 2019, NULL, 10000012, NULL, NULL, NULL, 2, '2019-09-04', 'الادارة العامة', '3000', 1, '125', 'طلب سند رقم 56 لشهر8 لسنة 2019 عملية البناء المستمر فرع الرياض', 2, 1, NULL, '2050-08-01', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (35, 8, 1, 2019, NULL, NULL, NULL, 10000008, NULL, 1, '2019-09-04', 'mangement', '400650300', 1, '1025', 'طلب استلام شيك رقم351 لشهر8 لسنة 2019 عملية البناء المستمر101 فرع مكة', 5, 1, NULL, '2050-08-01', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (36, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000011, 1, '2019-09-04', 'management department', '59240000', 1, '101', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', 4, 1, NULL, '2050-08-01', 2, '2019-09-04', '174.136.12.172uscentral428.accountservergroup.com', NULL, '0000-00-00', '', 0);
INSERT INTO `req_journal_mst` (`id`, `br_id`, `comp_id`, `br_year`, `j_no`, `r_no`, `p_no`, `cr_no`, `cp_no`, `box_bank_no`, `j_date`, `j_use`, `amt`, `j_type`, `ref`, `j_desc`, `post_type`, `process`, `j_return`, `m_date_maturity`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (37, 8, 1, 2019, NULL, NULL, NULL, NULL, 10000012, 1, '2019-09-10', 'management department', '59240000', 1, '101', 'طلب صرف شيك رقم55 لشهر8 لسنة 2019 عملية البناء المستمر102 فرع مكة', 4, 1, NULL, '2050-08-01', 1, '2019-09-10', '174.136.12.172uscentral428.accountservergroup.com', 1, '2019-09-10', '174.136.12.172uscentral428.accountservergroup.com', 1);


#
# TABLE STRUCTURE FOR: req_out_comming_dtl
#

DROP TABLE IF EXISTS `req_out_comming_dtl`;

CREATE TABLE `req_out_comming_dtl` (
  `id` int(11) NOT NULL,
  `out_com_id` int(11) NOT NULL,
  `yr_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_unit` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `cost` double NOT NULL,
  `stock_no` int(11) NOT NULL,
  `vat_amt` double NOT NULL,
  `amt` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: req_out_comming_mst
#

DROP TABLE IF EXISTS `req_out_comming_mst`;

CREATE TABLE `req_out_comming_mst` (
  `out_com_id` int(11) NOT NULL DEFAULT '0',
  `account` varchar(50) NOT NULL,
  `out_com_desc` varchar(255) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `ref_no` varchar(20) NOT NULL,
  `amt` double NOT NULL,
  `vat_amt` double NOT NULL,
  `req_no` int(11) NOT NULL,
  `process` int(11) NOT NULL DEFAULT '0',
  `yr_no` int(4) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `reseveir` varchar(50) NOT NULL,
  `cost_center` int(11) NOT NULL,
  `out_com_date` date NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`out_com_id`,`yr_no`,`br_no`,`comp_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: req_trans_item_dtl
#

DROP TABLE IF EXISTS `req_trans_item_dtl`;

CREATE TABLE `req_trans_item_dtl` (
  `id` int(11) NOT NULL,
  `req_trans_item_id` int(11) NOT NULL,
  `yr_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_unit` int(11) NOT NULL,
  `qty` double NOT NULL,
  `qty_process` double NOT NULL,
  `cost` double NOT NULL,
  `stock_no` int(11) NOT NULL,
  `vat_amt` double NOT NULL,
  `amt` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: req_trans_item_mst
#

DROP TABLE IF EXISTS `req_trans_item_mst`;

CREATE TABLE `req_trans_item_mst` (
  `req_trans_item_id` int(11) NOT NULL DEFAULT '0',
  `req_no` int(11) NOT NULL,
  `yr_no` int(4) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `req_trans_item_date` date NOT NULL,
  `cost_center` int(11) NOT NULL,
  `reseveir` varchar(50) NOT NULL,
  `req_trans_item_desc` varchar(255) NOT NULL,
  `stock_from_id` int(11) NOT NULL,
  `stock_to_it` int(11) NOT NULL,
  `ref_no` varchar(20) NOT NULL,
  `cost` double NOT NULL,
  `amt` double NOT NULL,
  `vat_amt` double NOT NULL,
  `process` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: reseive_item_dtl
#

DROP TABLE IF EXISTS `reseive_item_dtl`;

CREATE TABLE `reseive_item_dtl` (
  `id` int(11) NOT NULL,
  `reseive_item_id` int(11) NOT NULL,
  `yr_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_unit` int(11) NOT NULL,
  `qty` double NOT NULL,
  `cost` double NOT NULL,
  `stock_no` int(11) NOT NULL,
  `vat_amt` double NOT NULL,
  `amt` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: reseive_item_mst
#

DROP TABLE IF EXISTS `reseive_item_mst`;

CREATE TABLE `reseive_item_mst` (
  `id` int(11) NOT NULL,
  `reseive_item_no` int(11) NOT NULL,
  `req_no` int(11) NOT NULL,
  `yr_no` int(4) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `reseive_item_date` date NOT NULL,
  `cost_center` int(11) NOT NULL,
  `reseveir` varchar(50) NOT NULL,
  `trans_item_desc` varchar(255) NOT NULL,
  `stock_from_id` int(11) NOT NULL,
  `stock_to_it` int(11) NOT NULL,
  `ref_no` varchar(20) NOT NULL,
  `cost` double NOT NULL,
  `amt` double NOT NULL,
  `vat_amt` double NOT NULL,
  `postem` int(11) NOT NULL DEFAULT '0',
  `posted_u_id` int(11) DEFAULT NULL,
  `posted_date` date DEFAULT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`reseive_item_no`,`req_no`,`yr_no`,`comp_no`,`br_no`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: restrictionbody
#

DROP TABLE IF EXISTS `restrictionbody`;

CREATE TABLE `restrictionbody` (
  `ID` int(11) DEFAULT NULL,
  `DocumentNumber` int(11) DEFAULT NULL,
  `DocumentID` int(11) DEFAULT NULL,
  `ActionDate` date DEFAULT NULL,
  `Note` varchar(256) DEFAULT NULL,
  `ExchangeValue` float DEFAULT NULL,
  `CurrencyID` int(11) DEFAULT NULL,
  `ReferenceNumber` int(11) DEFAULT NULL,
  `RCost` float DEFAULT NULL,
  `RCredit` float DEFAULT NULL,
  `RDebt` float DEFAULT NULL,
  `AccName` varchar(256) DEFAULT NULL,
  `AccNumber` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: restrictionheader
#

DROP TABLE IF EXISTS `restrictionheader`;

CREATE TABLE `restrictionheader` (
  `ID` int(11) DEFAULT NULL,
  `DocumentNumber` int(11) DEFAULT NULL,
  `DocumentID` int(11) DEFAULT NULL,
  `ActionDate` date DEFAULT NULL,
  `Note` varchar(256) DEFAULT NULL,
  `ExchangeValue` float DEFAULT NULL,
  `CurrencyID` int(11) DEFAULT NULL,
  `ReferenceNumber` int(11) DEFAULT NULL,
  `RCost` float DEFAULT NULL,
  `RCredit` float DEFAULT NULL,
  `RDebt` float DEFAULT NULL,
  `AccName` varchar(256) DEFAULT NULL,
  `AccNumber` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: sceern_privilege
#

DROP TABLE IF EXISTS `sceern_privilege`;

CREATE TABLE `sceern_privilege` (
  `u_id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `include` int(11) NOT NULL,
  `ad` int(11) NOT NULL DEFAULT '0',
  `updte` int(11) NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL,
  `delte` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(11) NOT NULL DEFAULT '0',
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`u_id`,`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ss_interface
#

DROP TABLE IF EXISTS `ss_interface`;

CREATE TABLE `ss_interface` (
  `br_id` int(11) NOT NULL,
  `change_curreny` int(50) NOT NULL,
  `lost_item` int(50) NOT NULL,
  `accounts_payable` int(50) NOT NULL,
  `accounts_receivable` int(50) NOT NULL,
  `account_credit` int(50) NOT NULL,
  `change_cost` int(50) NOT NULL,
  `vat_pay` int(50) NOT NULL,
  `vat_sale` int(50) NOT NULL,
  PRIMARY KEY (`br_id`),
  KEY `accounts_payable` (`accounts_payable`),
  KEY `account_credit` (`account_credit`),
  KEY `change_cost` (`change_cost`),
  KEY `change_curreny` (`change_curreny`),
  KEY `lost_item` (`lost_item`),
  KEY `vat_pay` (`vat_pay`),
  KEY `vat_sale` (`vat_sale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: ss_para
#

DROP TABLE IF EXISTS `ss_para`;

CREATE TABLE `ss_para` (
  `id` int(11) NOT NULL DEFAULT '1',
  `use_vat` int(11) NOT NULL,
  `date_start_vat` int(11) NOT NULL,
  `use_cost` int(11) NOT NULL,
  `date_start_cost` int(11) NOT NULL,
  `allow_user_lg_pc` int(11) NOT NULL,
  `price_with_vat` int(11) NOT NULL,
  `date_start_price_w_vat` int(11) NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` int(11) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` int(11) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: ss_system
#

DROP TABLE IF EXISTS `ss_system`;

CREATE TABLE `ss_system` (
  `id` int(11) NOT NULL,
  `system_name` int(11) NOT NULL,
  `system_e_name` int(11) NOT NULL,
  `statuse` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `chort` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chort` (`chort`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: stocktaking_dtl
#

DROP TABLE IF EXISTS `stocktaking_dtl`;

CREATE TABLE `stocktaking_dtl` (
  `id` int(11) NOT NULL,
  `stocktaking_id` int(11) NOT NULL,
  `yr_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_unit` int(11) NOT NULL,
  `stocktaking_qty` double NOT NULL,
  `qty_stock` double NOT NULL,
  `cost` double NOT NULL,
  `stock_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stocktaking_id` (`stocktaking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: stocktaking_mst
#

DROP TABLE IF EXISTS `stocktaking_mst`;

CREATE TABLE `stocktaking_mst` (
  `stocktaking_id` int(11) NOT NULL DEFAULT '0',
  `comp_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `yr_no` int(4) NOT NULL,
  `account` varchar(50) NOT NULL,
  `stocktaking_desc` varchar(255) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `ref_no` varchar(20) NOT NULL,
  `amt` double NOT NULL,
  `process` int(11) NOT NULL DEFAULT '0',
  `posted` int(11) NOT NULL DEFAULT '0',
  `posted_u_id` int(11) NOT NULL,
  `posted_date` date DEFAULT NULL,
  `stocktaking_type` int(11) NOT NULL DEFAULT '1',
  `cost_center` int(11) NOT NULL,
  `stocktaking_date` date NOT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) DEFAULT NULL,
  `up_date` date DEFAULT NULL,
  `up_trmnl` varchar(50) DEFAULT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`stocktaking_id`,`yr_no`,`br_no`,`comp_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblactivitylog
#

DROP TABLE IF EXISTS `tblactivitylog`;

CREATE TABLE `tblactivitylog` (
  `id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staffid` (`staffid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblannouncements
#

DROP TABLE IF EXISTS `tblannouncements`;

CREATE TABLE `tblannouncements` (
  `announcementid` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `message` text,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcheckliststemplates
#

DROP TABLE IF EXISTS `tblcheckliststemplates`;

CREATE TABLE `tblcheckliststemplates` (
  `id` int(11) NOT NULL,
  `description` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblclients
#

DROP TABLE IF EXISTS `tblclients`;

CREATE TABLE `tblclients` (
  `userid` int(11) NOT NULL,
  `company` varchar(100) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT '0',
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT '0',
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT '0',
  `longitude` varchar(300) DEFAULT NULL,
  `latitude` varchar(300) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT '0',
  `show_primary_contact` int(11) NOT NULL DEFAULT '0',
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT '1',
  `addedfrom` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (1, 'مؤشرات الأداء', '301209059100003', '00966114741060', 194, 'الرياض', '11437', 'المنطقة الوسطى', 'حي المصيف - طريق ابي بكر الصديق جوار الجريسي', 'https://kpi.com.sa', '2018-10-07 13:32:21', 1, NULL, 'حي المصيف - طريق ابي بكر الصديق جوار الجريسي', 'الرياض', 'المنطقة الوسطى', '11437', 194, 'حي المصيف - طريق ابي بكر الصديق جوار الجريسي', 'الرياض', 'المنطقة الوسطى', '11437', 194, '24.7668001', '46.6933499', NULL, 0, 1, NULL, 1, 2);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (2, 'جامعة الباحة ', '', '', 194, 'الباحة ', '', 'المنطقة الوسطى', 'الباحة- حي العقيق', 'bu.edu.sa', '2018-10-07 14:51:52', 1, NULL, 'الباحة- حي العقيق', 'الباحة ', 'المنطقة الوسطى', '', 194, 'الباحة- حي العقيق', 'الباحة ', 'المنطقة الوسطى', '', 194, NULL, NULL, '', 3, 0, NULL, 1, 3);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (3, 'مكلند ', '', '', 194, 'الرياض', '', 'المنطقة الوسطى', 'طريق الملك عبدالعزيز', '', '2018-10-07 14:52:57', 1, NULL, 'طريق الملك عبدالعزيز', 'الرياض', 'المنطقة الوسطى', '', 194, 'طريق الملك عبدالعزيز', 'الرياض', 'المنطقة الوسطى', '', 194, NULL, NULL, NULL, 0, 0, NULL, 1, 4);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (4, 'جامعة نجران', '', '', 194, 'نجران', '', '', 'نجران', '', '2018-10-07 18:41:55', 1, NULL, '', '', '', '', 0, '', '', '', '', 0, NULL, NULL, NULL, 0, 0, NULL, 1, 3);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (5, 'جامعة المجمعة', '', '', 194, '', '', 'جديد', '', 'm.mu.edu.sa', '2018-10-07 18:45:15', 1, NULL, '', '', '', '', 0, '', '', '', '', 0, NULL, NULL, NULL, 0, 0, NULL, 1, 3);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (6, 'جامعة الملك خالد ', '', '', 194, 'أبها ', '', '', 'أبها', '/www.kku.edu.sa', '2018-10-08 14:20:01', 1, NULL, '', '', '', '', 0, '', '', '', '', 0, NULL, NULL, NULL, 0, 0, NULL, 1, 3);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (7, 'مؤسسة أفكار للعلاقات العامة', '300012738100003', '114741060', 194, 'الرياض', '11444', 'المنطقة الوسطى', 'حي المصيف - طريق ابو بكر الصديق جوار الجريسي', 'http://afkar.sa', '2018-10-25 10:04:28', 1, NULL, 'حي المصيف - طريق ابو بكر الصديق جوار الجريسي', 'الرياض', 'المنطقة الوسطى', '11444', 194, 'حي المصيف - طريق ابو بكر الصديق جوار الجريسي', 'الرياض', 'المنطقة الوسطى', '11444', 194, NULL, NULL, '', 0, 0, NULL, 1, 1);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (8, 'مؤسسة تحديث الشبكة لتقنية المعلومات', '', '114741060', 194, 'الرياض', '11444', 'المنطقة الوسطى', 'حي المصيف - طريق ابو بكر الصديق جوار الجريسي', 'http://networkupdate.sa', '2018-10-25 10:08:50', 1, NULL, 'حي المصيف - طريق ابو بكر الصديق جوار الجريسي', 'الرياض', 'المنطقة الوسطى', '11444', 194, 'حي المصيف - طريق ابو بكر الصديق جوار الجريسي', 'الرياض', 'المنطقة الوسطى', '11444', 194, NULL, NULL, '', 0, 0, NULL, 1, 1);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (9, 'شور التنمية للتطوير والاستثمار الزراعي', '', '', 194, 'الرياض', '', 'المنطقة الوسطى', 'حي النخيل - طريق الامام سعود بجوار بنك الراجحي مبنى السيف جاليري', 'http://shore.sa', '2018-10-30 09:24:37', 1, NULL, 'حي النخيل - طريق الامام سعود بجوار بنك الراجحي مبنى السيف جاليري', 'الرياض', 'المنطقة الوسطى', '', 194, 'حي النخيل - طريق الامام سعود بجوار بنك الراجحي مبنى السيف جاليري', 'الرياض', 'المنطقة الوسطى', '', 194, NULL, NULL, '', 0, 0, NULL, 1, 1);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (10, 'وزارة البيئة والمياة والزراعة', '', '', 194, 'الرياض', '11444', 'المنطقة الوسطى', 'الملز - حي الوزارات', '', '2018-10-30 12:43:29', 1, NULL, '', '', '', '', 0, '', '', '', '', 0, NULL, NULL, '', 0, 0, NULL, 1, 1);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (11, 'وزارة العدل', '', '0532311323', 194, 'الرياض', '', '', '', '', '2018-11-06 11:36:25', 1, 11, '', 'الرياض', '', '', 194, '', '', '', '', 0, NULL, NULL, '', 0, 0, NULL, 1, 4);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (13, 'Security L.L.C', '', '+971585744949', 166, 'Muscat', '', 'State of Oman', '', '', '2018-12-11 21:52:34', 1, 47, '', 'Muscat', 'State of Oman', '', 166, '', '', '', '', 0, NULL, NULL, 'english', 0, 0, NULL, 1, 5);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`) VALUES (14, 'مكتب البرمان للاستقدام', '', '966112677770+', 194, 'الرياض', '', 'المنطقة الوسطى', 'طريق ابي بكر الصديق<br />\r\n<br />\r\nحي المصيف', 'http://alborman.sa', '2018-12-12 08:45:21', 1, NULL, 'طريق ابي بكر الصديق<br />\r\n<br />\r\nحي المصيف', 'الرياض', 'المنطقة الوسطى', '', 194, 'طريق ابي بكر الصديق<br />\r\n<br />\r\nحي المصيف', 'الرياض', 'المنطقة الوسطى', '', 194, NULL, NULL, '', 0, 0, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: tblcontactpermissions
#

DROP TABLE IF EXISTS `tblcontactpermissions`;

CREATE TABLE `tblcontactpermissions` (
  `id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontacts
#

DROP TABLE IF EXISTS `tblcontacts`;

CREATE TABLE `tblcontacts` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT '1',
  `firstname` varchar(300) NOT NULL,
  `lastname` varchar(300) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(200) NOT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `profile_image` varchar(300) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT '1',
  `estimate_emails` tinyint(1) NOT NULL DEFAULT '1',
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT '1',
  `contract_emails` tinyint(1) NOT NULL DEFAULT '1',
  `task_emails` tinyint(1) NOT NULL DEFAULT '1',
  `project_emails` tinyint(1) NOT NULL DEFAULT '1',
  `ticket_emails` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `is_primary` (`is_primary`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (1, 1, 0, 'عبدالباقي', 'درار', 'proco@pmp.kpi.com.sa', '', 'منسق المشاريع', '2018-10-07 13:34:15', '$2', NULL, NULL, NULL, NULL, NULL, 1, NULL, '', 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (2, 14, 1, 'حسين', 'اليامي', 'info@alborman.sa', '', 'المدير العام', '2018-12-12 08:53:06', '$2', NULL, NULL, NULL, NULL, NULL, 1, NULL, '', 1, 0, 0, 0, 0, 0, 0);


#
# TABLE STRUCTURE FOR: tblcontractrenewals
#

DROP TABLE IF EXISTS `tblcontractrenewals`;

CREATE TABLE `tblcontractrenewals` (
  `id` int(11) NOT NULL,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT '0',
  `is_on_old_expiry_notified` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontracts
#

DROP TABLE IF EXISTS `tblcontracts`;

CREATE TABLE `tblcontracts` (
  `id` int(11) NOT NULL,
  `content` longtext,
  `description` text,
  `subject` varchar(300) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT '0',
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT '0',
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT '0',
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT '0',
  `signature` varchar(40) DEFAULT NULL,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontracttypes
#

DROP TABLE IF EXISTS `tblcontracttypes`;

CREATE TABLE `tblcontracttypes` (
  `id` int(11) NOT NULL,
  `name` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcreditnotes
#

DROP TABLE IF EXISTS `tblcreditnotes`;

CREATE TABLE `tblcreditnotes` (
  `id` int(11) NOT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '1',
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` text,
  `terms` text,
  `clientnote` text,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `discount_percent` decimal(15,2) DEFAULT '0.00',
  `discount_total` decimal(15,2) DEFAULT '0.00',
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcredits
#

DROP TABLE IF EXISTS `tblcredits`;

CREATE TABLE `tblcredits` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcurrencies
#

DROP TABLE IF EXISTS `tblcurrencies`;

CREATE TABLE `tblcurrencies` (
  `id` int(11) NOT NULL,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomeradmins
#

DROP TABLE IF EXISTS `tblcustomeradmins`;

CREATE TABLE `tblcustomeradmins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` text NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomergroups_in
#

DROP TABLE IF EXISTS `tblcustomergroups_in`;

CREATE TABLE `tblcustomergroups_in` (
  `id` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomersgroups
#

DROP TABLE IF EXISTS `tblcustomersgroups`;

CREATE TABLE `tblcustomersgroups` (
  `id` int(11) NOT NULL,
  `name` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbldepartments
#

DROP TABLE IF EXISTS `tbldepartments`;

CREATE TABLE `tbldepartments` (
  `departmentid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT '0',
  `host` varchar(150) DEFAULT NULL,
  `password` mediumtext,
  `encryption` varchar(3) DEFAULT NULL,
  `delete_after_import` int(11) NOT NULL DEFAULT '0',
  `calendar_id` mediumtext,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbldismissedannouncements
#

DROP TABLE IF EXISTS `tbldismissedannouncements`;

CREATE TABLE `tbldismissedannouncements` (
  `dismissedannouncementid` int(11) NOT NULL,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblestimates
#

DROP TABLE IF EXISTS `tblestimates`;

CREATE TABLE `tblestimates` (
  `id` int(11) NOT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '0',
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `clientnote` text,
  `adminnote` text,
  `discount_percent` decimal(15,2) DEFAULT '0.00',
  `discount_total` decimal(15,2) DEFAULT '0.00',
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT '0',
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `pipeline_order` int(11) NOT NULL DEFAULT '0',
  `is_expiry_notified` int(11) NOT NULL DEFAULT '0',
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblexpenses
#

DROP TABLE IF EXISTS `tblexpenses`;

CREATE TABLE `tblexpenses` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT '0',
  `reference_no` varchar(100) DEFAULT NULL,
  `note` text,
  `expense_name` varchar(500) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `billable` int(11) DEFAULT '0',
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `cycles` int(11) NOT NULL DEFAULT '0',
  `total_cycles` int(11) NOT NULL DEFAULT '0',
  `custom_recurring` int(11) NOT NULL DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblexpensescategories
#

DROP TABLE IF EXISTS `tblexpensescategories`;

CREATE TABLE `tblexpensescategories` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoicepaymentrecords
#

DROP TABLE IF EXISTS `tblinvoicepaymentrecords`;

CREATE TABLE `tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(200) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoicepaymentsmodes
#

DROP TABLE IF EXISTS `tblinvoicepaymentsmodes`;

CREATE TABLE `tblinvoicepaymentsmodes` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `show_on_pdf` int(11) NOT NULL DEFAULT '0',
  `invoices_only` int(11) NOT NULL DEFAULT '0',
  `expenses_only` int(11) NOT NULL DEFAULT '0',
  `selected_by_default` int(11) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoices
#

DROP TABLE IF EXISTS `tblinvoices`;

CREATE TABLE `tblinvoices` (
  `id` int(11) NOT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '0',
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT '1',
  `clientnote` text,
  `adminnote` text,
  `last_overdue_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT '0',
  `allowed_payment_modes` mediumtext,
  `token` mediumtext,
  `discount_percent` decimal(15,2) DEFAULT '0.00',
  `discount_total` decimal(15,2) DEFAULT '0.00',
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `cycles` int(11) NOT NULL DEFAULT '0',
  `total_cycles` int(11) NOT NULL DEFAULT '0',
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` text,
  `sale_agent` int(11) NOT NULL DEFAULT '0',
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `project_id` int(11) DEFAULT '0',
  `subscription_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitems
#

DROP TABLE IF EXISTS `tblitems`;

CREATE TABLE `tblitems` (
  `id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `long_description` text,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitems_groups
#

DROP TABLE IF EXISTS `tblitems_groups`;

CREATE TABLE `tblitems_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitems_in
#

DROP TABLE IF EXISTS `tblitems_in`;

CREATE TABLE `tblitems_in` (
  `id` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` mediumtext NOT NULL,
  `long_description` mediumtext,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `id` (`id`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitemsrelated
#

DROP TABLE IF EXISTS `tblitemsrelated`;

CREATE TABLE `tblitemsrelated` (
  `id` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitemstax
#

DROP TABLE IF EXISTS `tblitemstax`;

CREATE TABLE `tblitemstax` (
  `id` int(11) NOT NULL,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleads
#

DROP TABLE IF EXISTS `tblleads`;

CREATE TABLE `tblleads` (
  `id` int(11) NOT NULL,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(300) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(300) DEFAULT NULL,
  `description` text,
  `country` int(11) NOT NULL DEFAULT '0',
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT '1',
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT '0',
  `junk` int(11) NOT NULL DEFAULT '0',
  `last_lead_status` int(11) NOT NULL DEFAULT '0',
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT '0',
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `assigned` (`assigned`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `leadorder` (`leadorder`),
  KEY `dateadded` (`dateadded`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleadssources
#

DROP TABLE IF EXISTS `tblleadssources`;

CREATE TABLE `tblleadssources` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleadsstatus
#

DROP TABLE IF EXISTS `tblleadsstatus`;

CREATE TABLE `tblleadsstatus` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnotifications
#

DROP TABLE IF EXISTS `tblnotifications`;

CREATE TABLE `tblnotifications` (
  `id` int(11) NOT NULL,
  `isread` int(11) NOT NULL DEFAULT '0',
  `isread_inline` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT '0',
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` mediumtext,
  `additional_data` varchar(600) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbloptions
#

DROP TABLE IF EXISTS `tbloptions`;

CREATE TABLE `tbloptions` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblpermissions
#

DROP TABLE IF EXISTS `tblpermissions`;

CREATE TABLE `tblpermissions` (
  `permissionid` int(11) NOT NULL,
  `name` mediumtext NOT NULL,
  `shortname` mediumtext NOT NULL,
  PRIMARY KEY (`permissionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojects
#

DROP TABLE IF EXISTS `tblprojects`;

CREATE TABLE `tblprojects` (
  `id` int(11) NOT NULL,
  `name` varchar(600) NOT NULL,
  `description` text,
  `status` int(11) NOT NULL DEFAULT '0',
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT '0',
  `progress_from_tasks` int(11) NOT NULL DEFAULT '1',
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectsettings
#

DROP TABLE IF EXISTS `tblprojectsettings`;

CREATE TABLE `tblprojectsettings` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproposals
#

DROP TABLE IF EXISTS `tblproposals`;

CREATE TABLE `tblproposals` (
  `id` int(11) NOT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `content` longtext,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(600) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT '0',
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) NOT NULL DEFAULT '0',
  `is_expiry_notified` int(11) NOT NULL DEFAULT '0',
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblrolepermissions
#

DROP TABLE IF EXISTS `tblrolepermissions`;

CREATE TABLE `tblrolepermissions` (
  `rolepermissionid` int(11) NOT NULL,
  `roleid` int(11) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_own` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `permissionid` int(11) NOT NULL,
  PRIMARY KEY (`rolepermissionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblroles
#

DROP TABLE IF EXISTS `tblroles`;

CREATE TABLE `tblroles` (
  `roleid` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsalesactivity
#

DROP TABLE IF EXISTS `tblsalesactivity`;

CREATE TABLE `tblsalesactivity` (
  `id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `additional_data` text,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsessions
#

DROP TABLE IF EXISTS `tblsessions`;

CREATE TABLE `tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstaff
#

DROP TABLE IF EXISTS `tblstaff`;

CREATE TABLE `tblstaff` (
  `staffid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` mediumtext,
  `linkedin` mediumtext,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(300) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(300) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT '0',
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `two_factor_auth_enabled` tinyint(1) DEFAULT '0',
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` text,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstaffdepartments
#

DROP TABLE IF EXISTS `tblstaffdepartments`;

CREATE TABLE `tblstaffdepartments` (
  `staffdepartmentid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstaffpermissions
#

DROP TABLE IF EXISTS `tblstaffpermissions`;

CREATE TABLE `tblstaffpermissions` (
  `staffpermid` int(11) NOT NULL,
  `permissionid` int(11) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_own` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) NOT NULL DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `staffid` int(11) NOT NULL,
  PRIMARY KEY (`staffpermid`),
  KEY `permissionid` (`permissionid`),
  KEY `staffid` (`staffid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltags
#

DROP TABLE IF EXISTS `tbltags`;

CREATE TABLE `tbltags` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltags_in
#

DROP TABLE IF EXISTS `tbltags_in`;

CREATE TABLE `tbltags_in` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT '0',
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaxes
#

DROP TABLE IF EXISTS `tbltaxes`;

CREATE TABLE `tbltaxes` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbluserautologin
#

DROP TABLE IF EXISTS `tbluserautologin`;

CREATE TABLE `tbluserautologin` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblusermeta
#

DROP TABLE IF EXISTS `tblusermeta`;

CREATE TABLE `tblusermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `client_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: trans_item_dtl
#

DROP TABLE IF EXISTS `trans_item_dtl`;

CREATE TABLE `trans_item_dtl` (
  `id` int(11) NOT NULL,
  `trans_item_id` int(11) NOT NULL,
  `yr_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_unit` int(11) NOT NULL,
  `qty` double NOT NULL,
  `qty_process` double NOT NULL,
  `cost` double NOT NULL,
  `stock_no` int(11) NOT NULL,
  `vat_amt` double NOT NULL,
  `amt` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: trans_item_mst
#

DROP TABLE IF EXISTS `trans_item_mst`;

CREATE TABLE `trans_item_mst` (
  `id` int(11) NOT NULL,
  `trans_item_no` int(11) NOT NULL,
  `req_no` int(11) NOT NULL,
  `yr_no` int(4) NOT NULL,
  `comp_no` int(11) NOT NULL,
  `br_no` int(11) NOT NULL,
  `trans_item_date` date NOT NULL,
  `cost_center` int(11) NOT NULL,
  `reseveir` varchar(50) NOT NULL,
  `trans_item_desc` varchar(255) NOT NULL,
  `stock_from_id` int(11) NOT NULL,
  `stock_to_it` int(11) NOT NULL,
  `ref_no` varchar(20) NOT NULL,
  `cost` double NOT NULL,
  `amt` double NOT NULL,
  `vat_amt` double NOT NULL,
  `postem` int(11) NOT NULL DEFAULT '0',
  `posted_u_id` int(11) DEFAULT NULL,
  `posted_date` date DEFAULT NULL,
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`trans_item_no`,`yr_no`,`comp_no`,`br_no`),
  UNIQUE KEY `hjh` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: transaction_privilege
#

DROP TABLE IF EXISTS `transaction_privilege`;

CREATE TABLE `transaction_privilege` (
  `u_id` int(11) NOT NULL,
  `sale_less_cost` int(11) NOT NULL DEFAULT '0',
  `price_manual` int(11) NOT NULL DEFAULT '0',
  `cross_black_list` int(11) NOT NULL DEFAULT '0',
  `zero_cost` int(11) NOT NULL DEFAULT '0',
  `pay_vendor_wthout_bal` int(11) NOT NULL DEFAULT '0',
  `sale_free_qty` int(11) NOT NULL DEFAULT '0',
  `use_discount` int(11) NOT NULL DEFAULT '0',
  `discoutn_perecent` int(11) NOT NULL DEFAULT '0',
  `request_ar` int(11) NOT NULL DEFAULT '0',
  `request_ap` int(11) NOT NULL DEFAULT '0',
  `request_gl` int(11) NOT NULL DEFAULT '0',
  `cancel_approv` int(11) NOT NULL DEFAULT '0',
  `account_statmen_primary` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: translate
#

DROP TABLE IF EXISTS `translate`;

CREATE TABLE `translate` (
  `id` varchar(50) NOT NULL,
  `value` varchar(50) NOT NULL,
  `language` varchar(50) NOT NULL,
  PRIMARY KEY (`id`,`language`),
  KEY `translate_ibfk_1` (`language`),
  CONSTRAINT `translate_ibfk_1` FOREIGN KEY (`language`) REFERENCES `languages` (`lang_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `translate` (`id`, `value`, `language`) VALUES (' accountant', 'المحاسب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES (' accountant', ' Accountant', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES (' financial_system', ' النظام المالي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES (' financial_system', ' Financial system', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('acc', 'مركز التكلفة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('acc', 'Analytical account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account', 'الحساب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account', 'account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('accountant', 'محاسب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('accountant', 'accountant', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_1', 'حساب رقم  1', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_1', 'Account number 1', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_2', 'حساب رقم  2', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_2', 'Account number 2', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_analysis', 'الحساب التحليلي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_analysis', 'Analytical account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_balance', 'رصيد الحساب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_balance', 'Account balance', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_name', 'اسم الحساب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_name', 'account name', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_no', 'رقم الحساب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_no', 'account number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_not_exist', 'حصل خطا!  رقم الحساب غير موجود ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_not_exist', 'There was an error! Account number does not exist', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_number', 'حساب رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_number', 'Account number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_number_should_contain_main_account', 'رقم الحساب يجب اين يحتوي على الحساب الرئيسي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_number_should_contain_main_account', 'The account number should contain the main account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_nuture', ' طبيعة الحساب  ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_nuture', 'Nature of account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_primary', 'الحساب الرئيسي  ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_primary', 'ACCOUTN PRIMARY', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_report', 'تقرير الحساب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_report', 'Account report', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_type', '  نوع الحساب  ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('account_type', 'type of account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('action', 'الاجراء', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('action', 'Action', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('address_ar', 'العنوان بالعربية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('address_ar', 'Address in Arabic', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('address_en', 'العنوان بالانجليزية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('address_en', 'Address in English', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('all', 'كلي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('all', 'all', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('amt', 'المبلغ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('amt', 'Amount', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('analytical', 'تحليلي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('analytical', 'Analytical', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('arabic', 'عربي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('arabic', 'عربي', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('balance', 'الرصيد', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('balance', 'Balance', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('bank', 'البنك', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('bank', 'bank', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('banks', 'البنوك', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('banks', 'Banks', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('bank_balance', 'رصيد البنك', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('bank_balance', 'Bank balance', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('bank_no', 'رقم البنك', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('bank_no', 'bank number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('beneficiary', 'المستفيد', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('beneficiary', 'beneficiary', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('bond_no', 'رقم السند', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('bond_no', 'Bond No', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box', 'الصندوق', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box', 'box', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('boxs', 'الصناديق', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('boxs', 'Boxs', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box_balance', 'رصيد الصندوق', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box_balance', 'Box balance', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box_no', 'رقم الصندوق', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box_no', 'box number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box_number', 'صندوق البريد', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box_number', 'box number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box_or_bank_must>from_box_or_bank', 'يجب ان يكون  الى  صندوق او بنك اكبراو يساوي من من ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('box_or_bank_must>from_box_or_bank', 'From the  Box or Bank must be >=  to the  Box or B', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('branch', 'الفرع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('branch', 'Branch', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('Branchid', 'رقم الفرع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('Branchid', 'Branch number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('branchs', 'الفروع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('branchs', 'branchs', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('br_name', 'أسم الفرع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('br_name', 'Branch name', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('btn_add', 'اضافة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('btn_add', 'add', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('btn_edit', 'تعديل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('btn_edit', 'Update', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('by_level', 'كلي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('by_level', 'By level', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('chart-of_account_accounts_tree', 'الدليل المحاسبي - شجرة الحسابات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('chart-of_account_accounts_tree', 'Chart of account - Accounts tree', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('chartofaccount', 'الدليل المحاسبي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('chartofaccount', 'chart of account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('chart_sheet_balance', '  مخطط كشف الحسابات ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('chart_sheet_balance', 'chart_sheet_balance', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('check_box_belong_branch', 'فحص الصناديق المرتبطة بالفروع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('check_box_belong_branch', 'Examination of box  linked to branches', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('check_no', 'رقم الشيك', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('check_no', 'check number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('chiques_book', 'دفتر الشيكات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('chiques_book', 'Chiques Book', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('choose', 'اختر', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('choose', 'Choose', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('choose_file', 'اختر ملف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('choose_file', 'choose a file', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('close', 'اغلاق', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('close', 'Close', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('code', 'الكود', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('code', 'code', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('comany_name_ar', 'اسم المنشأه بالعربية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('comany_name_ar', 'Comany name Arabic', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('comany_name_en', 'اسم المنشأه بالانجليزية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('comany_name_en', 'Comany name English', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('company', 'معلومات المنشأه', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('company', 'company ifo', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('compare_between_account', 'مقارنة بين حسابين', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('compare_between_account', 'Compare between Account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('copy', 'نسخ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('copy', 'copy', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('cost_center', 'مراكز التكلفة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('cost_center', 'Cost Center', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('cpaymentvoucher', 'صرف شيكات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('cpaymentvoucher', 'Chique Payment', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('cpaymentvoucher_no', 'رقم صرف شيك', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('cpaymentvoucher_no', 'Chique Payment Number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('creceiptvoucher', ' استلام شيكات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('creceiptvoucher', 'Chique Receipt ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('creceiptvoucher_no', 'رقم  استلام شيك', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('creceiptvoucher_no', 'Chique Receipt number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('credit', 'دائن', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('credit', 'credit', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('credit_debit', 'مدين دائن ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('credit_debit', '  CRIDET DEBT', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currencies', 'العملات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currencies', 'Currencies', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currency', 'العملة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currency', 'currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currencyid', 'رقم العملة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currencyid', 'currency nubmer', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currency_name', 'اسم العملة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currency_name', 'currency name', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currency_sub', 'الفكه', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('currency_sub', 'sub currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('current_balance', 'الرصيد الحالي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('current_balance', 'current balance', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('cur_code', 'رمز العملة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('cur_code', 'cuureny code', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('customers', 'العملاء', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('customers', 'customers', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('date', 'التاريخ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('date', ' Date', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('date_entry', 'تاريخ الادخال', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('date_entry', 'Date entry', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('date_maturity', 'تاريخ الاستحقاق', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('date_maturity', 'date of maturity', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('date_update', 'تاريخ التعديل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('date_update', 'date  update', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('debit', 'مدين', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('debit', 'debit', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('debt_1_credit_0', ' مدين 1 و دائن 0', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('debt_1_credit_0', 'Debt  1 and credit 0', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('default_language', 'اللغة الافتراضي ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('default_language', ' default language', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('delete', 'حذف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('delete', 'delete', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('deleted_successfully', 'تمت عملية الحذف بنجاح', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('deleted_successfully', 'Deleted successfully', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('dictionary', 'القاموس', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('dictionary', 'Dictionary', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('disable', 'تعطيل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('disable', 'disable', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('disbursement', 'صرف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('disbursement', 'disbursement', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('document_number', 'رقم الوثيقة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('document_number', ' Document number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('doc_due_payment', 'المستندات المستحقة للسداد', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('doc_due_payment', ' Documents due for payment', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('downlaod_file_first', 'حمل الملف اولا', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('downlaod_file_first', 'Download the file first', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('download', ' انزال', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('download', ' Download', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('download_from', 'انزال من', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('download_from', ' Download from', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('dtl', 'التفاصيل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('dtl', 'details', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('edited_successfully', 'تم التعديل بنجاح', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('edited_successfully', 'edited successfully', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('email_id', 'البريد الالكتروني', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('email_id', 'Email ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('emps_sal', ' رواتب الموظفين', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('emps_sal', 'Employees\' salaries', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('empty_file', 'الملف فارغ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('empty_file', 'empty file', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enable', 'تفعيل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enable', 'Enable', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('english', 'English', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('english', 'English', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('english_name', 'الاسم الاجنبي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('english_name', 'English name', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enter_account', 'قم بادخال  الحساب ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enter_account', 'Enter the account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enter_amt', 'قم بادخال قيمة للمبلغ ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enter_amt', 'Enter a value for the amount', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enter_credit_or_debt', 'قم بادخال قيمة للدائن او المدين', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enter_credit_or_debt', 'Enter a value for the credit or debt', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enter_currency', 'قم بادخال  العملة ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('enter_currency', 'Enter the currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_add_duplicate_data_number', 'حصل خطأ ، اثناء الاضافة رقم بيانات مكرر', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_add_duplicate_data_number', ' An error occurred, while adding a duplicate data ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_delete', '!!حصل خطا! اثناء عملية الحذف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_delete', '\'!!There was an error! During deletion \'', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_level_of_primary_must_less_than', 'حصل خطأ! رتبة الحساب الرئيسي يجب ان تكون اقل من ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_level_of_primary_must_less_than', 'There was an error! The level of the main account ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_level_of_sub_must_equal', 'حصل خطأ! رتبة الحساب الفرعي يجب ان تساوي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_level_of_sub_must_equal', 'There was an error! The level of the sub account m', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_primary_account', '\' حصل خطأ! قد يكون   الحساب الرئيسي.\'', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_primary_account', '\' There was an error! It may be the primary  accou', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_there_is_movement', 'حصل خطا!      هنالك حركة  ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_there_is_movement', 'Error there is a Movement', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_type_of_file', 'حصل خطأ ، نوع المف غير صحيح', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('error_type_of_file', 'An error has occurred, invalid file type', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('excel', 'إكسل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('excel', 'excel', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('expir_date', 'تاريخ الانتهاء ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('expir_date', 'Expiry date', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('export_csv', 'تصدير csv ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('export_csv', 'export_csv', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('export_excel', 'تصدير اكسل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('export_excel', 'export_excel', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('export_pdf', 'تصدير pdf', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('export_pdf', 'export pdf', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('ex_max_value', 'اعلى قيمة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('ex_max_value', 'ex_max_value', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('ex_min_value', 'اقل قيمة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('ex_min_value', 'ex_min_value', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('ex_value', 'سعر التحويل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('ex_value', 'ex_value', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('faled', 'الحقل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('faled', 'faled', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('fax', 'الفاكس', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('fax', 'fax', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('financial_director', 'المدير المالي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('financial_director', 'Financial Director', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('financial_system', 'النظام المالي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('financial_system', 'Financial system', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('first_line_not_read_but_clarification', 'السطر الاول لا يتم  قراءته وإنما من اجل التوضيح', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('first_line_not_read_but_clarification', 'The first line is not read but for clarification', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('foreign_currency', 'اجنبية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('foreign_currency', 'foreignv currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_account_no', 'من حساب رقم ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_account_no', 'From Account number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_amt', 'من مبلغ ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_amt', 'From Amount', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_bank_no', 'من بنك رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_bank_no', 'From  Bank No.', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_bond_no', 'من سند رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_bond_no', 'from bond no', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_box_no', 'من صندوق رقم ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_box_no', 'From Box No.', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_branch_no', 'من فرع رقم ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_branch_no', 'From branch number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_check_no', 'من شيك رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_check_no', 'From check number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_cost_center', 'من مركز تلكفة رقم ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_cost_center', 'From Cost center', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_date', 'من    تاريخ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_date', 'From Date', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_date_maturity', 'من تاريخ إستحقاق', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_date_maturity', 'From Date Maturity', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_journal_entry_no', 'من قيد رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_journal_entry_no', 'from journal entry number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_type', 'من نوع ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('from_type', 'from type', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('general_director', 'المدير العام', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('general_director', ' General Director', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_balance_sheet_rep', 'تقرير كشف الحساب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_balance_sheet_rep', 'GL Repots Balance Sheet', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_credits_req', 'استخدام الاعتمادات للطلبات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_credits_req', 'Use credits for requests', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_movement_rep', 'تقارير الحركات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_movement_rep', 'GL Repots Movements', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_no_based_on_type', 'ترقيم المستندات بناء على الانواع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_no_based_on_type', 'Numbering documents based on types', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_operation_rep', 'تقارير العمليات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_operation_rep', 'GL Repots Operation ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_para', 'متغيرات الاستاذ العام', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_para', 'gl_para', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_req_mandatory', 'الطلبات اجباري ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_req_mandatory', 'requests are mandatory', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_save_zero', 'حفظ المستندات الصفرية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('gl_save_zero', 'Save zero documents', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('goal', 'الهدف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('goal', 'goal', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('group_by_account_no', 'التجميع بحسب رقم الحساب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('group_by_account_no', 'Group by account number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('home', 'الرئيسية |  ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('home', 'Home |  ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('home_financial_system', 'الرئيسية | النظام المالي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('home_financial_system', 'Home | Financial system', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('import_excel', 'استيراد من اكسل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('import_excel', 'Import from Excel', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('import_excel_condations', 'استيراد  الدليل المحاسبي من اكسل   يجب ان يكون حسب', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('import_excel_condations', 'Importing the accounting directory from Excel shou', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('inputs', 'المدخلات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('inputs', 'Inputs', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('Input_currency', 'عملة الادخال', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('Input_currency', 'Input currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('inv_currency', 'عملة المخزون', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('inv_currency', 'invoce currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('journal', 'القيود اليومية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('journal', 'journal', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('journal_entry', 'القيود اليومية	', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('journal_entry', 'journal entry', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('journal_number', 'رقم القيد', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('journal_number', 'Journal number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('j_desc1', 'البيان', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('j_desc1', 'description', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('key', 'المفتاح', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('key', 'key', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('Language', 'اللغة ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('Language', 'Language', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('letterhead_branch', 'فرع الترويسة  ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('letterhead_branch', 'Letterhead Branch', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('level', 'الرتبة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('level', 'LEVEL ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('level_of_sub_account', 'رتبة الحساب الفرعي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('level_of_sub_account', 'Rank of sub account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('local_currency', 'عملة محلية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('local_currency', 'local currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('location', 'العنوان', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('location', 'location', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('logout', 'خروج', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('logout', 'Logout', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('manager', ' المدير', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('manager', 'Manager  ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('manager_no', 'رقم المدير', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('manager_no', 'Manager Number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('model', 'نموذج', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('model', 'Model', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('movement', 'الحركة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('movement', 'movement ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('movement_no', 'رقم الحركة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('movement_no', 'movement number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('movement_type', 'نوع الحركة ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('movement_type', 'Movement type', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('must_be_less_than', '\' يجب ان تكون اقل من  \' ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('must_be_less_than', '\'It must be less than\'', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('must_contain_primary_account', 'يجب ان يحتوي على الحساب الرئيسي  ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('must_contain_primary_account', 'Must contain primary account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('must_equal', '\' يجب ان تساوي  \'', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('must_equal', '\'it must equal\'', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('name', 'الاسم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('name', 'name', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('new', 'جديد', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('new', 'new', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('normal_user', 'مستخدم عادى', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('normal_user', 'Normal user', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_saved_empty_fields', 'لم يتم الحفظ  هناك حقول فارغة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_saved_empty_fields', 'not saved there are Empty fields', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_saved_error', 'لم يتم حفظ خطأ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_saved_error', 'not saved error', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_update_empty_fields', 'لم يتم التعديل  هناك حقول فارغة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_update_empty_fields', 'not modified there are Empty fields', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_update_error', 'لم يتم التعديل    حصل خطأ ، اثناء التعديل ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_update_error', 'Not modified An error occurred, while editing', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_update_no_data_as_condition', 'حصل خطأ ، اثناء التعديل لا يوجد بيانات حسب الشرط', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('not_update_no_data_as_condition', 'An error occurred, while modifying no data as per ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('no_data_as_required', 'لايوجد بيانات حسب الشرط', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('no_data_as_required', 'No data as required', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('number', 'رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('number', 'Number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('number_of_records', 'عدد السجلات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('number_of_records', 'Number of records', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('open_balance', 'الرصيد الافتتاحي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('open_balance', 'Open Balance', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('operation', 'العملية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('operation', 'the operation', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('operations', 'العمليات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('operations', 'Operations', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('options', 'الخيارات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('options', 'Options', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('password', 'كلمة المرور ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('password', 'password', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('paymentvoucher', ' سندات الصرف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('paymentvoucher', 'Payment Voucher', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('paymentvoucher_no', 'رقم سند الصرف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('paymentvoucher_no', 'Payment Voucher number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('pay_rentals', 'تسديد الايجارات ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('pay_rentals', 'Pay rentals', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('pay_vat', 'تسديد ضريبة القيمة المضافة ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('pay_vat', 'Payment of VAT', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('periodic_entry', 'قيد دوري', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('periodic_entry', 'Periodic entry', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('phone_nmber', 'رقم الهاتف / الجوال', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('phone_nmber', 'Phone nmber', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('phone_nmber2', '2رقم الهاتف / الجوال', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('phone_nmber2', 'Phone nmber2', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('primary', 'رئيسي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('primary', 'PRIMARY', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('print', 'طباعة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('print', 'print', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('public', 'عام ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('public', 'public', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('receipt', 'قبض ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('receipt', 'Receipt', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('receiptvoucher', 'سندات القبض', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('receiptvoucher', 'Receipt voucher', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('receiptvoucher_no', 'رقم سند القبض', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('receiptvoucher_no', 'receipt voucher number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('receipt_disbursement', 'قبض وصرف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('receipt_disbursement', 'Receipt and disbursement', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('recipient', 'المستلم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('recipient', 'the recipient', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('reference_number', 'رقم المرجع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('reference_number', 'Reference number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('registry_entry', 'مدخل السجل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('registry_entry', 'Registry entry', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('registry_update', 'معدل السجل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('registry_update', 'Registry  update', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('reports', 'التقارير', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('reports', 'Reports', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_footer', 'تذييل التقرير ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_footer', 'Report footer', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_footer_text', 'هذا الكشف صحيحا وموافق عليه من قبلكم مالم يصلنا اى', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_footer_text', 'This statement is true and approved by you unless ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_title', 'عنوان التقرير ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_title', 'Report Title', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_type_2_Profit_and_loss_and_1_balance_sheet', 'نوع التقرير2 ارباح وخسائر و 1  ميزانية عمومية ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_type_2_Profit_and_loss_and_1_balance_sheet', 'Report type 2 Profit and loss and 1 balance sheet', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_view_type', 'طريقة عرض التقرير', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('report_view_type', 'Report view Type', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('repots_title', 'عنوان التقرير', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('repots_title', 'Repots Title', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('request_journal', 'طلب قيد', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('request_journal', 'طلب إدخال دفتر اليومية', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_cpaymentvoucher', 'طلبات صرف شيكات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_cpaymentvoucher', 'request chique payment  ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_creceiptvoucher', 'طلبات استلام شيكات', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_creceiptvoucher', 'request chique receipt  ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_journal', 'طلبات القيود اليومية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_journal', 'request Journal', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_paymentvoucher', 'طلبات سندات الصرف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_paymentvoucher', 'request Payment Voucher', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_receiptvoucher', 'طلبات سندات القبض', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('req_receiptvoucher', 'request  Receipt Voucher', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('save', 'حفظ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('save', 'save', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('saved_successfully', 'حفظ بنجاح', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('saved_successfully', 'saved successfully', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('select_download', 'اختر رقم ثم اضغط انزال', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('select_download', 'Select a number and click Download', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('setup', 'تهيئة النظام', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('setup', 'setup', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('show', 'معاينة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('show', 'show', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sing_1', 'توقيع رقم1 ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sing_1', 'Signature # 1', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sing_2', 'توقيع رقم2 ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sing_2', 'Signature # 2', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sing_3', 'توقيع رقم3 ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sing_3', 'Signature # 3', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sing_4', 'توقيع رقم4 ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sing_4', 'Signature # 4', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('start_date', 'تاريخ البدء', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('start_date', 'starting date', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('status', 'الحالة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('status', 'status', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('stop', 'إيقاف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('stop', 'stop', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sub', 'فرعي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('sub', 'sub', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('tax_num', 'الاسم الاجنبي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('tax_num', 'Tax number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('text', 'النص', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('text', 'TEXT', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('there_was_an_error_!_the_level_of_the_account_must', 'حصل خطأ! رتبة الحساب  يجب ان تساوي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('there_was_an_error_!_the_level_of_the_account_must', 'There was an error! The level of the account must ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('there_was_an_error_account_number_must_contain_mai', 'حصل خطأ! رقم الحساب  يجب ان يحتوي على الحساب الرئي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('there_was_an_error_account_number_must_contain_mai', 'There was an error! The account number must contai', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('there_was_an_error_primary_account_may_not_exist_o', 'حصل خطأ! قد يكون   الحساب الرئيسي غير موجود   موجو', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('there_was_an_error_primary_account_may_not_exist_o', 'There was an error!  The master account may not ex', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('there_was_an_error_the_level_of_the_account_must_b', 'حصل خطأ! رتبة الحساب  يجب ان تساوي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('there_was_an_error_the_level_of_the_account_must_b', 'There was an error! The level of the account must ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total', 'اجمالى', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total', 'Total', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_amt', 'اجمالى المبلغ بالعملة المحلية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_amt', 'Total amount in local currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_credit', 'اجمالى الدائن بالمحلي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_credit', 'Total credit in local currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_debit', 'اجمالى المدين بالمحلي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_debit', 'Total debit in local currency', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_debt_must_be_equal_to_credit', 'يجب ان يكون اجمالى المدين يساوي الدائن', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_debt_must_be_equal_to_credit', 'The total debt must be equal to  credit', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_must_be_equal_to_credit_debt', 'يجب ان يكون اجمالى المبلغ يساوي الدائن والمدين ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('total_must_be_equal_to_credit_debt', 'The total amount must be equal to  credit and  deb', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_account_no', 'الى حساب رقم ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_account_no', 'To Account number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_amt', 'الى مبلغ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_amt', 'TO Amount', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_amt_must>from_amt', 'يجب ان يكون  الى مبلغ اكبراو يساوي من من مبلغ ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_amt_must>from_amt', 'The To Amount must be equal to  from amount', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_bank_no', 'الى بنك رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_bank_no', 'To Bank No.', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_bond_no', 'الى سند رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_bond_no', 'to bond no', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_box_no', 'الى صندوق رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_box_no', 'To Box No.', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_branch_must>from_brnach', 'يجب ان يكون  الى فرع اكبراو يساوي من من فرع ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_branch_must>from_brnach', 'The branch must be greater than or equal to that o', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_branch_no', 'الى فرع رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_branch_no', 'To branch number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_check_no', 'الى شيك رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_check_no', 'To check number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_cost_center', 'الى مركز تلكفة رقم ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_cost_center', 'To Cost center', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_cost_must>from_cost', 'يجب ان يكون  الى  مركز تكلفة اكبر او يساوي من من م', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_cost_must>from_cost', 'The To cost center must be equal to  from cost cen', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_date', 'الى    تاريخ ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_date', 'To Date', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_date_maturity', 'الى تاريخ إستحقاق', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_date_maturity', 'To Date Maturity', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_date_must>from_date', 'يجب ان يكون  الى تاريخ اكبراو يساوي من من تاريخ ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_date_must>from_date', 'The To date must be equal to  from date', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_journal_entry_no', 'الى قيد رقم ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_journal_entry_no', 'to journal entry number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_number_must>from_tnumber', 'يجب ان يكون  الى رقم اكبراو يساوي من من رقم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_number_must>from_tnumber', 'The To number must be equal to  from number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_type', 'الى نوع ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('to_type', 'to type', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type', 'النوع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type', 'Type', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_1_main_and_0_sub', 'النوع 1 رئيسي و 0 فرعي ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_1_main_and_0_sub', 'Type 1 main and 0 sub', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_journal_entry', 'انواع القيود اليومية', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_journal_entry', 'Type of  Journal entry', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_must>from_type', 'يجب ان يكون  الى النوع اكبر او يساوي من من النوع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_must>from_type', 'From the  Type must be >=  to the  type', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_no', ' رقم النوع', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_no', 'Type  number', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_of_reports', 'نوع التقرير', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_of_reports', ' TYPE OF REPORT ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_payment_voucher', 'انواع سندات الصرف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_payment_voucher', 'Type of payment voucher', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_receipt_voucher', 'انواع سندات القبض', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('type_receipt_voucher', 'Type of Receipt voucher', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('Unnature_accoutn', ' الحسابات المخالفة لطبيعتها', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('Unnature_accoutn', 'Account unnature', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('un_used', 'غير مستخدم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('un_used', 'Not used', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('update', 'تعديل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('update', 'update', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('update_chart_of_account', 'تعديل الدليل المحاسبي', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('update_chart_of_account', 'Update chart of account', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('update_network', 'تحديث الشبكة | 2019', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('update_network', 'Update NetworK |2019', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('update_times', 'مرات التعديل', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('update_times', 'Update times', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('used', 'مستخدم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('used', 'Used', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('users', 'المستخدمين', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('users', 'Users', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('users_info', 'معلومات المستخدم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('users_info', 'Users_info', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('user_id', 'رقم المستخدم ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('user_id', 'user id', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('user_name', 'اسم المستخدم', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('user_name', 'user name', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('user_stoped_cant_update', 'المستخدم موقف لايمكن تعديلة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('user_stoped_cant_update', 'User has been  stoped cannot be modified', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('use_box_in_journal', 'استخدام الصناديق فى القيود ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('use_box_in_journal', 'Use of funds in restrictions', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('vat_correction', 'تصحيح ضريبة القيمة المضافة', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('vat_correction', 'VAT correction', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('vat_refund_provider', 'مقدم استرداد ضريبة اليمة المضافة ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('vat_refund_provider', 'VAT refund provider', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('vendors', ' الموردين', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('vendors', 'vendors ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('website', 'الموقع الاللكتروني', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('website', 'website', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('word', 'وورد', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('word', 'word', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('you_cannot_entervalue_creditor_and_debt', 'لا يمكنك ادخال قيمة للدائن والمدين لنفس الحساب بنف', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('you_cannot_entervalue_creditor_and_debt', 'You cannot enter a value for the creditor and the ', 'english');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('you_can_also_download_file by_extension', '  كما يمكنك تنزيل ملف حسب الامتداد ', 'arabic');
INSERT INTO `translate` (`id`, `value`, `language`) VALUES ('you_can_also_download_file by_extension', 'You can also download a file by extension', 'english');


#
# TABLE STRUCTURE FOR: type_journal_entry
#

DROP TABLE IF EXISTS `type_journal_entry`;

CREATE TABLE `type_journal_entry` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `e_name` int(50) NOT NULL,
  `goal` varchar(50) NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` int(11) NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `type_journal_entry` (`id`, `name`, `e_name`, `goal`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 'شهري', 0, '5', 0, 1, '2019-06-23', '192.168.1.10moshtaq', 1, 2019, '192.168.1.10moshtaq', 7);
INSERT INTO `type_journal_entry` (`id`, `name`, `e_name`, `goal`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 'على حسب المستخدم', 0, '5', 0, 1, '2019-06-24', '192.168.1.10moshtaq', 1, 2019, '192.168.1.10moshtaq', 1);
INSERT INTO `type_journal_entry` (`id`, `name`, `e_name`, `goal`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (11, 'عام', 0, '5', 0, 1, '2019-06-23', '192.168.1.10moshtaq', 1, 2019, '192.168.1.10moshtaq', 6);


#
# TABLE STRUCTURE FOR: type_payment_voucher
#

DROP TABLE IF EXISTS `type_payment_voucher`;

CREATE TABLE `type_payment_voucher` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `e_name` int(50) NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `type_payment_voucher` (`id`, `name`, `e_name`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 'EvaluationCustomerd', 1, 0, 1, '2019-06-23', '192.168.1.10moshtaq', 1, '2019-06-24', '192.168.1.10moshtaq', 4);
INSERT INTO `type_payment_voucher` (`id`, `name`, `e_name`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 'EvaluationCustomerds', 1, 0, 1, '2019-06-24', '192.168.1.10moshtaq', 0, '0000-00-00', '', 0);


#
# TABLE STRUCTURE FOR: type_receipt_voucher
#

DROP TABLE IF EXISTS `type_receipt_voucher`;

CREATE TABLE `type_receipt_voucher` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `e_name` int(50) NOT NULL,
  `statuse` int(11) NOT NULL DEFAULT '0',
  `ad_u_id` int(11) NOT NULL,
  `ad_date` date NOT NULL,
  `ad_trmnl` varchar(50) NOT NULL,
  `up_u_id` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `up_trmnl` varchar(50) NOT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `type_receipt_voucher` (`id`, `name`, `e_name`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (1, 'qEvaluationCustomer', 0, 0, 1, '2019-06-23', '192.168.1.10moshtaq', 1, '2019-07-07', '192.168.1.14drabdulrahman', 6);
INSERT INTO `type_receipt_voucher` (`id`, `name`, `e_name`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (2, 'EvaluationCustomer1', 1, 0, 1, '2019-06-23', '192.168.1.10moshtaq', 0, '0000-00-00', '', 0);
INSERT INTO `type_receipt_voucher` (`id`, `name`, `e_name`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (3, 'EvaluationCustomer1ي', 1, 0, 1, '2019-06-23', '192.168.1.10moshtaq', 1, '2019-06-23', '192.168.1.10moshtaq', 1);
INSERT INTO `type_receipt_voucher` (`id`, `name`, `e_name`, `statuse`, `ad_u_id`, `ad_date`, `ad_trmnl`, `up_u_id`, `up_date`, `up_trmnl`, `up_count`) VALUES (24, 'qEvaluationuCustomer', 0, 0, 1, '2019-07-07', '192.168.1.14drabdulrahman', 0, '0000-00-00', '', 0);


#
# TABLE STRUCTURE FOR: unit
#

DROP TABLE IF EXISTS `unit`;

CREATE TABLE `unit` (
  `chort` varchar(10) NOT NULL,
  `unit_name` varchar(30) DEFAULT NULL,
  `unit_e_name` varchar(30) DEFAULT NULL,
  `unit_type` int(1) DEFAULT '1',
  `defsult_size` int(10) DEFAULT '1',
  `ad_u_id` int(5) DEFAULT NULL,
  `ad_date` date DEFAULT NULL,
  `up_u_id` int(5) DEFAULT NULL,
  `up_date` date DEFAULT NULL,
  `up_count` int(10) DEFAULT '0',
  `ad_trmnl` varchar(50) DEFAULT NULL,
  `up_trmnl` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`chort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: user_r
#

DROP TABLE IF EXISTS `user_r`;

CREATE TABLE `user_r` (
  `id` int(5) NOT NULL,
  `U_A_NAME` varchar(100) NOT NULL,
  `U_E_NAME` varchar(100) DEFAULT NULL,
  `U_MNG` int(5) DEFAULT NULL,
  `GROUP_NO` int(5) DEFAULT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `PASSWORD2` varchar(20) DEFAULT NULL,
  `f_DATE` date DEFAULT NULL,
  `t_EDATE` date DEFAULT NULL,
  `statuse` int(1) DEFAULT '0',
  `A_CODE` varchar(30) DEFAULT NULL,
  `logo` blob NOT NULL,
  `type` int(11) NOT NULL,
  `CHNG_PASSWD_AFTR_LGN` int(1) DEFAULT '0',
  `EMP_NO` int(10) DEFAULT NULL,
  `default_lang` varchar(11) NOT NULL,
  `AD_U_ID` int(5) DEFAULT NULL,
  `AD_DATE` date DEFAULT NULL,
  `UP_U_ID` int(5) DEFAULT NULL,
  `UP_DATE` date DEFAULT NULL,
  `AD_TRMNL_NM` varchar(50) DEFAULT NULL,
  `UP_TRMNL_NM` varchar(50) DEFAULT NULL,
  `mobile_no` int(11) DEFAULT NULL,
  `email_id` varchar(5) DEFAULT NULL,
  `up_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `U_A_NAME` (`U_A_NAME`),
  KEY `default_lang` (`default_lang`),
  CONSTRAINT `user_r_ibfk_1` FOREIGN KEY (`default_lang`) REFERENCES `languages` (`lang_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user_r` (`id`, `U_A_NAME`, `U_E_NAME`, `U_MNG`, `GROUP_NO`, `PASSWORD`, `PASSWORD2`, `f_DATE`, `t_EDATE`, `statuse`, `A_CODE`, `logo`, `type`, `CHNG_PASSWD_AFTR_LGN`, `EMP_NO`, `default_lang`, `AD_U_ID`, `AD_DATE`, `UP_U_ID`, `UP_DATE`, `AD_TRMNL_NM`, `UP_TRMNL_NM`, `mobile_no`, `email_id`, `up_count`) VALUES (1, 'Admin', 'admin', 1, NULL, '12345', '12345', '0000-00-00', '0000-00-00', 1, NULL, 'Admin', 2, 0, NULL, 'arabic', NULL, NULL, 1, '2019-09-01', NULL, '192.168.1.14moshtaq', 0, '', 2);
INSERT INTO `user_r` (`id`, `U_A_NAME`, `U_E_NAME`, `U_MNG`, `GROUP_NO`, `PASSWORD`, `PASSWORD2`, `f_DATE`, `t_EDATE`, `statuse`, `A_CODE`, `logo`, `type`, `CHNG_PASSWD_AFTR_LGN`, `EMP_NO`, `default_lang`, `AD_U_ID`, `AD_DATE`, `UP_U_ID`, `UP_DATE`, `AD_TRMNL_NM`, `UP_TRMNL_NM`, `mobile_no`, `email_id`, `up_count`) VALUES (2, 'moshtaq', 'moshtaq', 1, NULL, '12345', '12345', '0000-00-00', '0000-00-00', 1, NULL, 'moshtaq', 1, 0, NULL, 'english', NULL, NULL, 1, '2019-09-01', NULL, '192.168.1.14moshtaq', 0, '', 1);
INSERT INTO `user_r` (`id`, `U_A_NAME`, `U_E_NAME`, `U_MNG`, `GROUP_NO`, `PASSWORD`, `PASSWORD2`, `f_DATE`, `t_EDATE`, `statuse`, `A_CODE`, `logo`, `type`, `CHNG_PASSWD_AFTR_LGN`, `EMP_NO`, `default_lang`, `AD_U_ID`, `AD_DATE`, `UP_U_ID`, `UP_DATE`, `AD_TRMNL_NM`, `UP_TRMNL_NM`, `mobile_no`, `email_id`, `up_count`) VALUES (3, 'فغا56اغ56اغ', NULL, 1, NULL, '65غ56اغا', NULL, '0000-00-00', '0000-00-00', 1, NULL, 'فغا56اغ56اغ', 1, 0, NULL, 'arabic', 1, '2019-09-01', 1, '2019-09-01', NULL, '192.168.1.14moshtaq', 0, '', 1);


#
# TABLE STRUCTURE FOR: venders
#

DROP TABLE IF EXISTS `venders`;

CREATE TABLE `venders` (
  `ID` int(11) NOT NULL,
  `VendersName` varchar(256) DEFAULT NULL,
  `VendersAccount` int(11) DEFAULT NULL,
  `VendersPhone` int(11) DEFAULT NULL,
  `VendersMobile` int(11) DEFAULT NULL,
  `VendersEmail` varchar(256) DEFAULT NULL,
  `VendersAddress` varchar(256) DEFAULT NULL,
  `VendersDebtLimit` float DEFAULT NULL,
  `VendersTxNo` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: warehouses
#

DROP TABLE IF EXISTS `warehouses`;

CREATE TABLE `warehouses` (
  `wh_code` int(10) NOT NULL,
  `warehousename` varchar(100) NOT NULL,
  `warehousename_en` varchar(100) DEFAULT NULL,
  `addres` varchar(100) DEFAULT NULL,
  `tel_no` varchar(30) DEFAULT NULL,
  `statuse` int(1) DEFAULT '1',
  `wh_keeper` varchar(100) DEFAULT NULL,
  `price_level` int(10) DEFAULT NULL,
  `no_sale` int(1) DEFAULT '0',
  `country_id` int(1) DEFAULT '0',
  `warehouse_trans_account` int(30) DEFAULT NULL,
  `city_id` int(10) DEFAULT NULL,
  `region_id` int(11) NOT NULL,
  `brn_id` int(6) DEFAULT NULL,
  `ad_u_id` int(5) DEFAULT NULL,
  `ad_date` date DEFAULT NULL,
  `up_u_id` int(5) DEFAULT NULL,
  `up_date` date DEFAULT NULL,
  `up_count` int(10) DEFAULT '0',
  `currency` int(10) DEFAULT NULL,
  `ad_trmnl` varchar(50) DEFAULT NULL,
  `up_trmnl` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`wh_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

